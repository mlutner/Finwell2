export interface FinancialAssessment {
  monthlyIncome: number;
  monthlyExpenses: number;
  savings: number;
  debt: number;
  financialGoals: string[];
  riskTolerance: 'low' | 'medium' | 'high';
  investmentExperience: 'none' | 'beginner' | 'intermediate' | 'advanced';
}

export interface MoodEntry {
  date: string;
  mood: 'very_negative' | 'negative' | 'neutral' | 'positive' | 'very_positive';
  financialAnxiety: number;
  notes?: string;
}

export interface AssessmentState {
  initialAssessment: FinancialAssessment | null;
  moodEntries: MoodEntry[];
  lastAssessmentDate: string | null;
}