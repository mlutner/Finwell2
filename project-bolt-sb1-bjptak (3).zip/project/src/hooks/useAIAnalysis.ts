import { useState } from 'react';
import OpenAI from 'openai';

// Mock response for when API key is not available
const mockAnalysis = {
  riskLevel: 'moderate' as const,
  sentiment: 'neutral' as const,
  emotionalTriggers: ['financial stress', 'impulsive spending', 'money anxiety'],
  recommendations: {
    cbt: [
      'Practice mindfulness when making financial decisions',
      'Challenge negative money beliefs',
      'Keep a financial thought diary'
    ],
    financial: [
      'Create a monthly budget',
      'Track daily expenses',
      'Build an emergency fund'
    ],
    combined: [
      'Set realistic financial goals aligned with your values',
      'Develop healthy money habits through CBT techniques',
      'Practice self-compassion during financial setbacks'
    ]
  },
  suggestedModules: [
    'Financial Mindset Fundamentals',
    'Emotional Spending Awareness',
    'Building Healthy Money Habits'
  ]
};

export function useAIAnalysis() {
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const analyzeResponses = async (assessmentData: any): Promise<typeof mockAnalysis> => {
    setIsAnalyzing(true);
    try {
      const apiKey = import.meta.env.VITE_OPENAI_API_KEY;

      // If no API key is available, return mock data after a delay
      if (!apiKey) {
        await new Promise(resolve => setTimeout(resolve, 1500)); // Simulate API delay
        return mockAnalysis;
      }

      // If API key is available, use OpenAI
      const openai = new OpenAI({
        apiKey,
        dangerouslyAllowBrowser: true
      });

      const prompt = generatePrompt(assessmentData);
      const response = await openai.chat.completions.create({
        model: "gpt-4",
        messages: [{
          role: "system",
          content: "You are a financial therapist expert in CBT techniques. Analyze the assessment responses and provide insights."
        }, {
          role: "user",
          content: prompt
        }],
        temperature: 0.7,
        max_tokens: 1000,
      });

      return parseAIResponse(response.choices[0].message?.content || '');
    } catch (error) {
      console.error('AI Analysis Error:', error);
      // Fallback to mock data if API call fails
      return mockAnalysis;
    } finally {
      setIsAnalyzing(false);
    }
  };

  return {
    analyzeResponses,
    isAnalyzing,
  };
}

function generatePrompt(data: any): string {
  return `
    Analyze the following financial wellness assessment data:
    
    Initial Assessment:
    ${JSON.stringify(data.initial, null, 2)}
    
    Emotional Assessment:
    ${JSON.stringify(data.emotional, null, 2)}
    
    Financial Assessment:
    ${JSON.stringify(data.financial, null, 2)}
    
    Please provide:
    1. Risk level assessment (low, moderate, high, severe)
    2. Sentiment analysis
    3. Identified emotional triggers
    4. CBT-based recommendations
    5. Financial recommendations
    6. Combined therapy approach suggestions
    7. Recommended learning modules
  `;
}

function parseAIResponse(response: string): typeof mockAnalysis {
  try {
    // Attempt to parse AI response
    // This is a placeholder - you would need to implement proper parsing logic
    return mockAnalysis;
  } catch (error) {
    console.error('Error parsing AI response:', error);
    return mockAnalysis;
  }
}