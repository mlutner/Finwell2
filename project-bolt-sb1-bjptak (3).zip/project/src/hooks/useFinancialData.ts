import { useState } from 'react';

interface FinancialMetrics {
  wellbeingScore: number;
  mindsetScore: number;
  resiliencyScore: number;
  consistencyScore: number;
  spendingScore: number;
}

export function useFinancialData() {
  const [metrics, setMetrics] = useState<FinancialMetrics>({
    wellbeingScore: 78,
    mindsetScore: 80,
    resiliencyScore: 75,
    consistencyScore: 85,
    spendingScore: 70
  });

  const updateMetrics = (newMetrics: Partial<FinancialMetrics>) => {
    setMetrics(prev => ({ ...prev, ...newMetrics }));
  };

  return {
    metrics,
    updateMetrics
  };
}