import {
  Box,
  Button,
  Card,
  CardBody,
  CardHeader,
  Heading,
  Radio,
  RadioGroup,
  Stack,
  Text,
  VStack,
  Textarea,
} from '@chakra-ui/react';
import { useState } from 'react';

interface Question {
  id: number;
  text: string;
  options: string[];
  type: 'radio' | 'text';
}

const questions: Question[] = [
  {
    id: 1,
    text: 'How would you describe your current relationship with money?',
    options: [
      'Very stressful',
      'Somewhat stressful',
      'Neutral',
      'Somewhat comfortable',
      'Very comfortable'
    ],
    type: 'radio'
  },
  {
    id: 2,
    text: 'What are your main financial concerns or challenges?',
    options: [],
    type: 'text'
  },
  {
    id: 3,
    text: 'How confident do you feel about making financial decisions?',
    options: [
      'Not at all confident',
      'Slightly confident',
      'Moderately confident',
      'Very confident',
      'Extremely confident'
    ],
    type: 'radio'
  }
];

interface Props {
  onComplete: (data: any) => void;
}

export default function InitialAssessment({ onComplete }: Props) {
  const [responses, setResponses] = useState<Record<number, string>>({});

  const handleResponse = (questionId: number, value: string) => {
    setResponses(prev => ({
      ...prev,
      [questionId]: value
    }));
  };

  const handleSubmit = () => {
    onComplete({
      initial: {
        responses,
        timestamp: new Date().toISOString()
      }
    });
  };

  const isComplete = questions.every(q => 
    q.type === 'text' 
      ? responses[q.id]?.trim().length > 0
      : responses[q.id]
  );

  return (
    <Card>
      <CardHeader>
        <Heading size="lg">Initial Assessment</Heading>
        <Text mt={2} color="gray.600">
          Let's start by understanding your current financial situation
        </Text>
      </CardHeader>

      <CardBody>
        <VStack spacing={8} align="stretch">
          {questions.map((question) => (
            <Box key={question.id}>
              <Text mb={4} fontSize="lg" fontWeight="medium">
                {question.text}
              </Text>
              
              {question.type === 'radio' ? (
                <RadioGroup
                  onChange={(value) => handleResponse(question.id, value)}
                  value={responses[question.id] || ''}
                >
                  <Stack spacing={4}>
                    {question.options.map((option) => (
                      <Radio
                        key={option}
                        value={option}
                        colorScheme="purple"
                        size="lg"
                      >
                        {option}
                      </Radio>
                    ))}
                  </Stack>
                </RadioGroup>
              ) : (
                <Textarea
                  value={responses[question.id] || ''}
                  onChange={(e) => handleResponse(question.id, e.target.value)}
                  placeholder="Type your answer here..."
                  minH="120px"
                  resize="vertical"
                />
              )}
            </Box>
          ))}

          <Button
            colorScheme="purple"
            size="lg"
            onClick={handleSubmit}
            isDisabled={!isComplete}
            bgGradient="linear(to-r, purple.500, blue.500)"
            _hover={{
              bgGradient: "linear(to-r, purple.600, blue.600)",
            }}
          >
            Continue
          </Button>
        </VStack>
      </CardBody>
    </Card>
  );
}