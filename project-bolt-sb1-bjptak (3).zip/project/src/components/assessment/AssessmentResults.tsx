import {
  Box,
  Button,
  Card,
  CardBody,
  CardHeader,
  Heading,
  List,
  ListIcon,
  ListItem,
  Stack,
  Text,
  VStack,
  Badge,
  Divider,
  useToast,
} from '@chakra-ui/react';
import { CheckCircleIcon, WarningIcon, InfoIcon } from '@chakra-ui/icons';
import { useNavigate } from 'react-router-dom';

interface Props {
  data: any;
  analysis: {
    riskLevel: string;
    sentiment: string;
    emotionalTriggers: string[];
    recommendations: {
      cbt: string[];
      financial: string[];
      combined: string[];
    };
    suggestedModules: string[];
  };
  onComplete: () => void;
}

export default function AssessmentResults({ data, analysis, onComplete }: Props) {
  const navigate = useNavigate();
  const toast = useToast();

  const handleStartJourney = () => {
    // Save pathway assignment
    localStorage.setItem('assignedPathway', JSON.stringify({
      modules: analysis.suggestedModules,
      startedAt: new Date().toISOString(),
      currentModule: 0,
      progress: 0
    }));

    toast({
      title: 'Pathway Assigned',
      description: 'Your personalized learning pathway has been created.',
      status: 'success',
      duration: 3000,
    });

    onComplete();
  };

  const getRiskColor = (level: string) => {
    switch (level.toLowerCase()) {
      case 'low': return 'green';
      case 'moderate': return 'yellow';
      case 'high': return 'orange';
      case 'severe': return 'red';
      default: return 'gray';
    }
  };

  return (
    <VStack spacing={6} align="stretch">
      <Card>
        <CardHeader>
          <Stack direction="row" justify="space-between" align="center">
            <Heading size="lg">Your Assessment Results</Heading>
            <Badge
              colorScheme={getRiskColor(analysis.riskLevel)}
              fontSize="md"
              px={3}
              py={1}
              borderRadius="full"
            >
              {analysis.riskLevel.toUpperCase()} RISK
            </Badge>
          </Stack>
        </CardHeader>

        <CardBody>
          <VStack spacing={6} align="stretch">
            {/* Analysis sections remain the same */}
            
            <Divider />

            <Box>
              <Heading size="md" mb={4}>Your Personalized Learning Path</Heading>
              <Text mb={4} color="gray.600">
                Based on your assessment, we've created a customized learning journey for you:
              </Text>
              <List spacing={3}>
                {analysis.suggestedModules.map((module, index) => (
                  <ListItem 
                    key={index} 
                    display="flex" 
                    alignItems="center"
                    bg="purple.50"
                    p={3}
                    rounded="md"
                  >
                    <ListIcon as={InfoIcon} color="purple.500" boxSize={5} />
                    <Box ml={3}>
                      <Text fontWeight="medium">{module}</Text>
                      <Text fontSize="sm" color="gray.600">
                        Module {index + 1}
                      </Text>
                    </Box>
                  </ListItem>
                ))}
              </List>
            </Box>
          </VStack>
        </CardBody>
      </Card>

      <Stack direction="row" spacing={4} justify="center">
        <Button
          size="lg"
          colorScheme="purple"
          onClick={handleStartJourney}
          bgGradient="linear(to-r, purple.500, blue.500)"
          _hover={{
            bgGradient: "linear(to-r, purple.600, blue.600)",
          }}
          px={8}
        >
          Start Your Journey
        </Button>
      </Stack>
    </VStack>
  );
}