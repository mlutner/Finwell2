import {
  Box,
  Button,
  Flex,
  Icon,
  IconButton,
  Input,
  Text,
  VStack,
  useDisclosure,
  Collapse,
  Tooltip,
  Badge,
} from '@chakra-ui/react';
import { FiMessageSquare, FiX, FiSend, FiHelpCircle } from 'react-icons/fi';
import { useState, useRef, useEffect } from 'react';
import ChatExplainer from './ChatExplainer';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  timestamp: Date;
}

interface Props {
  context?: string;
  initialMessage?: string;
  position?: 'fixed' | 'relative';
  showExplainer?: boolean;
}

export default function AIChat({ 
  context = 'general',
  initialMessage = "Hi! I'm your AI financial wellness assistant. How can I help you today?",
  position = 'fixed',
  showExplainer = true,
}: Props) {
  const { isOpen, onToggle } = useDisclosure();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [showExplainerModal, setShowExplainerModal] = useState(false);

  useEffect(() => {
    if (initialMessage) {
      setMessages([{
        id: '0',
        text: initialMessage,
        sender: 'ai',
        timestamp: new Date()
      }]);
    }
  }, [initialMessage]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: input,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: "I understand your question. Let me help you with that...",
        sender: 'ai',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, aiMessage]);
      setIsTyping(false);
    }, 1500);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <>
      <Box
        position={position}
        bottom={6}
        right={6}
        zIndex={1000}
        maxW="400px"
        w="full"
      >
        <Collapse in={isOpen} animateOpacity>
          <Box
            bg="white"
            rounded="lg"
            shadow="lg"
            overflow="hidden"
            maxH="600px"
            display="flex"
            flexDirection="column"
          >
            {/* Header */}
            <Flex
              align="center"
              justify="space-between"
              p={4}
              bg="purple.500"
              color="white"
            >
              <Flex align="center" gap={2}>
                <Icon as={FiMessageSquare} boxSize={5} />
                <Text fontWeight="medium">AI Assistant</Text>
                {isTyping && (
                  <Badge colorScheme="green" variant="solid" fontSize="xs">
                    typing...
                  </Badge>
                )}
              </Flex>
              <Flex gap={2}>
                {showExplainer && (
                  <Tooltip label="Learn about AI assistance">
                    <IconButton
                      icon={<FiHelpCircle />}
                      aria-label="Help"
                      variant="ghost"
                      color="white"
                      _hover={{ bg: 'purple.600' }}
                      onClick={() => setShowExplainerModal(true)}
                    />
                  </Tooltip>
                )}
                <IconButton
                  icon={<FiX />}
                  aria-label="Close chat"
                  variant="ghost"
                  color="white"
                  _hover={{ bg: 'purple.600' }}
                  onClick={onToggle}
                />
              </Flex>
            </Flex>

            {/* Messages */}
            <VStack
              spacing={4}
              p={4}
              overflowY="auto"
              maxH="400px"
              bg="gray.50"
              align="stretch"
            >
              {messages.map((message) => (
                <Flex
                  key={message.id}
                  justify={message.sender === 'user' ? 'flex-end' : 'flex-start'}
                >
                  <Box
                    maxW="80%"
                    bg={message.sender === 'user' ? 'purple.500' : 'white'}
                    color={message.sender === 'user' ? 'white' : 'gray.800'}
                    px={4}
                    py={2}
                    rounded="lg"
                    shadow="sm"
                  >
                    <Text>{message.text}</Text>
                  </Box>
                </Flex>
              ))}
              {isTyping && (
                <Flex>
                  <Box bg="white" px={4} py={2} rounded="lg" shadow="sm">
                    <Text color="gray.500">Typing...</Text>
                  </Box>
                </Flex>
              )}
              <div ref={messagesEndRef} />
            </VStack>

            {/* Input */}
            <Flex p={4} bg="white" borderTop="1px" borderColor="gray.100">
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Type your message..."
                mr={2}
              />
              <IconButton
                colorScheme="purple"
                aria-label="Send message"
                icon={<FiSend />}
                onClick={handleSend}
                isDisabled={!input.trim()}
              />
            </Flex>
          </Box>
        </Collapse>

        {/* Toggle Button */}
        {!isOpen && (
          <Button
            position={position}
            bottom={6}
            right={6}
            colorScheme="purple"
            leftIcon={<FiMessageSquare />}
            onClick={onToggle}
            shadow="md"
          >
            Chat with AI Assistant
          </Button>
        )}
      </Box>

      {/* Explainer Modal */}
      <ChatExplainer
        isOpen={showExplainerModal}
        onClose={() => setShowExplainerModal(false)}
      />
    </>
  );
}