import {
  Box,
  Container,
  Grid,
  Heading,
  Text,
  VStack,
  Flex,
} from '@chakra-ui/react';
import { useState } from 'react';
import MetricsCard from './MetricsCard';
import MoodTracker from './MoodTracker';
import QuickActions from './QuickActions';
import SpendingGraph from './SpendingGraph';
import LearningPathways from './LearningPathways';
import AIChat from '../chat/AIChat';
import BankSync from './BankSync';

export default function Dashboard() {
  const [currentMood, setCurrentMood] = useState<string | null>(null);

  const handleMoodSelect = (mood: string) => {
    setCurrentMood(mood);
  };

  return (
    <Container maxW="container.xl" py={8}>
      <VStack spacing={8} align="stretch">
        {/* Header with Bank Sync */}
        <Flex justify="space-between" align="center">
          <Box>
            <Heading size="lg" mb={2}>Dashboard</Heading>
            <Text color="gray.600">
              Welcome back! Here's your financial wellness overview.
            </Text>
          </Box>
          <Box maxW="xs">
            <BankSync />
          </Box>
        </Flex>

        {/* Main Content */}
        <Grid templateColumns={{ base: '1fr', lg: '2fr 1fr' }} gap={6}>
          {/* Left Column */}
          <VStack spacing={6} align="stretch">
            <MetricsCard />
            <SpendingGraph />
          </VStack>

          {/* Right Column */}
          <VStack spacing={6} align="stretch">
            <MoodTracker onMoodSelect={handleMoodSelect} />
            <QuickActions />
            <LearningPathways />
          </VStack>
        </Grid>

        {/* AI Chat */}
        <AIChat
          context="dashboard"
          initialMessage={
            currentMood === 'Bad' || currentMood === 'Low'
              ? "I noticed you're not feeling great. Would you like to talk about what's bothering you?"
              : "Welcome to your dashboard! I'm here to help you understand your financial wellness metrics and answer any questions."
          }
          showExplainer={true}
        />
      </VStack>
    </Container>
  );
}