import {
  Box,
  Button,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalCloseButton,
  Text,
  VStack,
  Icon,
  useDisclosure,
  List,
  ListItem,
  ListIcon,
} from '@chakra-ui/react';
import { FiUpload, FiLock, FiShield, FiCheck } from 'react-icons/fi';
import { useState } from 'react';

export default function BankSync() {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [isConnecting, setIsConnecting] = useState(false);

  const handleConnect = async () => {
    setIsConnecting(true);
    // TODO: Implement actual bank connection logic
    setTimeout(() => {
      setIsConnecting(false);
      onClose();
    }, 2000);
  };

  return (
    <>
      <Button
        leftIcon={<Icon as={FiUpload} />}
        colorScheme="blue"
        onClick={onOpen}
        size="lg"
        w="full"
      >
        Connect Bank Account
      </Button>

      <Modal isOpen={isOpen} onClose={onClose} size="lg">
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>Connect Your Bank Account</ModalHeader>
          <ModalCloseButton />
          <ModalBody pb={6}>
            <VStack spacing={6} align="stretch">
              <Text>
                Securely connect your bank account to automatically track your spending,
                set budgets, and get personalized insights.
              </Text>

              <Box bg="blue.50" p={4} rounded="lg">
                <Text fontWeight="medium" mb={2}>Why connect your bank?</Text>
                <List spacing={2}>
                  <ListItem display="flex" alignItems="center">
                    <ListIcon as={FiCheck} color="green.500" />
                    Automatic transaction tracking
                  </ListItem>
                  <ListItem display="flex" alignItems="center">
                    <ListIcon as={FiCheck} color="green.500" />
                    Real-time spending insights
                  </ListItem>
                  <ListItem display="flex" alignItems="center">
                    <ListIcon as={FiCheck} color="green.500" />
                    Smart budgeting recommendations
                  </ListItem>
                </List>
              </Box>

              <Box bg="gray.50" p={4} rounded="lg">
                <VStack spacing={3} align="stretch">
                  <Box display="flex" alignItems="center" gap={2}>
                    <Icon as={FiLock} color="purple.500" />
                    <Text fontWeight="medium">Bank-level Security</Text>
                  </Box>
                  <Text fontSize="sm" color="gray.600">
                    We use industry-leading encryption and security practices to keep
                    your data safe. We never store your bank credentials.
                  </Text>
                </VStack>
              </Box>

              <Button
                colorScheme="purple"
                size="lg"
                onClick={handleConnect}
                isLoading={isConnecting}
                loadingText="Connecting..."
                leftIcon={<Icon as={FiShield} />}
              >
                Securely Connect Bank
              </Button>

              <Text fontSize="sm" color="gray.500" textAlign="center">
                By connecting your bank, you agree to our Terms of Service and Privacy Policy.
              </Text>
            </VStack>
          </ModalBody>
        </ModalContent>
      </Modal>
    </>
  );
}