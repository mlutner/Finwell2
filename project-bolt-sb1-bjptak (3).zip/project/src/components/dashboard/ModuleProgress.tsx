import {
  Box,
  Button,
  Collapse,
  Flex,
  Progress,
  Text,
  VStack,
  Icon,
  useDisclosure,
  Tooltip,
} from '@chakra-ui/react';
import { FiChevronRight, FiChevronDown } from 'react-icons/fi';

const MODULES = [
  { 
    id: 1,
    title: 'Goal Setting & Initial Assessment',
    shortTitle: 'Goals & Assessment',
    progress: 0,
    status: 'upcoming' as const
  },
  { 
    id: 2,
    title: 'First Steps & Taking Action',
    shortTitle: 'First Steps',
    progress: 0,
    status: 'upcoming' as const
  },
  { 
    id: 3,
    title: 'Identifying Triggers & Emotional Spending',
    shortTitle: 'Triggers & Spending',
    progress: 0,
    status: 'upcoming' as const
  },
  { 
    id: 4,
    title: 'Cognitive Restructuring & Thought Management',
    shortTitle: 'Thought Management',
    progress: 0,
    status: 'upcoming' as const
  },
  { 
    id: 5,
    title: 'Building Sustainable Financial Habits',
    shortTitle: 'Building Habits',
    progress: 0,
    status: 'upcoming' as const
  },
  { 
    id: 6,
    title: 'Strengthening Emotional Resilience',
    shortTitle: 'Resilience',
    progress: 0,
    status: 'upcoming' as const
  },
  { 
    id: 7,
    title: 'Preparing for Maintenance & Long-Term Success',
    shortTitle: 'Long-Term Success',
    progress: 0,
    status: 'upcoming' as const
  },
  { 
    id: 8,
    title: 'Maintenance, Reflection & Future Planning',
    shortTitle: 'Future Planning',
    progress: 0,
    status: 'upcoming' as const
  }
];

export default function ModuleProgress() {
  const { isOpen, onToggle } = useDisclosure({ defaultIsOpen: true });

  return (
    <Box bg="white" rounded="lg" shadow="sm" p={4}>
      <Button
        variant="ghost"
        width="full"
        onClick={onToggle}
        display="flex"
        justifyContent="space-between"
        alignItems="center"
        mb={isOpen ? 4 : 0}
      >
        <Text fontWeight="medium">8-Week CBT Program Progress</Text>
        <Icon as={isOpen ? FiChevronDown : FiChevronRight} />
      </Button>

      <Collapse in={isOpen}>
        <VStack spacing={3} align="stretch">
          {MODULES.map((module) => (
            <Box key={module.id}>
              <Tooltip label={module.title} placement="right">
                <Box>
                  <Flex align="center" justify="space-between" mb={1}>
                    <Text fontSize="xs" color="gray.600" noOfLines={1} flex="1">
                      {module.shortTitle}
                    </Text>
                    <Text fontSize="xs" color="gray.600" ml={2}>
                      {module.progress}%
                    </Text>
                  </Flex>
                  <Progress
                    value={module.progress}
                    size="sm"
                    colorScheme="purple"
                    borderRadius="full"
                  />
                </Box>
              </Tooltip>
            </Box>
          ))}
        </VStack>
      </Collapse>
    </Box>
  );
}