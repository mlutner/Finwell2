import {
  Box,
  Button,
  Heading,
  HStack,
  Text,
  VStack,
} from '@chakra-ui/react';

interface MoodButtonProps {
  label: string;
  onClick: () => void;
}

function MoodButton({ label, onClick }: MoodButtonProps) {
  return (
    <VStack spacing={1}>
      <Button
        w="12"
        h="12"
        rounded="full"
        variant="ghost"
        _hover={{ bg: 'purple.100' }}
        onClick={onClick}
      >
        {/* Add mood emoji based on label */}
        {label === 'Great' && '😄'}
        {label === 'Good' && '🙂'}
        {label === 'Ok' && '😐'}
        {label === 'Low' && '😕'}
        {label === 'Bad' && '😢'}
      </Button>
      <Text fontSize="sm" color="gray.600">{label}</Text>
    </VStack>
  );
}

export default function MoodTracker() {
  const handleMoodSelect = (mood: string) => {
    // TODO: Implement mood tracking
    console.log('Selected mood:', mood);
  };

  return (
    <Box bg="white" rounded="lg" shadow="sm" p={6}>
      <Heading size="md" mb={6}>How are you feeling?</Heading>
      <HStack justify="space-between">
        <MoodButton label="Bad" onClick={() => handleMoodSelect('Bad')} />
        <MoodButton label="Low" onClick={() => handleMoodSelect('Low')} />
        <MoodButton label="Ok" onClick={() => handleMoodSelect('Ok')} />
        <MoodButton label="Good" onClick={() => handleMoodSelect('Good')} />
        <MoodButton label="Great" onClick={() => handleMoodSelect('Great')} />
      </HStack>
    </Box>
  );
}