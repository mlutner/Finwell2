import { useState } from 'react';
import {
  Box,
  Container,
  VStack,
  useToast,
  Progress,
  Text,
  Flex,
} from '@chakra-ui/react';
import { useNavigate } from 'react-router-dom';
import InitialAssessment from '../components/assessment/InitialAssessment';
import EmotionalAssessment from '../components/assessment/EmotionalAssessment';
import FinancialAssessment from '../components/assessment/FinancialAssessment';
import AssessmentResults from '../components/assessment/AssessmentResults';
import AIChat from '../components/chat/AIChat';

export default function Assessment() {
  const [currentStep, setCurrentStep] = useState(1);
  const [assessmentData, setAssessmentData] = useState({});
  const toast = useToast();
  const navigate = useNavigate();

  const handleStepComplete = async (stepData: any) => {
    const updatedData = { ...assessmentData, ...stepData };
    setAssessmentData(updatedData);

    if (currentStep === 3) {
      // Generate mock analysis for now
      const analysis = {
        riskLevel: 'moderate',
        sentiment: 'neutral',
        emotionalTriggers: ['financial stress', 'impulsive spending'],
        recommendations: {
          cbt: ['Practice mindfulness', 'Challenge negative thoughts'],
          financial: ['Create a budget', 'Track expenses'],
          combined: ['Set realistic goals', 'Develop healthy habits']
        },
        suggestedModules: [
          'Financial Mindset Basics',
          'Emotional Spending Control',
          'Building Better Habits'
        ]
      };

      setAssessmentData(prev => ({ ...prev, analysis }));
      
      // Save assessment results
      localStorage.setItem('assessmentResults', JSON.stringify({
        data: updatedData,
        analysis,
        completedAt: new Date().toISOString()
      }));

      // Move to results
      setCurrentStep(prev => prev + 1);
    } else {
      setCurrentStep(prev => prev + 1);
    }
  };

  const steps = [
    'Initial Assessment',
    'Emotional Assessment',
    'Financial Assessment',
    'Results & Pathway'
  ];

  return (
    <Box minH="100vh" bg="gray.50" pt={20}>
      {/* Progress Bar */}
      <Box position="fixed" top="0" left="0" right="0" bg="white" shadow="sm" zIndex={10}>
        <Container maxW="3xl" py={4}>
          <Flex justify="space-between" mb={2}>
            <Text fontSize="sm" fontWeight="medium">Assessment Progress</Text>
            <Text fontSize="sm" fontWeight="medium">{currentStep} of {steps.length}</Text>
          </Flex>
          <Progress
            value={(currentStep / steps.length) * 100}
            size="sm"
            colorScheme="purple"
            borderRadius="full"
          />
          <Flex justify="space-between" mt={2}>
            {steps.map((step, index) => (
              <Text
                key={index}
                fontSize="xs"
                color={currentStep > index ? 'purple.500' : 'gray.500'}
                fontWeight={currentStep === index + 1 ? 'medium' : 'normal'}
              >
                {step}
              </Text>
            ))}
          </Flex>
        </Container>
      </Box>

      <Container maxW="3xl" py={8}>
        <VStack spacing={8} align="stretch">
          {currentStep === 1 && (
            <InitialAssessment onComplete={handleStepComplete} />
          )}
          {currentStep === 2 && (
            <EmotionalAssessment onComplete={handleStepComplete} />
          )}
          {currentStep === 3 && (
            <FinancialAssessment onComplete={handleStepComplete} />
          )}
          {currentStep === 4 && assessmentData.analysis && (
            <AssessmentResults 
              data={assessmentData}
              analysis={assessmentData.analysis}
              onComplete={() => navigate('/dashboard')}
            />
          )}
        </VStack>
      </Container>

      <AIChat
        context="assessment"
        initialMessage="Hi! I'm here to help you with the assessment. Feel free to ask any questions about the process."
        showExplainer={true}
      />
    </Box>
  );
}