import {
  Box,
  Container,
  Grid,
  Heading,
  Text,
  VStack,
  Flex,
  Button,
  Progress,
  SimpleGrid,
  Card,
  CardBody,
} from '@chakra-ui/react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import MetricsCard from '../components/dashboard/MetricsCard';
import MoodTracker from '../components/dashboard/MoodTracker';
import QuickActions from '../components/dashboard/QuickActions';
import SpendingGraph from '../components/dashboard/SpendingGraph';
import LearningPathways from '../components/dashboard/LearningPathways';
import AIChat from '../components/chat/AIChat';
import BankSync from '../components/dashboard/BankSync';
import ModuleProgress from '../components/dashboard/ModuleProgress';

export default function Dashboard() {
  const [currentMood, setCurrentMood] = useState<string | null>(null);
  const navigate = useNavigate();
  const hasStartedJourney = localStorage.getItem('assignedPathway');

  const handleMoodSelect = (mood: string) => {
    setCurrentMood(mood);
  };

  const handleStartJourney = () => {
    navigate('/assessment');
  };

  return (
    <Container maxW="container.xl" py={8}>
      <VStack spacing={8} align="stretch">
        {/* Header Section */}
        <Grid templateColumns={{ base: '1fr', md: '2fr 1fr' }} gap={6}>
          <Box>
            <Heading size="lg" mb={2}>Dashboard</Heading>
            <Text color="gray.600" mb={6}>
              Welcome back! Here's your financial wellness overview.
            </Text>
            {!hasStartedJourney && (
              <Button
                size="lg"
                colorScheme="purple"
                bgGradient="linear(to-r, purple.500, blue.500)"
                _hover={{
                  bgGradient: "linear(to-r, purple.600, blue.600)",
                }}
                onClick={handleStartJourney}
                mb={4}
              >
                Start Your Wellbeing Journey
              </Button>
            )}
          </Box>
          <Box>
            <BankSync />
          </Box>
        </Grid>

        {/* Main Content */}
        <Grid templateColumns={{ base: '1fr', lg: '2fr 1fr' }} gap={6}>
          {/* Left Column */}
          <VStack spacing={6} align="stretch">
            <MetricsCard />
            <SpendingGraph />
          </VStack>

          {/* Right Column */}
          <VStack spacing={6} align="stretch">
            <ModuleProgress />
            <MoodTracker onMoodSelect={handleMoodSelect} />
            <QuickActions />
            <LearningPathways />
          </VStack>
        </Grid>

        {/* AI Chat */}
        <AIChat
          context="dashboard"
          initialMessage={
            currentMood === 'Bad' || currentMood === 'Low'
              ? "I noticed you're not feeling great. Would you like to talk about what's bothering you?"
              : "Welcome to your dashboard! I'm here to help you understand your financial wellness metrics and answer any questions."
          }
          showExplainer={true}
        />
      </VStack>
    </Container>
  );
}