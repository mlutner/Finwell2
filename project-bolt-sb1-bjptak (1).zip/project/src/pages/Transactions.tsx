import { Box, Heading } from '@chakra-ui/react'

function Transactions() {
  return (
    <Box>
      <Heading mb={6}>Transactions</Heading>
      {/* Transactions implementation will go here */}
    </Box>
  )
}

export default Transactions