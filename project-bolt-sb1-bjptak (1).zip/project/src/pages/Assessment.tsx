import { useState } from 'react';
import {
  Box,
  Container,
  IconButton,
  useDisclosure,
} from '@chakra-ui/react';
import { QuestionOutlineIcon } from '@chakra-ui/icons';
import AssessmentProgress from '../components/assessment/AssessmentProgress';
import FinancialAssessmentForm from '../components/assessment/FinancialAssessmentForm';

export default function Assessment() {
  const [currentStep, setCurrentStep] = useState(1);
  const { isOpen, onOpen, onClose } = useDisclosure();

  return (
    <Box minH="100vh" bg="gray.50" pt={24}>
      <AssessmentProgress
        currentStep={currentStep}
        totalSteps={4}
      />
      
      <Container maxW="3xl">
        <FinancialAssessmentForm
          onSubmit={(data) => {
            console.log('Assessment data:', data);
            setCurrentStep(currentStep + 1);
          }}
        />
      </Container>

      <IconButton
        aria-label="Get help"
        icon={<QuestionOutlineIcon />}
        position="fixed"
        bottom={6}
        right={6}
        size="lg"
        colorScheme="purple"
        rounded="full"
        shadow="lg"
        onClick={onOpen}
      />
    </Box>
  );
}