import {
  Box,
  Button,
  Container,
  Flex,
  Grid,
  Heading,
  Progress,
  Text,
  VStack,
  useDisclosure,
} from '@chakra-ui/react';
import MetricsCard from '../components/dashboard/MetricsCard';
import MoodTracker from '../components/dashboard/MoodTracker';
import QuickActions from '../components/dashboard/QuickActions';
import SpendingGraph from '../components/dashboard/SpendingGraph';
import LearningPathways from '../components/dashboard/LearningPathways';
import AITherapist from '../components/dashboard/AITherapist';
import { useAuth } from '../contexts/AuthContext';

export default function Dashboard() {
  const { user } = useAuth();
  const { isOpen, onOpen, onClose } = useDisclosure();
  const isNewUser = false; // TODO: Implement new user detection

  return (
    <Container maxW="container.xl" py={8}>
      <VStack spacing={8} align="stretch">
        {/* Header */}
        <Box>
          <Heading size="lg" mb={2}>Dashboard</Heading>
          <Text color="gray.600">
            Welcome back! Here's your financial wellness overview.
          </Text>
        </Box>

        {/* Main Content */}
        <Grid templateColumns={{ base: '1fr', lg: '2fr 1fr' }} gap={6}>
          {/* Left Column */}
          <VStack spacing={6} align="stretch">
            <MetricsCard />
            <SpendingGraph />
          </VStack>

          {/* Right Column */}
          <VStack spacing={6} align="stretch">
            <MoodTracker />
            <QuickActions />
            <LearningPathways />
          </VStack>
        </Grid>

        {/* AI Therapist Chat */}
        <AITherapist isOpen={isOpen} onClose={onClose} />

        {/* Start Journey Button - For new users */}
        {isNewUser && (
          <Flex position="fixed" bottom={6} left="50%" transform="translateX(-50%)" zIndex={50}>
            <Button
              size="lg"
              colorScheme="purple"
              px={8}
              rounded="full"
              bgGradient="linear(to-r, purple.500, blue.500)"
              _hover={{
                bgGradient: "linear(to-r, purple.600, blue.600)",
              }}
              onClick={onOpen}
            >
              Start Your Journey
            </Button>
          </Flex>
        )}
      </VStack>
    </Container>
  );
}