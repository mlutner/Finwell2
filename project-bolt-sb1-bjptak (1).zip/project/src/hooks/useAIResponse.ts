import { useState } from 'react';
import { getAIResponse } from '../lib/cache/aiResponses';

interface UseAIResponseOptions<T> {
  onSuccess?: (data: T) => void;
  onError?: (error: Error) => void;
}

export function useAIResponse<T>(
  generateResponse: () => Promise<T>,
  options: UseAIResponseOptions<T> = {}
) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<Error | null>(null);
  const [loading, setLoading] = useState(false);

  const execute = async (prompt: string) => {
    try {
      setLoading(true);
      setError(null);
      
      const response = await getAIResponse<T>(prompt, generateResponse);
      setData(response);
      options.onSuccess?.(response);
      
      return response;
    } catch (err) {
      const error = err instanceof Error ? err : new Error('Unknown error occurred');
      setError(error);
      options.onError?.(error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  return {
    execute,
    data,
    error,
    loading,
  };
}</content>