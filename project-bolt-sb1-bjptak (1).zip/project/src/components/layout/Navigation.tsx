import {
  Box,
  Flex,
  IconButton,
  Menu,
  MenuButton,
  MenuList,
  MenuItem,
  Avatar,
  Text,
  HStack,
  Divider,
} from '@chakra-ui/react';
import { FiSettings, FiUser, FiHelpCircle, FiLogOut } from 'react-icons/fi';
import { useAuth } from '../../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

export default function Navigation() {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    try {
      await signOut();
      navigate('/signin');
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  return (
    <Box bg="white" px={4} borderBottom="1px" borderColor="gray.200">
      <Flex h={16} alignItems="center" justifyContent="flex-end">
        <HStack spacing={3}>
          <IconButton
            variant="ghost"
            aria-label="Settings"
            icon={<FiSettings />}
            rounded="full"
          />
          
          <Menu>
            <MenuButton>
              <HStack spacing={3} cursor="pointer">
                <Avatar
                  size="sm"
                  name={user?.email || 'User'}
                  src={user?.photoURL || undefined}
                  bg="purple.500"
                />
                <Box display={{ base: 'none', md: 'block' }}>
                  <Text fontWeight="medium" fontSize="sm">
                    {user?.email?.split('@')[0] || 'User'}
                  </Text>
                  <Text fontSize="xs" color="gray.500">
                    Free Plan
                  </Text>
                </Box>
              </HStack>
            </MenuButton>
            <MenuList>
              <MenuItem icon={<FiUser />}>Profile</MenuItem>
              <MenuItem icon={<FiSettings />}>Settings</MenuItem>
              <MenuItem icon={<FiHelpCircle />}>Help & Support</MenuItem>
              <Divider />
              <MenuItem icon={<FiLogOut />} onClick={handleSignOut}>
                Sign Out
              </MenuItem>
            </MenuList>
          </Menu>
        </HStack>
      </Flex>
    </Box>
  );
}