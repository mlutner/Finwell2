import {
  Box,
  Button,
  Card,
  CardBody,
  CardHeader,
  Heading,
  Progress,
  Radio,
  RadioGroup,
  Stack,
  Text,
  VStack,
  useToast,
} from '@chakra-ui/react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

interface Question {
  id: number;
  text: string;
  options: string[];
  selectedOption: string | null;
  category: 'emotional' | 'behavioral' | 'financial';
}

const questions: Question[] = [
  {
    id: 1,
    text: 'I often spend money impulsively when feeling stressed or anxious.',
    options: ['Never', 'Rarely', 'Sometimes', 'Often', 'Always'],
    selectedOption: null,
    category: 'emotional'
  },
  {
    id: 2,
    text: 'I track my expenses and follow a budget.',
    options: ['Never', 'Rarely', 'Sometimes', 'Often', 'Always'],
    selectedOption: null,
    category: 'behavioral'
  },
  {
    id: 3,
    text: 'Financial concerns affect my sleep or daily mood.',
    options: ['Never', 'Rarely', 'Sometimes', 'Often', 'Always'],
    selectedOption: null,
    category: 'emotional'
  },
  {
    id: 4,
    text: 'I have clear financial goals and a plan to achieve them.',
    options: ['Never', 'Rarely', 'Sometimes', 'Often', 'Always'],
    selectedOption: null,
    category: 'financial'
  },
  {
    id: 5,
    text: 'I use shopping as a way to feel better when I'm down.',
    options: ['Never', 'Rarely', 'Sometimes', 'Often', 'Always'],
    selectedOption: null,
    category: 'behavioral'
  }
];

export default function FinancialAssessment() {
  const [currentQuestions, setCurrentQuestions] = useState<Question[]>(questions);
  const [currentStep, setCurrentStep] = useState(1);
  const navigate = useNavigate();
  const toast = useToast();

  const handleOptionSelect = (questionId: number, value: string) => {
    setCurrentQuestions(prev =>
      prev.map(q =>
        q.id === questionId ? { ...q, selectedOption: value } : q
      )
    );
  };

  const calculateProgress = () => {
    const answered = currentQuestions.filter(q => q.selectedOption !== null).length;
    return (answered / currentQuestions.length) * 100;
  };

  const isStepComplete = () => {
    const currentQuestionSet = currentQuestions.slice((currentStep - 1) * 3, currentStep * 3);
    return currentQuestionSet.every(q => q.selectedOption !== null);
  };

  const handleNext = () => {
    if (currentStep * 3 >= currentQuestions.length) {
      // Calculate assessment results
      const results = analyzeResponses(currentQuestions);
      
      // Save results and navigate to recommendations
      navigate('/assessment/results', { state: { results } });
    } else {
      setCurrentStep(prev => prev + 1);
    }
  };

  const handlePrevious = () => {
    setCurrentStep(prev => Math.max(1, prev - 1));
  };

  const getCurrentQuestions = () => {
    const startIdx = (currentStep - 1) * 3;
    return currentQuestions.slice(startIdx, startIdx + 3);
  };

  return (
    <Card maxW="3xl" mx="auto" mt={8}>
      <CardHeader>
        <VStack spacing={4} align="stretch">
          <Heading size="lg">Financial Wellness Assessment</Heading>
          <Text color="gray.600">
            Step {currentStep} of {Math.ceil(currentQuestions.length / 3)}
          </Text>
          <Progress
            value={calculateProgress()}
            size="sm"
            colorScheme="purple"
            borderRadius="full"
          />
        </VStack>
      </CardHeader>

      <CardBody>
        <VStack spacing={8} align="stretch">
          {getCurrentQuestions().map((question) => (
            <Box key={question.id}>
              <Text mb={4} fontSize="lg" fontWeight="medium">
                {question.text}
              </Text>
              <RadioGroup
                value={question.selectedOption || ''}
                onChange={(value) => handleOptionSelect(question.id, value)}
              >
                <Stack spacing={4}>
                  {question.options.map((option) => (
                    <Radio
                      key={option}
                      value={option}
                      colorScheme="purple"
                      size="lg"
                    >
                      {option}
                    </Radio>
                  ))}
                </Stack>
              </RadioGroup>
            </Box>
          ))}

          <Stack direction="row" spacing={4} justify="space-between" mt={6}>
            <Button
              variant="ghost"
              onClick={handlePrevious}
              isDisabled={currentStep === 1}
            >
              Previous
            </Button>
            <Button
              colorScheme="purple"
              onClick={handleNext}
              isDisabled={!isStepComplete()}
            >
              {currentStep * 3 >= currentQuestions.length ? 'Complete' : 'Next'}
            </Button>
          </Stack>
        </VStack>
      </CardBody>
    </Card>
  );
}

function analyzeResponses(questions: Question[]): any {
  const scores = {
    emotional: 0,
    behavioral: 0,
    financial: 0
  };

  questions.forEach(q => {
    if (q.selectedOption) {
      const value = q.options.indexOf(q.selectedOption);
      scores[q.category] += value;
    }
  });

  return {
    scores,
    timestamp: new Date().toISOString(),
    recommendations: generateRecommendations(scores)
  };
}

function generateRecommendations(scores: any) {
  const recommendations = [];

  if (scores.emotional > 6) {
    recommendations.push({
      category: 'emotional',
      title: 'Emotional Spending Awareness',
      description: 'Your responses indicate a connection between emotions and spending habits.',
      actions: [
        'Practice mindfulness before making purchases',
        'Keep a mood and spending journal',
        'Develop alternative stress-relief activities'
      ]
    });
  }

  if (scores.behavioral > 6) {
    recommendations.push({
      category: 'behavioral',
      title: 'Building Healthy Habits',
      description: 'Focus on developing consistent financial behaviors.',
      actions: [
        'Set up automatic savings',
        'Create a realistic budget',
        'Track expenses daily'
      ]
    });
  }

  if (scores.financial > 6) {
    recommendations.push({
      category: 'financial',
      title: 'Financial Planning',
      description: 'Strengthen your financial foundation with clear goals.',
      actions: [
        'Define short and long-term financial goals',
        'Create an emergency fund',
        'Review and adjust your budget monthly'
      ]
    });
  }

  return recommendations;
}