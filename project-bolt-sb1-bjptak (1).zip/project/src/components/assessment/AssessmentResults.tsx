import {
  Box,
  Button,
  Card,
  CardBody,
  CardHeader,
  Heading,
  List,
  ListIcon,
  ListItem,
  Stack,
  Text,
  VStack,
} from '@chakra-ui/react';
import { CheckCircleIcon } from '@chakra-ui/icons';
import { useLocation, useNavigate } from 'react-router-dom';

export default function AssessmentResults() {
  const location = useLocation();
  const navigate = useNavigate();
  const { results } = location.state || { results: null };

  if (!results) {
    return (
      <Box textAlign="center" py={10}>
        <Text>No assessment results found.</Text>
        <Button
          onClick={() => navigate('/assessment')}
          colorScheme="purple"
          mt={4}
        >
          Take Assessment
        </Button>
      </Box>
    );
  }

  const { scores, recommendations } = results;

  return (
    <Box maxW="4xl" mx="auto" py={8}>
      <VStack spacing={8} align="stretch">
        <Card>
          <CardHeader>
            <Heading size="lg">Your Assessment Results</Heading>
          </CardHeader>
          <CardBody>
            <Stack spacing={6}>
              <Box>
                <Heading size="md" mb={4}>Overall Scores</Heading>
                <Stack spacing={4}>
                  {Object.entries(scores).map(([category, score]) => (
                    <Box key={category}>
                      <Text fontWeight="medium" mb={2} textTransform="capitalize">
                        {category} Score: {score}
                      </Text>
                      <Box
                        w="full"
                        h="2"
                        bg="gray.100"
                        borderRadius="full"
                        overflow="hidden"
                      >
                        <Box
                          h="full"
                          bg={score > 6 ? 'yellow.400' : 'green.400'}
                          borderRadius="full"
                          w={`${(Number(score) / 10) * 100}%`}
                        />
                      </Box>
                    </Box>
                  ))}
                </Stack>
              </Box>

              <Box>
                <Heading size="md" mb={4}>Recommendations</Heading>
                <Stack spacing={6}>
                  {recommendations.map((rec, index) => (
                    <Card key={index} variant="outline">
                      <CardBody>
                        <Heading size="sm" mb={2} color="purple.600">
                          {rec.title}
                        </Heading>
                        <Text mb={4}>{rec.description}</Text>
                        <List spacing={3}>
                          {rec.actions.map((action, actionIndex) => (
                            <ListItem
                              key={actionIndex}
                              display="flex"
                              alignItems="center"
                            >
                              <ListIcon
                                as={CheckCircleIcon}
                                color="green.500"
                              />
                              {action}
                            </ListItem>
                          ))}
                        </List>
                      </CardBody>
                    </Card>
                  ))}
                </Stack>
              </Box>
            </Stack>
          </CardBody>
        </Card>

        <Stack direction="row" spacing={4} justify="center">
          <Button
            colorScheme="purple"
            size="lg"
            onClick={() => navigate('/dashboard')}
          >
            Go to Dashboard
          </Button>
          <Button
            variant="outline"
            colorScheme="purple"
            size="lg"
            onClick={() => navigate('/learning-path')}
          >
            View Learning Path
          </Button>
        </Stack>
      </VStack>
    </Box>
  );
}