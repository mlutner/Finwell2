# FinWell - Financial Wellness Platform

A comprehensive financial wellness platform combining CBT techniques with AI-powered guidance.

## Features

- Financial wellbeing assessment
- Mood tracking and analysis
- Spending visualization
- AI-powered guidance
- CBT exercises and tools
- Learning pathways

## Getting Started

1. Clone the repository:
```bash
git clone https://github.com/yourusername/finwell.git
cd finwell
```

2. Install dependencies:
```bash
npm install
```

3. Create a `.env` file with your Firebase configuration:
```
VITE_FIREBASE_API_KEY=your_api_key
VITE_FIREBASE_AUTH_DOMAIN=your_auth_domain
VITE_FIREBASE_PROJECT_ID=your_project_id
VITE_FIREBASE_STORAGE_BUCKET=your_storage_bucket
VITE_FIREBASE_MESSAGING_SENDER_ID=your_messaging_sender_id
VITE_FIREBASE_APP_ID=your_app_id
VITE_FIREBASE_MEASUREMENT_ID=your_measurement_id
```

4. Start the development server:
```bash
npm run dev
```

## Project Structure

```
src/
├── components/        # Reusable UI components
├── contexts/         # React context providers
├── hooks/           # Custom React hooks
├── lib/             # Utility functions
├── pages/           # Main route components
└── types/           # TypeScript type definitions
```

## Technologies Used

- React + TypeScript
- Vite
- Chakra UI
- Firebase Auth
- Chart.js
- React Router DOM

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request