import {
  Box,
  Button,
  Container,
  Flex,
  Grid,
  Heading,
  Text,
  VStack,
  useDisclosure,
} from '@chakra-ui/react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FiUpload, FiBookOpen } from 'react-icons/fi';
import MetricsCard from '../components/dashboard/MetricsCard';
import MoodTracker from '../components/dashboard/MoodTracker';
import QuickActions from '../components/dashboard/QuickActions';
import SpendingGraph from '../components/dashboard/SpendingGraph';
import LearningPathways from '../components/dashboard/LearningPathways';
import BankImportModal from '../components/bank/BankImportModal';
import ConsultationSection from '../components/consultation/ConsultationSection';

export default function Dashboard() {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [currentMood, setCurrentMood] = useState<string | null>(null);
  const navigate = useNavigate();

  const handleMoodSelect = (mood: string) => {
    setCurrentMood(mood);
  };

  const handleCBTProgram = () => {
    navigate('/cbt-program');
  };

  return (
    <Container maxW="container.xl">
      <VStack spacing={6} align="stretch">
        {/* Header with Bank Import */}
        <Flex justify="space-between" align="center" pt={4}>
          <Box>
            <Heading size="lg" mb={1}>Dashboard</Heading>
            <Text color="gray.600">
              Welcome back! Here's your financial wellness overview.
            </Text>
          </Box>
          <Flex gap={4}>
            <Button
              leftIcon={<FiUpload />}
              colorScheme="purple"
              onClick={onOpen}
              size="lg"
              bgGradient="linear(to-r, purple.500, blue.500)"
              _hover={{
                bgGradient: "linear(to-r, purple.600, blue.600)",
              }}
            >
              Import Bank Data
            </Button>
            <Button
              leftIcon={<FiBookOpen />}
              colorScheme="blue"
              size="lg"
              onClick={handleCBTProgram}
              bgGradient="linear(to-r, blue.500, purple.500)"
              _hover={{
                bgGradient: "linear(to-r, blue.600, purple.600)",
              }}
            >
              Access CBT Pathway
            </Button>
          </Flex>
        </Flex>

        {/* Main Content */}
        <Grid templateColumns={{ base: '1fr', lg: '2fr 1fr' }} gap={6}>
          {/* Left Column */}
          <VStack spacing={6} align="stretch">
            <MetricsCard />
            <SpendingGraph />
            <ConsultationSection />
          </VStack>

          {/* Right Column */}
          <VStack spacing={6} align="stretch">
            <MoodTracker onMoodSelect={handleMoodSelect} />
            <QuickActions />
            <LearningPathways />
          </VStack>
        </Grid>

        {/* Bank Import Modal */}
        <BankImportModal isOpen={isOpen} onClose={onClose} />
      </VStack>
    </Container>
  );
}