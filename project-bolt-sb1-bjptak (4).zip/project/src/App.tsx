import { Box } from '@chakra-ui/react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import ErrorBoundary from './components/ErrorBoundary';
import Layout from './components/layout/Layout';
import Dashboard from './pages/Dashboard';
import Budget from './pages/Budget';
import Transactions from './pages/Transactions';
import Assessment from './pages/Assessment';
import CBTProgram from './pages/CBTProgram';
import SignIn from './components/auth/SignIn';
import SignUp from './components/auth/SignUp';

function PrivateRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  
  if (loading) {
    return null;
  }
  
  return user ? <>{children}</> : <Navigate to="/signin" />;
}

function App() {
  const { user } = useAuth();

  return (
    <ErrorBoundary>
      <Router>
        <Box minH="100vh" bg="gray.50">
          {user ? (
            <Layout>
              <Routes>
                <Route path="/" element={<Dashboard />} />
                <Route path="/budget" element={<Budget />} />
                <Route path="/transactions" element={<Transactions />} />
                <Route path="/assessment" element={<Assessment />} />
                <Route path="/cbt-program" element={<CBTProgram />} />
                <Route path="*" element={<Navigate to="/" />} />
              </Routes>
            </Layout>
          ) : (
            <Routes>
              <Route path="/signin" element={<SignIn />} />
              <Route path="/signup" element={<SignUp />} />
              <Route path="*" element={<Navigate to="/signin" />} />
            </Routes>
          )}
        </Box>
      </Router>
    </ErrorBoundary>
  );
}

function AppWithAuth() {
  return (
    <AuthProvider>
      <App />
    </AuthProvider>
  );
}

export default AppWithAuth;