import { useState } from 'react';
import {
  Box,
  Container,
  Flex,
  Heading,
  Text,
  Tabs,
  TabList,
  TabPanels,
  Tab,
  TabPanel,
  useDisclosure,
} from '@chakra-ui/react';
import ConsultationOverview from './ConsultationOverview';
import ConsultationBooking from './ConsultationBooking';
import { Professional } from '../../types/consultation';

export default function ConsultationDashboard() {
  const [selectedProfessional, setSelectedProfessional] = useState<Professional | null>(null);
  const { isOpen, onOpen, onClose } = useDisclosure();

  return (
    <Box minH="100vh" bg="gray.50">
      <Container maxW="container.xl" py={8}>
        <Flex justify="space-between" align="center" mb={8}>
          <Box>
            <Heading size="lg">Professional Support</Heading>
            <Text color="gray.600">Connect with financial wellness experts</Text>
          </Box>
        </Flex>

        <Tabs variant="enclosed" colorScheme="purple">
          <TabList>
            <Tab>Overview</Tab>
            <Tab>Book Consultation</Tab>
          </TabList>

          <TabPanels>
            <TabPanel>
              <ConsultationOverview onBooking={() => {}} />
            </TabPanel>
            <TabPanel>
              <ConsultationBooking />
            </TabPanel>
          </TabPanels>
        </Tabs>
      </Container>
    </Box>
  );
}