import {
  Box,
  Button,
  Card,
  CardBody,
  CardHeader,
  Flex,
  Heading,
  List,
  ListItem,
  Progress,
  Text,
  VStack,
  Icon,
  Badge,
} from '@chakra-ui/react';
import { FiCalendar, FiCheckCircle, FiClock, FiArrowLeft } from 'react-icons/fi';
import { CBTModule } from '../../types/cbt';

interface Props {
  module: CBTModule;
  onBack: () => void;
}

export default function ModuleDetail({ module, onBack }: Props) {
  return (
    <VStack spacing={6} align="stretch">
      <Button
        variant="ghost"
        leftIcon={<Icon as={FiArrowLeft} />}
        onClick={onBack}
        alignSelf="flex-start"
        _hover={{ transform: "translateX(-2px)" }}
        transition="all 0.2s"
      >
        Back to Modules
      </Button>

      <Card>
        <CardHeader>
          <Flex justify="space-between" align="start">
            <Box>
              <Badge mb={2}>Module {module.id}</Badge>
              <Badge
                ml={2}
                colorScheme={
                  module.status === 'completed' ? 'green' :
                  module.status === 'in-progress' ? 'purple' :
                  module.status === 'available' ? 'blue' : 'gray'
                }
              >
                {module.status}
              </Badge>
              <Heading size="lg" mt={2}>{module.title}</Heading>
              <Text color="gray.600" mt={2}>{module.description}</Text>
            </Box>
          </Flex>
        </CardHeader>

        <CardBody>
          <VStack spacing={6} align="stretch">
            {/* Module Info */}
            <Flex gap={6} bg="gray.50" p={4} rounded="lg">
              <Flex align="center" gap={2}>
                <Icon as={FiClock} color="purple.500" />
                <Box>
                  <Text fontSize="sm" color="gray.600">Duration</Text>
                  <Text fontWeight="medium">{module.duration}</Text>
                </Box>
              </Flex>
              <Flex align="center" gap={2}>
                <Icon as={FiCheckCircle} color="green.500" />
                <Box>
                  <Text fontSize="sm" color="gray.600">Progress</Text>
                  <Progress
                    value={module.progress}
                    size="sm"
                    width="100px"
                    colorScheme="purple"
                    rounded="full"
                  />
                </Box>
              </Flex>
            </Flex>

            {/* Exercises */}
            <Box>
              <Heading size="md" mb={4}>Module Exercises</Heading>
              <List spacing={4}>
                {module.exercises.map((exercise) => (
                  <ListItem
                    key={exercise.id}
                    p={4}
                    border="1px"
                    borderColor="gray.200"
                    rounded="lg"
                  >
                    <Flex justify="space-between" align="center">
                      <Box>
                        <Badge
                          colorScheme={
                            exercise.type === 'quiz' ? 'blue' :
                            exercise.type === 'journal' ? 'green' :
                            'purple'
                          }
                          mb={1}
                        >
                          {exercise.type}
                        </Badge>
                        <Text fontWeight="medium">{exercise.title}</Text>
                      </Box>
                      <Button
                        size="sm"
                        colorScheme={exercise.completed ? 'green' : 'purple'}
                        variant={exercise.completed ? 'outline' : 'solid'}
                      >
                        {exercise.completed ? 'Review' : 'Start'}
                      </Button>
                    </Flex>
                  </ListItem>
                ))}
              </List>
            </Box>

            {/* Support Section */}
            <Box bg="blue.50" p={4} rounded="lg">
              <Flex align="center" gap={3}>
                <Icon as={FiCalendar} color="blue.500" />
                <Box>
                  <Text fontWeight="medium" color="blue.700">
                    Need help with this module?
                  </Text>
                  <Text fontSize="sm" color="blue.600">
                    Schedule a consultation with our financial therapist
                  </Text>
                </Box>
                <Button
                  ml="auto"
                  colorScheme="blue"
                  variant="outline"
                  size="sm"
                >
                  Get Support
                </Button>
              </Flex>
            </Box>
          </VStack>
        </CardBody>
      </Card>
    </VStack>
  );
}