import {
  Box,
  Button,
  Circle,
  Flex,
  Heading,
  Progress,
  Stack,
  Text,
  VStack,
  Badge,
} from '@chakra-ui/react';
import { CheckIcon } from '@chakra-ui/icons';

interface ModuleStep {
  id: number;
  title: string;
  status: 'completed' | 'in-progress' | 'upcoming';
}

const steps: ModuleStep[] = [
  {
    id: 1,
    title: 'Thought Recognition',
    status: 'completed',
  },
  {
    id: 2,
    title: 'Emotional Awareness',
    status: 'in-progress',
  },
  {
    id: 3,
    title: 'Behavior Patterns',
    status: 'upcoming',
  },
];

export default function ModuleTracker() {
  const progress = 60;

  const getStepIcon = (step: ModuleStep) => {
    if (step.status === 'completed') {
      return (
        <Circle size="8" bg="green.500" color="white">
          <CheckIcon />
        </Circle>
      );
    }
    if (step.status === 'in-progress') {
      return (
        <Circle size="8" bg="blue.500" color="white">
          {step.id}
        </Circle>
      );
    }
    return (
      <Circle size="8" bg="gray.200" color="gray.600">
        {step.id}
      </Circle>
    );
  };

  const getStepStatus = (status: ModuleStep['status']) => {
    switch (status) {
      case 'completed':
        return 'Completed';
      case 'in-progress':
        return 'In Progress';
      case 'upcoming':
        return 'Upcoming';
      default:
        return '';
    }
  };

  return (
    <Box bg="white" rounded="lg" shadow="sm" p={6}>
      <VStack align="stretch" spacing={6}>
        <Flex justify="space-between" align="center">
          <Box>
            <Heading size="md" color="gray.900" mb={1}>
              Your CBT Journey
            </Heading>
            <Text color="gray.600" fontSize="sm">
              Module 1: Understanding Financial Thoughts
            </Text>
          </Box>
          <Badge
            colorScheme="blue"
            fontSize="sm"
            px={3}
            py={1}
            borderRadius="full"
          >
            {progress}% Complete
          </Badge>
        </Flex>

        <Progress
          value={progress}
          size="sm"
          colorScheme="blue"
          borderRadius="full"
        />

        <Stack spacing={4}>
          {steps.map((step) => (
            <Flex key={step.id} align="center" gap={3}>
              {getStepIcon(step)}
              <Box>
                <Text fontWeight="medium">{step.title}</Text>
                <Text fontSize="sm" color="gray.600">
                  {getStepStatus(step.status)}
                </Text>
              </Box>
            </Flex>
          ))}
        </Stack>

        <Button
          colorScheme="blue"
          size="lg"
          w="full"
          bgGradient="linear(to-r, blue.500, purple.500)"
          _hover={{
            bgGradient: "linear(to-r, blue.600, purple.600)",
          }}
        >
          Continue Module
        </Button>
      </VStack>
    </Box>
  );
}