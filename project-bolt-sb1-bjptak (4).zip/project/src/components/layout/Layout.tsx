import { Box } from '@chakra-ui/react';
import Sidebar from './Sidebar';
import Navigation from './Navigation';
import { useEffect, useState } from 'react';

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const [isCollapsed, setIsCollapsed] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem('sidebarCollapsed');
    if (stored) {
      setIsCollapsed(JSON.parse(stored));
    }
  }, []);

  useEffect(() => {
    const handleStorageChange = () => {
      const stored = localStorage.getItem('sidebarCollapsed');
      if (stored) {
        setIsCollapsed(JSON.parse(stored));
      }
    };

    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  return (
    <Box minH="100vh" bg="gray.50">
      <Sidebar />
      <Box
        ml={{ base: 0, md: isCollapsed ? '16' : '60' }}
        transition=".3s ease"
      >
        <Navigation />
        <Box p={8}>
          {children}
        </Box>
      </Box>
    </Box>
  );
}