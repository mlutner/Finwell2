import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalCloseButton,
  Text,
  VStack,
  Box,
  List,
  ListItem,
  ListIcon,
  Button,
  useToast,
} from '@chakra-ui/react';
import { FiCheck, FiLock, FiShield } from 'react-icons/fi';
import { useState } from 'react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export default function BankImportModal({ isOpen, onClose }: Props) {
  const [isConnecting, setIsConnecting] = useState(false);
  const toast = useToast();

  const handleConnect = async () => {
    setIsConnecting(true);
    try {
      // TODO: Implement actual bank connection logic
      await new Promise(resolve => setTimeout(resolve, 2000));
      toast({
        title: 'Bank connected successfully',
        description: 'Your transactions will be synced automatically',
        status: 'success',
        duration: 5000,
      });
      onClose();
    } catch (error) {
      toast({
        title: 'Connection failed',
        description: 'Please try again later',
        status: 'error',
        duration: 5000,
      });
    } finally {
      setIsConnecting(false);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} size="lg">
      <ModalOverlay />
      <ModalContent>
        <ModalHeader>Connect Your Bank Account</ModalHeader>
        <ModalCloseButton />
        <ModalBody pb={6}>
          <VStack spacing={6} align="stretch">
            <Text>
              Securely connect your bank account to automatically track your spending,
              set budgets, and get personalized insights.
            </Text>

            <Box bg="blue.50" p={4} rounded="lg">
              <Text fontWeight="medium" mb={2}>Why connect your bank?</Text>
              <List spacing={2}>
                <ListItem display="flex" alignItems="center">
                  <ListIcon as={FiCheck} color="green.500" />
                  Automatic transaction tracking
                </ListItem>
                <ListItem display="flex" alignItems="center">
                  <ListIcon as={FiCheck} color="green.500" />
                  Real-time spending insights
                </ListItem>
                <ListItem display="flex" alignItems="center">
                  <ListIcon as={FiCheck} color="green.500" />
                  Smart budgeting recommendations
                </ListItem>
              </List>
            </Box>

            <Box bg="gray.50" p={4} rounded="lg">
              <VStack spacing={3} align="stretch">
                <Box display="flex" alignItems="center" gap={2}>
                  <FiLock />
                  <Text fontWeight="medium">Bank-level Security</Text>
                </Box>
                <Text fontSize="sm" color="gray.600">
                  We use industry-leading encryption and security practices to keep
                  your data safe. We never store your bank credentials.
                </Text>
              </VStack>
            </Box>

            <Button
              colorScheme="purple"
              size="lg"
              onClick={handleConnect}
              isLoading={isConnecting}
              loadingText="Connecting..."
              leftIcon={<FiShield />}
              bgGradient="linear(to-r, purple.500, blue.500)"
              _hover={{
                bgGradient: "linear(to-r, purple.600, blue.600)",
              }}
            >
              Securely Connect Bank
            </Button>

            <Text fontSize="sm" color="gray.500" textAlign="center">
              By connecting your bank, you agree to our Terms of Service and Privacy Policy.
            </Text>
          </VStack>
        </ModalBody>
      </ModalContent>
    </Modal>
  );
}