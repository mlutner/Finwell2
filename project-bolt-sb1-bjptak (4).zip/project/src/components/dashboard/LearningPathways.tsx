import {
  Box,
  Button,
  Flex,
  Heading,
  Progress,
  Text,
  VStack,
  useDisclosure,
} from '@chakra-ui/react';
import { useNavigate } from 'react-router-dom';

interface PathwayCardProps {
  title: string;
  progress: number;
  status: string;
  onClick: () => void;
}

function PathwayCard({ title, progress, status, onClick }: PathwayCardProps) {
  return (
    <Flex
      justify="space-between"
      align="center"
      p={4}
      bg="gray.50"
      rounded="lg"
    >
      <Box flex={1}>
        <Text fontWeight="medium" mb={2}>{title}</Text>
        <Progress
          value={progress}
          size="sm"
          colorScheme="purple"
          rounded="full"
          w="32"
        />
      </Box>
      <Button
        variant="ghost"
        color="purple.600"
        _hover={{ color: 'purple.700' }}
        onClick={onClick}
      >
        {status}
      </Button>
    </Flex>
  );
}

export default function LearningPathways() {
  const navigate = useNavigate();
  const { isOpen, onOpen, onClose } = useDisclosure();

  const handleStartPathway = () => {
    navigate('/assessment');
  };

  const handleCBTPathway = () => {
    navigate('/cbt-program');
  };

  return (
    <Box bg="white" rounded="lg" shadow="sm" p={6}>
      <VStack spacing={6} align="stretch">
        <Heading size="md">Learning Pathways</Heading>
        
        {/* Start Pathway Button */}
        <Button
          w="full"
          size="lg"
          colorScheme="purple"
          bgGradient="linear(to-r, purple.500, blue.500)"
          _hover={{
            bgGradient: "linear(to-r, purple.600, blue.600)",
            transform: "translateY(-2px)",
          }}
          shadow="md"
          transition="all 0.2s"
          onClick={handleStartPathway}
        >
          Start Your Wellbeing Journey
        </Button>

        {/* CBT Pathway Button */}
        <Button
          w="full"
          size="lg"
          colorScheme="blue"
          bgGradient="linear(to-r, blue.500, purple.500)"
          _hover={{
            bgGradient: "linear(to-r, blue.600, purple.600)",
            transform: "translateY(-2px)",
          }}
          shadow="md"
          transition="all 0.2s"
          onClick={handleCBTPathway}
        >
          Continue Your CBT Pathway
        </Button>

        <Text fontSize="sm" color="gray.600" textAlign="center">
          Take the assessment and find your pathway
        </Text>

        <VStack spacing={4} align="stretch" mt={4}>
          <PathwayCard
            title="Introduction to FinWell"
            progress={100}
            status="Continue"
            onClick={() => navigate('/learning/intro')}
          />
          <PathwayCard
            title="Spending Tracker"
            progress={60}
            status="Continue"
            onClick={() => navigate('/learning/spending')}
          />
          <PathwayCard
            title="Financial Mindset"
            progress={0}
            status="Start"
            onClick={() => navigate('/learning/mindset')}
          />
        </VStack>
      </VStack>
    </Box>
  );
}