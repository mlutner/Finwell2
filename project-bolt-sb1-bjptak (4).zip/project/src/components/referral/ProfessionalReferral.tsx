import {
  Box,
  Button,
  Card,
  CardBody,
  CardHeader,
  Flex,
  Heading,
  Text,
  VStack,
  Badge,
  Avatar,
  Stack,
  useDisclosure,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalCloseButton,
  useToast,
} from '@chakra-ui/react';
import { FiVideo, FiPhone, FiMessageCircle, FiStar, FiCalendar } from 'react-icons/fi';
import { useState } from 'react';

interface Professional {
  id: string;
  name: string;
  title: string;
  specialties: string[];
  availability: string[];
  rating: number;
  imageUrl: string;
  bio: string;
  consultationTypes: ('video' | 'phone' | 'chat')[];
  nextAvailable: string;
}

interface Props {
  riskLevel?: 'low' | 'medium' | 'high';
  concerns?: string[];
}

export default function ProfessionalReferral({ riskLevel = 'medium', concerns = [] }: Props) {
  const [selectedPro, setSelectedPro] = useState<Professional | null>(null);
  const { isOpen, onOpen, onClose } = useDisclosure();
  const toast = useToast();

  // Mock data - in production, fetch from your backend
  const professionals: Professional[] = [
    {
      id: '1',
      name: 'Dr. Sarah Wilson',
      title: 'Financial Therapist',
      specialties: ['Anxiety', 'Spending Patterns', 'Debt Management'],
      availability: ['Mon', 'Wed', 'Fri'],
      rating: 4.9,
      imageUrl: '/placeholder.jpg',
      bio: 'Specializing in financial anxiety and behavior change with 10+ years experience.',
      consultationTypes: ['video', 'phone', 'chat'],
      nextAvailable: 'Tomorrow at 2 PM'
    },
    {
      id: '2',
      name: 'Michael Chen',
      title: 'Financial Counselor',
      specialties: ['Budgeting', 'Debt Relief', 'Financial Planning'],
      availability: ['Tue', 'Thu', 'Sat'],
      rating: 4.8,
      imageUrl: '/placeholder.jpg',
      bio: 'Focused on practical solutions for debt management and financial planning.',
      consultationTypes: ['video', 'phone'],
      nextAvailable: 'Today at 4 PM'
    }
  ];

  const handleSchedule = (pro: Professional) => {
    setSelectedPro(pro);
    onOpen();
  };

  const handleConfirmBooking = () => {
    toast({
      title: 'Consultation Scheduled',
      description: `Your consultation with ${selectedPro?.name} has been confirmed. Check your email for details.`,
      status: 'success',
      duration: 5000,
    });
    onClose();
  };

  return (
    <Box>
      <VStack spacing={6} align="stretch">
        <Box>
          <Heading size="lg" mb={2}>Professional Support</Heading>
          <Text color="gray.600">
            Connect with financial wellness experts matched to your needs
          </Text>
        </Box>

        {professionals.map((pro) => (
          <Card key={pro.id} variant="outline" _hover={{ shadow: 'md' }}>
            <CardBody>
              <Flex gap={4}>
                <Avatar name={pro.name} src={pro.imageUrl} size="lg" />
                
                <Box flex={1}>
                  <Flex justify="space-between" align="start" mb={2}>
                    <Box>
                      <Heading size="md">{pro.name}</Heading>
                      <Text color="gray.600">{pro.title}</Text>
                    </Box>
                    <Flex align="center" gap={1}>
                      <FiStar color="gold" />
                      <Text>{pro.rating}</Text>
                    </Flex>
                  </Flex>

                  <Stack direction="row" spacing={2} mb={4}>
                    {pro.specialties.map((specialty) => (
                      <Badge 
                        key={specialty}
                        colorScheme={concerns.includes(specialty) ? 'purple' : 'gray'}
                      >
                        {specialty}
                      </Badge>
                    ))}
                  </Stack>

                  <Text fontSize="sm" mb={4}>{pro.bio}</Text>

                  <Flex justify="space-between" align="center">
                    <Flex gap={2}>
                      {pro.consultationTypes.includes('video') && (
                        <FiVideo />
                      )}
                      {pro.consultationTypes.includes('phone') && (
                        <FiPhone />
                      )}
                      {pro.consultationTypes.includes('chat') && (
                        <FiMessageCircle />
                      )}
                    </Flex>

                    <Flex gap={4} align="center">
                      <Flex align="center" gap={2} color="gray.600">
                        <FiCalendar />
                        <Text fontSize="sm">{pro.nextAvailable}</Text>
                      </Flex>
                      <Button
                        colorScheme="purple"
                        onClick={() => handleSchedule(pro)}
                      >
                        Schedule Consultation
                      </Button>
                    </Flex>
                  </Flex>
                </Box>
              </Flex>
            </CardBody>
          </Card>
        ))}
      </VStack>

      {/* Scheduling Modal */}
      <Modal isOpen={isOpen} onClose={onClose} size="lg">
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>Schedule Consultation</ModalHeader>
          <ModalCloseButton />
          <ModalBody pb={6}>
            {selectedPro && (
              <VStack spacing={6} align="stretch">
                <Box>
                  <Heading size="sm" mb={2}>Select Consultation Type</Heading>
                  <Stack direction="row" spacing={4}>
                    {selectedPro.consultationTypes.map((type) => (
                      <Button
                        key={type}
                        variant="outline"
                        leftIcon={
                          type === 'video' ? <FiVideo /> :
                          type === 'phone' ? <FiPhone /> :
                          <FiMessageCircle />
                        }
                      >
                        {type.charAt(0).toUpperCase() + type.slice(1)}
                      </Button>
                    ))}
                  </Stack>
                </Box>

                <Box>
                  <Heading size="sm" mb={2}>Available Time Slots</Heading>
                  <Stack spacing={2}>
                    {selectedPro.availability.map((slot) => (
                      <Button key={slot} variant="outline">
                        {slot}
                      </Button>
                    ))}
                  </Stack>
                </Box>

                <Button
                  colorScheme="purple"
                  size="lg"
                  onClick={handleConfirmBooking}
                  mt={4}
                >
                  Confirm Booking
                </Button>
              </VStack>
            )}
          </ModalBody>
        </ModalContent>
      </Modal>
    </Box>
  );
}