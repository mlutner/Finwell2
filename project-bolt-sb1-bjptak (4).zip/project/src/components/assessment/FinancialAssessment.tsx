import {
  Box,
  Button,
  Card,
  CardBody,
  CardHeader,
  Heading,
  NumberInput,
  NumberInputField,
  FormControl,
  FormLabel,
  Select,
  Text,
  VStack,
  Spinner,
} from '@chakra-ui/react';
import { useState } from 'react';

interface Props {
  onComplete: (data: any) => void;
  isAnalyzing: boolean;
}

export default function FinancialAssessment({ onComplete, isAnalyzing }: Props) {
  const [data, setData] = useState({
    monthlyIncome: '',
    monthlyExpenses: '',
    savings: '',
    debt: '',
    financialGoals: '',
    riskTolerance: '',
    investmentExperience: ''
  });

  const handleChange = (field: string, value: string) => {
    setData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSubmit = () => {
    onComplete({
      financial: {
        ...data,
        timestamp: new Date().toISOString()
      }
    });
  };

  const isComplete = Object.values(data).every(value => value !== '');

  return (
    <Card>
      <CardHeader>
        <Heading size="lg">Financial Assessment</Heading>
        <Text mt={2} color="gray.600">
          Help us understand your financial situation
        </Text>
      </CardHeader>

      <CardBody>
        <VStack spacing={6} align="stretch">
          <FormControl>
            <FormLabel>Monthly Income</FormLabel>
            <NumberInput>
              <NumberInputField
                value={data.monthlyIncome}
                onChange={(e) => handleChange('monthlyIncome', e.target.value)}
                placeholder="Enter amount"
              />
            </NumberInput>
          </FormControl>

          <FormControl>
            <FormLabel>Monthly Expenses</FormLabel>
            <NumberInput>
              <NumberInputField
                value={data.monthlyExpenses}
                onChange={(e) => handleChange('monthlyExpenses', e.target.value)}
                placeholder="Enter amount"
              />
            </NumberInput>
          </FormControl>

          <FormControl>
            <FormLabel>Total Savings</FormLabel>
            <NumberInput>
              <NumberInputField
                value={data.savings}
                onChange={(e) => handleChange('savings', e.target.value)}
                placeholder="Enter amount"
              />
            </NumberInput>
          </FormControl>

          <FormControl>
            <FormLabel>Total Debt</FormLabel>
            <NumberInput>
              <NumberInputField
                value={data.debt}
                onChange={(e) => handleChange('debt', e.target.value)}
                placeholder="Enter amount"
              />
            </NumberInput>
          </FormControl>

          <FormControl>
            <FormLabel>Risk Tolerance</FormLabel>
            <Select
              placeholder="Select option"
              value={data.riskTolerance}
              onChange={(e) => handleChange('riskTolerance', e.target.value)}
            >
              <option value="low">Low</option>
              <option value="moderate">Moderate</option>
              <option value="high">High</option>
            </Select>
          </FormControl>

          <FormControl>
            <FormLabel>Investment Experience</FormLabel>
            <Select
              placeholder="Select option"
              value={data.investmentExperience}
              onChange={(e) => handleChange('investmentExperience', e.target.value)}
            >
              <option value="none">None</option>
              <option value="beginner">Beginner</option>
              <option value="intermediate">Intermediate</option>
              <option value="advanced">Advanced</option>
            </Select>
          </FormControl>

          <Button
            colorScheme="purple"
            size="lg"
            onClick={handleSubmit}
            isDisabled={!isComplete || isAnalyzing}
          >
            {isAnalyzing ? (
              <>
                <Spinner size="sm" mr={2} />
                Analyzing Responses...
              </>
            ) : (
              'Complete Assessment'
            )}
          </Button>
        </VStack>
      </CardBody>
    </Card>
  );
}