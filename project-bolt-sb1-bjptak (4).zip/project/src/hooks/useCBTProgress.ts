import { useState } from 'react';

interface ModuleProgress {
  id: string;
  title: string;
  progress: number;
  status: 'not-started' | 'in-progress' | 'completed';
}

export function useCBTProgress() {
  const [modules, setModules] = useState<ModuleProgress[]>([
    {
      id: 'intro',
      title: 'Introduction to FinWell',
      progress: 100,
      status: 'completed'
    },
    {
      id: 'spending',
      title: 'Spending Awareness',
      progress: 60,
      status: 'in-progress'
    },
    {
      id: 'mindset',
      title: 'Financial Mindset',
      progress: 0,
      status: 'not-started'
    }
  ]);

  const updateProgress = (moduleId: string, progress: number) => {
    setModules(prev => 
      prev.map(mod => 
        mod.id === moduleId 
          ? { 
              ...mod, 
              progress,
              status: progress === 100 ? 'completed' : 'in-progress'
            }
          : mod
      )
    );
  };

  return {
    modules,
    updateProgress
  };
}