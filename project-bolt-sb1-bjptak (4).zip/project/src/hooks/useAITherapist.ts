import { useState } from 'react';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  timestamp: Date;
  suggestions?: string[];
}

export function useAITherapist() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const sendMessage = async (text: string, context?: any) => {
    try {
      setIsLoading(true);
      
      // Add user message
      const userMessage: Message = {
        id: Date.now().toString(),
        text,
        sender: 'user',
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, userMessage]);

      // TODO: Implement AI response generation
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: 'This is a mock AI response',
        sender: 'ai',
        timestamp: new Date(),
        suggestions: ['Consider tracking your spending', 'Try a mindfulness exercise']
      };

      setMessages(prev => [...prev, aiResponse]);
      return aiResponse;
    } catch (error) {
      console.error('Error sending message:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  return {
    messages,
    sendMessage,
    isLoading
  };
}