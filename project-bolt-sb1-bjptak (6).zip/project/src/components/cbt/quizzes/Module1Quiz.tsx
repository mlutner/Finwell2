import {
  Box,
  Button,
  Card,
  CardBody,
  CardHeader,
  Heading,
  Radio,
  RadioGroup,
  Stack,
  Text,
  VStack,
  Progress,
  useToast,
} from '@chakra-ui/react';
import { useState } from 'react';

interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

const module1Questions: QuizQuestion[] = [
  {
    id: 1,
    question: "Which of the following is NOT a key component of a SMART financial goal?",
    options: [
      "Specific amounts and deadlines",
      "Measurable progress indicators",
      "Ambitious but unrealistic targets",
      "Time-bound milestones"
    ],
    correctAnswer: 2,
    explanation: "SMART goals should be Specific, Measurable, Achievable, Relevant, and Time-bound. Unrealistic targets contradict the 'Achievable' criterion."
  },
  {
    id: 2,
    question: "In the Stages of Change model, which stage involves actively taking steps toward behavior change?",
    options: [
      "Pre-contemplation",
      "Contemplation",
      "Preparation",
      "Action"
    ],
    correctAnswer: 3,
    explanation: "The Action stage is when individuals are actively modifying their behavior, experiences, or environment to overcome their problems."
  },
  {
    id: 3,
    question: "What is the primary purpose of the Confidence to Achieve Goals Log?",
    options: [
      "To track daily expenses",
      "To measure self-efficacy and belief in success",
      "To record past financial mistakes",
      "To list financial goals"
    ],
    correctAnswer: 1,
    explanation: "The Confidence Log helps assess your belief in your ability to achieve goals and identifies areas where you might need additional support."
  },
  {
    id: 4,
    question: "How does CBT approach financial wellness?",
    options: [
      "By focusing only on budgeting techniques",
      "By examining the connection between thoughts, feelings, and financial behaviors",
      "By providing loans and financial aid",
      "By ignoring emotional aspects of money management"
    ],
    correctAnswer: 1,
    explanation: "CBT examines how thoughts and feelings influence financial behaviors, helping create healthier patterns."
  }
];

interface Props {
  onComplete: (results: { score: number }) => void;
}

export default function Module1Quiz({ onComplete }: Props) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [showExplanation, setShowExplanation] = useState(false);
  const toast = useToast();

  const handleAnswer = (value: string) => {
    setAnswers(prev => ({
      ...prev,
      [currentQuestion]: parseInt(value)
    }));
    setShowExplanation(true);
  };

  const handleNext = () => {
    setShowExplanation(false);
    if (currentQuestion < module1Questions.length - 1) {
      setCurrentQuestion(prev => prev + 1);
    } else {
      const score = calculateScore();
      onComplete({ score });
    }
  };

  const calculateScore = () => {
    const correctAnswers = Object.entries(answers).filter(
      ([questionIndex, answer]) => 
        answer === module1Questions[parseInt(questionIndex)].correctAnswer
    ).length;
    return Math.round((correctAnswers / module1Questions.length) * 100);
  };

  const question = module1Questions[currentQuestion];
  const progress = ((currentQuestion + 1) / module1Questions.length) * 100;

  return (
    <Card>
      <CardHeader>
        <VStack spacing={4} align="stretch">
          <Heading size="md">Module 1 Quiz: Goal Setting & Assessment</Heading>
          <Progress
            value={progress}
            size="sm"
            colorScheme="purple"
            borderRadius="full"
          />
          <Text color="gray.600">
            Question {currentQuestion + 1} of {module1Questions.length}
          </Text>
        </VStack>
      </CardHeader>

      <CardBody>
        <VStack spacing={6} align="stretch">
          <Box>
            <Text fontSize="lg" fontWeight="medium" mb={4}>
              {question.question}
            </Text>

            <RadioGroup
              onChange={handleAnswer}
              value={answers[currentQuestion]?.toString()}
              isDisabled={showExplanation}
            >
              <Stack spacing={4}>
                {question.options.map((option, index) => (
                  <Radio
                    key={index}
                    value={index.toString()}
                    colorScheme="purple"
                    size="lg"
                  >
                    {option}
                  </Radio>
                ))}
              </Stack>
            </RadioGroup>
          </Box>

          {showExplanation && (
            <Box
              p={4}
              bg={
                answers[currentQuestion] === question.correctAnswer
                  ? 'green.50'
                  : 'red.50'
              }
              borderRadius="md"
            >
              <Text
                color={
                  answers[currentQuestion] === question.correctAnswer
                    ? 'green.700'
                    : 'red.700'
                }
                fontWeight="medium"
                mb={2}
              >
                {answers[currentQuestion] === question.correctAnswer
                  ? 'Correct!'
                  : 'Incorrect'}
              </Text>
              <Text color="gray.700">{question.explanation}</Text>
            </Box>
          )}

          {showExplanation && (
            <Button
              colorScheme="purple"
              onClick={handleNext}
              size="lg"
              w="full"
            >
              {currentQuestion === module1Questions.length - 1
                ? 'Complete Quiz'
                : 'Next Question'}
            </Button>
          )}
        </VStack>
      </CardBody>
    </Card>
  );
}