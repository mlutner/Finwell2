import {
  Box,
  Button,
  Container,
  Flex,
  Grid,
  Heading,
  Progress,
  Text,
  VStack,
  useDisclosure,
} from '@chakra-ui/react';
import { useState } from 'react';
import MetricsCard from './MetricsCard';
import MoodTracker from './MoodTracker';
import QuickActions from './QuickActions';
import SpendingGraph from './SpendingGraph';
import LearningPathways from './LearningPathways';
import AITherapist from './AITherapist';

export default function Dashboard() {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [currentMood, setCurrentMood] = useState<string | null>(null);
  const isNewUser = false; // TODO: Implement new user detection

  const handleMoodSelect = (mood: string) => {
    setCurrentMood(mood);
    // If mood is negative, open AI therapist
    if (mood === 'Bad' || mood === 'Low') {
      onOpen();
    }
  };

  return (
    <Container maxW="container.xl" py={8}>
      <VStack spacing={8} align="stretch">
        {/* Header */}
        <Box>
          <Heading size="lg" mb={2}>Dashboard</Heading>
          <Text color="gray.600">
            Welcome back! Here's your financial wellness overview.
          </Text>
        </Box>

        {/* Main Content */}
        <Grid templateColumns={{ base: '1fr', lg: '2fr 1fr' }} gap={6}>
          {/* Left Column */}
          <VStack spacing={6} align="stretch">
            <MetricsCard />
            <SpendingGraph />
          </VStack>

          {/* Right Column */}
          <VStack spacing={6} align="stretch">
            <MoodTracker onMoodSelect={handleMoodSelect} />
            <QuickActions />
            <LearningPathways />
          </VStack>
        </Grid>

        {/* AI Therapist Chat */}
        <AITherapist 
          isOpen={isOpen} 
          onClose={onClose}
          currentMood={currentMood}
        />

        {/* Start Journey Button - For new users */}
        {isNewUser && (
          <Flex position="fixed" bottom={6} left="50%" transform="translateX(-50%)" zIndex={50}>
            <Button
              size="lg"
              colorScheme="purple"
              px={8}
              rounded="full"
              bgGradient="linear(to-r, purple.500, blue.500)"
              _hover={{
                bgGradient: "linear(to-r, purple.600, blue.600)",
              }}
              onClick={onOpen}
            >
              Start Your Journey
            </Button>
          </Flex>
        )}
      </VStack>
    </Container>
  );
}