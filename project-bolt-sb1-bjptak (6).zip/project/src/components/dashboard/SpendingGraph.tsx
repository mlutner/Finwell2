import {
  Box,
  Heading,
  Select,
  ButtonGroup,
  Button,
  Flex,
} from '@chakra-ui/react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';
import { Line } from 'react-chartjs-2';
import { useState } from 'react';
import { motion } from 'framer-motion';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

const options = {
  responsive: true,
  maintainAspectRatio: false,
  animation: {
    duration: 1000,
    easing: 'easeInOutQuart',
  },
  plugins: {
    legend: {
      position: 'top' as const,
    },
  },
  scales: {
    y: {
      beginAtZero: true,
      grid: {
        color: 'rgba(0, 0, 0, 0.05)',
      },
      ticks: {
        callback: (value: number) => `$${value}`,
      },
    },
    x: {
      grid: {
        display: false,
      },
    },
  },
};

const labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];

const spendingData = {
  labels,
  datasets: [
    {
      label: 'Spending',
      data: [2100, 1800, 2300, 1900, 2100, 1700],
      borderColor: 'rgb(124, 58, 237)',
      backgroundColor: 'rgba(124, 58, 237, 0.5)',
      tension: 0.3,
    },
    {
      label: 'Budget',
      data: [2000, 2000, 2000, 2000, 2000, 2000],
      borderColor: 'rgb(45, 55, 72)',
      backgroundColor: 'rgba(45, 55, 72, 0.5)',
      borderDash: [5, 5],
      tension: 0,
    },
    {
      label: 'Stress Level',
      data: [65, 75, 85, 70, 60, 80],
      borderColor: 'rgb(239, 68, 68)',
      backgroundColor: 'rgba(239, 68, 68, 0.5)',
      tension: 0.3,
      hidden: true,
    }
  ],
};

const moodData = {
  labels,
  datasets: [
    {
      label: 'Mood Score',
      data: [85, 75, 82, 78, 90, 88],
      borderColor: 'rgb(72, 187, 120)',
      backgroundColor: 'rgba(72, 187, 120, 0.5)',
      tension: 0.3,
    },
    {
      label: 'Spending',
      data: [2100, 1800, 2300, 1900, 2100, 1700],
      borderColor: 'rgb(124, 58, 237)',
      backgroundColor: 'rgba(124, 58, 237, 0.5)',
      tension: 0.3,
      yAxisID: 'spending',
    }
  ],
};

const moodOptions = {
  ...options,
  scales: {
    ...options.scales,
    spending: {
      type: 'linear' as const,
      display: true,
      position: 'right' as const,
      grid: {
        drawOnChartArea: false,
      },
      ticks: {
        callback: (value: number) => `$${value}`,
      },
    },
  },
};

export default function SpendingGraph() {
  const [timeframe, setTimeframe] = useState('6months');
  const [view, setView] = useState<'spending' | 'mood'>('spending');

  return (
    <Box bg="white" rounded="lg" shadow="sm" p={6}>
      <Box mb={6}>
        <Heading size="md" mb={4}>Monthly Spending</Heading>
        <Flex justify="space-between" align="center">
          <Select 
            defaultValue="6months" 
            size="sm" 
            maxW="200px"
            onChange={(e) => setTimeframe(e.target.value)}
          >
            <option value="3months">Last 3 months</option>
            <option value="6months">Last 6 months</option>
            <option value="1year">Last year</option>
          </Select>
          <ButtonGroup size="sm" isAttached variant="outline">
            <Button
              onClick={() => setView('spending')}
              colorScheme={view === 'spending' ? 'purple' : 'gray'}
            >
              Spending & Stress
            </Button>
            <Button
              onClick={() => setView('mood')}
              colorScheme={view === 'mood' ? 'purple' : 'gray'}
            >
              Spending & Mood
            </Button>
          </ButtonGroup>
        </Flex>
      </Box>
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
      >
        <Box h="300px">
          <Line 
            options={view === 'spending' ? options : moodOptions} 
            data={view === 'spending' ? spendingData : moodData} 
          />
        </Box>
      </motion.div>
    </Box>
  );
}