import {
  Box,
  Button,
  Card,
  CardBody,
  CardHeader,
  Flex,
  Heading,
  HStack,
  Icon,
  Text,
  Textarea,
  VStack,
  Progress,
  useDisclosure,
} from '@chakra-ui/react';
import { useState } from 'react';
import { FiSmile, FiMeh, FiFrown, FiActivity } from 'react-icons/fi';
import { useMoodTracking } from '../../hooks/useMoodTracking';
import { useWearables } from '../../hooks/useWearables';
import type { MoodType } from '../../types/mood';

const MOODS: { type: MoodType; icon: any; label: string; color: string }[] = [
  { type: 'great', icon: FiSmile, label: 'Great', color: 'green.500' },
  { type: 'good', icon: FiSmile, label: 'Good', color: 'blue.500' },
  { type: 'neutral', icon: FiMeh, label: 'Neutral', color: 'gray.500' },
  { type: 'low', icon: FiFrown, label: 'Low', color: 'orange.500' },
  { type: 'bad', icon: FiFrown, label: 'Bad', color: 'red.500' },
];

export default function MoodTracker() {
  const [selectedMood, setSelectedMood] = useState<MoodType | null>(null);
  const [note, setNote] = useState('');
  const { addEntry, isLoading } = useMoodTracking();
  const { metrics } = useWearables();
  const { isOpen, onOpen, onClose } = useDisclosure();

  const handleSubmit = async () => {
    if (selectedMood) {
      await addEntry(selectedMood, note);
      setSelectedMood(null);
      setNote('');
      onClose();
    }
  };

  return (
    <Card>
      <CardHeader>
        <Heading size="md">How are you feeling?</Heading>
        <Text color="gray.600" mt={1}>
          Track your mood and stress levels
        </Text>
      </CardHeader>

      <CardBody>
        <VStack spacing={6}>
          <HStack spacing={4} justify="center">
            {MOODS.map(({ type, icon, label, color }) => (
              <Button
                key={type}
                onClick={() => setSelectedMood(type)}
                variant={selectedMood === type ? 'solid' : 'outline'}
                colorScheme={selectedMood === type ? color.split('.')[0] : 'gray'}
                size="lg"
                p={6}
              >
                <VStack>
                  <Icon as={icon} boxSize={6} />
                  <Text fontSize="sm">{label}</Text>
                </VStack>
              </Button>
            ))}
          </HStack>

          {metrics && (
            <Card bg="purple.50" p={4} w="full">
              <VStack align="stretch" spacing={3}>
                <Flex justify="space-between" align="center">
                  <Text fontWeight="medium">Current Stress Level</Text>
                  <HStack>
                    <Icon as={FiActivity} color="purple.500" />
                    <Text>{metrics.stressLevel}%</Text>
                  </HStack>
                </Flex>
                <Progress
                  value={metrics.stressLevel}
                  colorScheme={metrics.stressLevel > 70 ? 'red' : 'green'}
                  size="sm"
                  rounded="full"
                />
                <Text fontSize="sm" color="gray.600">
                  {metrics.stressLevel > 70 
                    ? 'High stress detected. Consider taking a break.'
                    : 'Stress levels are manageable.'}
                </Text>
              </VStack>
            </Card>
          )}

          {selectedMood && (
            <Box w="full">
              <Textarea
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="Add a note about how you're feeling..."
                resize="none"
                mb={4}
              />
              <Button
                colorScheme="purple"
                onClick={handleSubmit}
                isLoading={isLoading}
                w="full"
              >
                Save Entry
              </Button>
            </Box>
          )}
        </VStack>
      </CardBody>
    </Card>
  );
}