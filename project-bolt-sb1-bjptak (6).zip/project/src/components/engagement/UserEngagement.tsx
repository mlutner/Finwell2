import {
  Box,
  Button,
  Card,
  CardHeader,
  CardBody,
  Flex,
  Grid,
  Heading,
  Icon,
  Progress,
  SimpleGrid,
  Text,
  VStack,
} from '@chakra-ui/react';
import { FiStar } from 'react-icons/fi';

const UserEngagement = () => {
  return (
    <SimpleGrid columns={{ base: 1, md: 2 }} spacing={6}>
      <Card>
        <CardHeader>
          <Heading size="md">Today's Progress</Heading>
        </CardHeader>
        <CardBody>
          <VStack spacing={4}>
            <Flex
              p={3}
              bg="blue.50"
              rounded="lg"
              w="full"
              align="center"
              gap={3}
            >
              <Flex
                h={12}
                w={12}
                rounded="full"
                bg="blue.100"
                align="center"
                justify="center"
              >
                <Icon as={FiStar} boxSize={6} color="blue.600" />
              </Flex>
              <Box>
                <Text fontWeight="semibold" color="blue.900">7 Day Streak!</Text>
                <Text fontSize="sm" color="blue.700">Keep up the great work</Text>
              </Box>
            </Flex>

            <Grid templateColumns="repeat(3, 1fr)" gap={2} w="full">
              {[
                { title: 'Journal Entry', completed: true },
                { title: 'Module Progress', completed: false },
                { title: 'Mood Check', completed: true }
              ].map((goal) => (
                <Box
                  key={goal.title}
                  p={3}
                  border="1px"
                  borderColor="gray.200"
                  rounded="lg"
                  textAlign="center"
                >
                  <Text fontSize="sm" fontWeight="medium" color="gray.700" mb={2}>
                    {goal.title}
                  </Text>
                  <Icon
                    as={FiStar}
                    boxSize={5}
                    color={goal.completed ? "yellow.500" : "gray.300"}
                    fill={goal.completed ? "yellow.500" : "none"}
                  />
                </Box>
              ))}
            </Grid>

            <Box w="full">
              <Flex justify="space-between" mb={2}>
                <Text fontSize="sm" color="gray.600">Today's Progress</Text>
                <Text fontSize="sm" fontWeight="medium">67%</Text>
              </Flex>
              <Progress value={67} size="sm" colorScheme="purple" rounded="full" />
            </Box>
          </VStack>
        </CardBody>
      </Card>

      <VStack spacing={6}>
        <Card w="full">
          <CardHeader>
            <Heading size="md">Weekly Overview</Heading>
          </CardHeader>
          <CardBody>
            <VStack spacing={4}>
              <Flex justify="space-between" align="center" w="full">
                <Box>
                  <Text fontSize="sm" fontWeight="medium" color="gray.700">
                    Completed Tasks
                  </Text>
                  <Text fontSize="2xl" fontWeight="bold">12/15</Text>
                </Box>
                <Flex
                  h={12}
                  w={12}
                  rounded="full"
                  bg="green.100"
                  align="center"
                  justify="center"
                >
                  <Icon as={FiStar} boxSize={6} color="green.600" />
                </Flex>
              </Flex>
              
              <Progress value={80} size="sm" colorScheme="purple" w="full" />
              
              <Text fontSize="sm" color="gray.600">
                You're making great progress this week!
              </Text>
            </VStack>
          </CardBody>
        </Card>

        <Card w="full">
          <CardHeader>
            <Heading size="md">Achievement Unlocked!</Heading>
          </CardHeader>
          <CardBody>
            <VStack spacing={4}>
              <Flex
                h={16}
                w={16}
                rounded="full"
                bg="purple.100"
                align="center"
                justify="center"
              >
                <Icon as={FiStar} boxSize={8} color="purple.600" />
              </Flex>
              <Box textAlign="center">
                <Text fontWeight="semibold" color="gray.900">
                  Consistency Master
                </Text>
                <Text fontSize="sm" color="gray.600">
                  Completed activities 7 days in a row
                </Text>
              </Box>
              <Button variant="outline" w="full">
                View All Achievements
              </Button>
            </VStack>
          </CardBody>
        </Card>
      </VStack>
    </SimpleGrid>
  );
};

export default UserEngagement;