import { useState } from 'react';
import {
  Box,
  Button,
  FormControl,
  FormLabel,
  Textarea,
  VStack,
  Text,
} from '@chakra-ui/react';
import type { ThoughtRecord } from '../../types/exercises';

interface Props {
  onComplete: (data: Partial<ThoughtRecord>) => void;
  isLoading?: boolean;
}

export default function ThoughtInput({ onComplete, isLoading }: Props) {
  const [thought, setThought] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onComplete({ thought });
  };

  return (
    <Box as="form" onSubmit={handleSubmit}>
      <VStack spacing={4} align="stretch">
        <Text fontSize="lg" fontWeight="medium">
          What's on your mind? Record your thought below:
        </Text>
        
        <FormControl isRequired>
          <FormLabel>Thought</FormLabel>
          <Textarea
            value={thought}
            onChange={(e) => setThought(e.target.value)}
            placeholder="Describe your thought in detail..."
            minH="150px"
            isDisabled={isLoading}
          />
        </FormControl>

        <Button
          type="submit"
          colorScheme="blue"
          isDisabled={!thought.trim() || isLoading}
          isLoading={isLoading}
        >
          Continue
        </Button>
      </VStack>
    </Box>
  );
}</content>