import {
  Box,
  Container,
  Flex,
  IconButton,
  Menu,
  MenuButton,
  MenuList,
  MenuItem,
  Avatar,
  Text,
  HStack,
  Divider,
  useColorModeValue,
} from '@chakra-ui/react';
import { FiSettings, FiUser, FiHelpCircle, FiLogOut } from 'react-icons/fi';
import { useAuth } from '../../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import ThemeToggle from './ThemeToggle';

export default function Navigation() {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const bgColor = useColorModeValue('white', 'gray.800');
  const borderColor = useColorModeValue('gray.200', 'gray.700');

  const handleSignOut = async () => {
    try {
      await signOut();
      navigate('/signin');
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  return (
    <Box bg={bgColor} borderBottom="1px" borderColor={borderColor}>
      <Container maxW="container.xl">
        <Flex h={16} alignItems="center" justifyContent="space-between">
          {/* Logo/Brand */}
          <Text
            fontSize="xl"
            fontWeight="bold"
            bgGradient="linear(to-r, purple.500, blue.500)"
            bgClip="text"
          >
            FinWell
          </Text>

          {/* Right Side Navigation */}
          <HStack spacing={3}>
            <ThemeToggle />
            
            <IconButton
              variant="ghost"
              aria-label="Settings"
              icon={<FiSettings />}
              rounded="full"
              size="sm"
            />
            
            <Menu>
              <MenuButton>
                <HStack spacing={3} cursor="pointer">
                  <Avatar
                    size="sm"
                    name={user?.email || 'User'}
                    src={user?.photoURL || undefined}
                    bg="purple.500"
                  />
                  <Box display={{ base: 'none', md: 'block' }}>
                    <Text fontWeight="medium" fontSize="sm">
                      {user?.email?.split('@')[0] || 'User'}
                    </Text>
                    <Text fontSize="xs" color="gray.500">
                      Free Plan
                    </Text>
                  </Box>
                </HStack>
              </MenuButton>
              <MenuList
                shadow="lg"
                rounded="xl"
                p={2}
                minW="200px"
                border="1px"
                borderColor={borderColor}
              >
                <MenuItem
                  icon={<FiUser />}
                  rounded="lg"
                  _hover={{ bg: 'purple.50' }}
                >
                  Profile
                </MenuItem>
                <MenuItem
                  icon={<FiSettings />}
                  rounded="lg"
                  _hover={{ bg: 'purple.50' }}
                >
                  Settings
                </MenuItem>
                <MenuItem
                  icon={<FiHelpCircle />}
                  rounded="lg"
                  _hover={{ bg: 'purple.50' }}
                >
                  Help & Support
                </MenuItem>
                <Divider my={2} />
                <MenuItem
                  icon={<FiLogOut />}
                  rounded="lg"
                  _hover={{ bg: 'red.50', color: 'red.500' }}
                  onClick={handleSignOut}
                >
                  Sign Out
                </MenuItem>
              </MenuList>
            </Menu>
          </HStack>
        </Flex>
      </Container>
    </Box>
  );
}