import {
  Box,
  Flex,
  Text,
  IconButton,
  Icon,
  useDisclosure,
  Drawer,
  DrawerContent,
  VStack,
  Image,
  Tooltip,
} from '@chakra-ui/react';
import { Link, useLocation } from 'react-router-dom';
import {
  FiMenu,
  FiHome,
  FiBookOpen,
  FiTarget,
  FiDollarSign,
  FiPieChart,
  FiCalendar,
  FiX,
  FiChevronLeft,
  FiChevronRight,
} from 'react-icons/fi';
import { useEffect, useState } from 'react';

const NavItems = [
  { name: 'Dashboard', icon: FiHome, path: '/' },
  { name: 'Learning Path', icon: FiBookOpen, path: '/learning' },
  { name: 'Goals', icon: FiTarget, path: '/goals' },
  { name: 'Expenses', icon: FiDollarSign, path: '/expenses' },
  { name: 'Savings', icon: FiDollarSign, path: '/savings' },
  { name: 'Calendar', icon: FiCalendar, path: '/calendar' },
  { name: 'Analytics', icon: FiPieChart, path: '/analytics' },
];

interface SidebarContentProps {
  onClose: () => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
}

const SidebarContent = ({ onClose, isCollapsed, onToggleCollapse, ...rest }) => {
  const location = useLocation();

  return (
    <Box
      bg="white"
      borderRight="1px"
      borderRightColor="gray.200"
      w={isCollapsed ? '16' : { base: 'full', md: 60 }}
      pos="fixed"
      h="full"
      {...rest}
    >
      <Flex h="20" alignItems="center" mx={isCollapsed ? 2 : 8} justifyContent="space-between">
        {!isCollapsed && (
          <Flex alignItems="center">
            <Image src="/owl-logo.svg" h="8" mr={2} />
            <Text fontSize="2xl" fontWeight="bold" color="purple.600">
              FinWell
            </Text>
          </Flex>
        )}
        <IconButton
          display={{ base: 'flex', md: 'none' }}
          onClick={onClose}
          variant="ghost"
          aria-label="close menu"
          icon={<FiX />}
        />
        <IconButton
          display={{ base: 'none', md: 'flex' }}
          onClick={onToggleCollapse}
          variant="ghost"
          aria-label={isCollapsed ? 'expand menu' : 'collapse menu'}
          icon={isCollapsed ? <FiChevronRight /> : <FiChevronLeft />}
          size="sm"
        />
      </Flex>

      <VStack spacing={1} align="stretch">
        {NavItems.map((item) => (
          <Link key={item.name} to={item.path}>
            <Tooltip
              label={isCollapsed ? item.name : ''}
              placement="right"
              isDisabled={!isCollapsed}
            >
              <Flex
                align="center"
                p="4"
                mx={isCollapsed ? '2' : '4'}
                borderRadius="lg"
                role="group"
                cursor="pointer"
                bg={location.pathname === item.path ? 'purple.50' : 'transparent'}
                color={location.pathname === item.path ? 'purple.600' : 'gray.600'}
                _hover={{
                  bg: 'purple.50',
                  color: 'purple.600',
                }}
              >
                <Icon
                  mr={isCollapsed ? '0' : '4'}
                  fontSize="16"
                  as={item.icon}
                />
                {!isCollapsed && (
                  <Text fontSize="sm" fontWeight="medium">{item.name}</Text>
                )}
              </Flex>
            </Tooltip>
          </Link>
        ))}
      </VStack>

      {!isCollapsed && (
        <Box position="absolute" bottom="4" width="full">
          <Box mx="4" p="4" bg="blue.50" rounded="lg">
            <Text fontSize="sm" fontStyle="italic" color="gray.600" textAlign="center">
              "Financial wellness is a journey, not a destination."
            </Text>
          </Box>
        </Box>
      )}
    </Box>
  );
};

export default function Sidebar() {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [isCollapsed, setIsCollapsed] = useState(false);

  // Store collapse state in localStorage
  useEffect(() => {
    const stored = localStorage.getItem('sidebarCollapsed');
    if (stored) {
      setIsCollapsed(JSON.parse(stored));
    }
  }, []);

  const handleToggleCollapse = () => {
    const newState = !isCollapsed;
    setIsCollapsed(newState);
    localStorage.setItem('sidebarCollapsed', JSON.stringify(newState));
  };

  return (
    <Box>
      <IconButton
        display={{ base: 'flex', md: 'none' }}
        onClick={onOpen}
        variant="ghost"
        aria-label="open menu"
        icon={<FiMenu />}
        position="fixed"
        top="4"
        left="4"
        zIndex="modal"
      />
      <Box display={{ base: 'none', md: 'block' }}>
        <SidebarContent 
          onClose={() => {}} 
          isCollapsed={isCollapsed}
          onToggleCollapse={handleToggleCollapse}
        />
      </Box>
      <Drawer
        autoFocus={false}
        isOpen={isOpen}
        placement="left"
        onClose={onClose}
        returnFocusOnClose={false}
        onOverlayClick={onClose}
        size="full"
      >
        <DrawerContent>
          <SidebarContent 
            onClose={onClose} 
            isCollapsed={false}
            onToggleCollapse={() => {}}
          />
        </DrawerContent>
      </Drawer>
    </Box>
  );
}