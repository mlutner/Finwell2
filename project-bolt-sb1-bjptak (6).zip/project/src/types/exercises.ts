export interface ThoughtRecord {
  thought: string;
  emotions: Emotion[];
  behavior: string;
  analysis?: ThoughtAnalysis;
}

export interface Emotion {
  name: string;
  intensity: number;
}

export interface ThoughtAnalysis {
  distortions: string[];
  recommendations: string[];
  emotionalImpact: string;
}

export interface AIAnalysis {
  patterns: string[];
  suggestions: string;
  actions: string[];
}