import { useState, useCallback } from 'react';
import { useToast } from '@chakra-ui/react';
import OpenAI from 'openai';
import { getHuggingFaceResponse } from '../lib/ai/huggingface';
import { getCachedResponse, cacheResponse } from '../lib/ai/cache';
import { selectModel } from '../lib/ai/modelSelector';
import { config } from '../lib/ai/config';
import type { Message } from '../types/chat';

// Initialize OpenAI only if available
const openai = config.openai.available ? new OpenAI({
  apiKey: config.openai.apiKey,
  dangerouslyAllowBrowser: true
}) : null;

export function useAITherapist() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '0',
      text: "Hi! I'm your AI Financial Therapist. How can I help you today?",
      sender: 'ai',
      timestamp: new Date(),
    },
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const toast = useToast();

  const getAIResponse = async (prompt: string, context?: any) => {
    // Check cache first
    const cached = await getCachedResponse(prompt, context);
    if (cached) return cached.response;

    const { provider, model, temperature } = selectModel(prompt);

    try {
      let response: string;

      if (provider === 'openai' && openai) {
        const completion = await openai.chat.completions.create({
          model,
          messages: [
            { 
              role: 'system', 
              content: 'You are an empathetic AI Financial Therapist helping users with financial wellness and mental health.'
            },
            { role: 'user', content: prompt }
          ],
          temperature,
        });

        response = completion.choices[0].message?.content || '';
      } else {
        response = await getHuggingFaceResponse(prompt);
      }

      // Cache successful response
      await cacheResponse(prompt, response, provider, context);
      return response;
    } catch (error) {
      console.error(`${provider} API Error:`, error);
      throw error;
    }
  };

  const sendMessage = useCallback(async (text: string) => {
    try {
      setIsLoading(true);
      
      const userMessage: Message = {
        id: Date.now().toString(),
        text,
        sender: 'user',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, userMessage]);

      const aiResponse = await getAIResponse(text);
      
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: aiResponse,
        sender: 'ai',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, aiMessage]);

    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to get AI response. Please try again.',
        status: 'error',
        duration: 3000,
      });
    } finally {
      setIsLoading(false);
    }
  }, [toast]);

  return {
    messages,
    sendMessage,
    isLoading,
  };
}