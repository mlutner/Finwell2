import { z } from 'zod';

// Mock responses for development/demo mode
export const MOCK_RESPONSES = {
  therapist: [
    "I understand how challenging financial stress can be. Let's explore what's troubling you.",
    "That's a common concern. Have you noticed any patterns in when these feelings arise?",
    "It sounds like you're taking important steps to improve your financial wellness.",
    "Let's break this down into smaller, manageable steps.",
    "How does this financial situation make you feel emotionally?",
    "Would you like to explore some coping strategies for financial stress?",
    "I notice you're making progress. How do you feel about these changes?",
    "Let's focus on what you can control in this situation.",
  ],
};

const envSchema = z.object({
  VITE_OPENAI_API_KEY: z.string().optional(),
  VITE_HUGGINGFACE_API_KEY: z.string().optional(),
  VITE_USE_MOCK_AI: z.string().optional(),
});

// Validate environment variables
const env = envSchema.safeParse({
  VITE_OPENAI_API_KEY: import.meta.env.VITE_OPENAI_API_KEY,
  VITE_HUGGINGFACE_API_KEY: import.meta.env.VITE_HUGGINGFACE_API_KEY,
  VITE_USE_MOCK_AI: import.meta.env.VITE_USE_MOCK_AI,
});

interface AIConfig {
  useMockResponses: boolean;
  openai: {
    apiKey: string;
    defaultModel: string;
    maxTokens: number;
    available: boolean;
  };
  huggingface: {
    apiKey: string;
    defaultModel: string;
    available: boolean;
  };
}

export const config: AIConfig = {
  // Use mock responses if explicitly set or if no API keys are available
  useMockResponses: env.success && (
    env.data.VITE_USE_MOCK_AI === 'true' || 
    (!env.data.VITE_OPENAI_API_KEY && !env.data.VITE_HUGGINGFACE_API_KEY)
  ),
  openai: {
    apiKey: env.success ? env.data.VITE_OPENAI_API_KEY || '' : '',
    defaultModel: 'gpt-3.5-turbo',
    maxTokens: 150,
    available: env.success && Boolean(env.data.VITE_OPENAI_API_KEY)
  },
  huggingface: {
    apiKey: env.success ? env.data.VITE_HUGGINGFACE_API_KEY || '' : '',
    defaultModel: 'facebook/opt-350m',
    available: env.success && Boolean(env.data.VITE_HUGGINGFACE_API_KEY)
  }
};