import { config } from './config';
import { HfInference } from '@huggingface/inference';
import OpenAI from 'openai';

export async function testAPIs() {
  const results = {
    openai: false,
    huggingface: false
  };

  // Only test if API keys are provided
  if (config.openai.available) {
    try {
      const openai = new OpenAI({
        apiKey: config.openai.apiKey,
        dangerouslyAllowBrowser: true
      });

      const completion = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [{ role: "user", content: "Test" }],
        max_tokens: 5
      });

      results.openai = true;
      console.log("✅ OpenAI API is working");
    } catch (error) {
      console.log("ℹ️ OpenAI API not configured");
    }
  }

  if (config.huggingface.available) {
    try {
      const hf = new HfInference(config.huggingface.apiKey);
      
      await hf.textGeneration({
        model: config.huggingface.defaultModel,
        inputs: "Test",
        parameters: {
          max_new_tokens: 5
        }
      });

      results.huggingface = true;
      console.log("✅ Hugging Face API is working");
    } catch (error) {
      console.log("ℹ️ Hugging Face API not configured");
    }
  }

  return results;
}