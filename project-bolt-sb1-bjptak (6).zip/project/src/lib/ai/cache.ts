import { openDB } from 'idb';
import { hash } from 'object-hash';

const DB_NAME = 'finwell-ai';
const STORE_NAME = 'responses';
const CACHE_DURATION = 24 * 60 * 60 * 1000; // 24 hours for financial advice

interface CachedResponse {
  response: string;
  timestamp: number;
  usage: number;
  source: 'openai' | 'huggingface';
  context?: {
    mood?: string;
    stressLevel?: number;
  };
}

const db = await openDB(DB_NAME, 1, {
  upgrade(db) {
    db.createObjectStore(STORE_NAME);
  },
});

export async function getCachedResponse(
  prompt: string,
  context?: { mood?: string; stressLevel?: number }
): Promise<CachedResponse | null> {
  const key = hash({ prompt, context });
  const cached = await db.get(STORE_NAME, key);
  
  if (!cached) return null;
  if (Date.now() - cached.timestamp > CACHE_DURATION) {
    await db.delete(STORE_NAME, key);
    return null;
  }
  
  // Update usage counter
  await db.put(STORE_NAME, {
    ...cached,
    usage: cached.usage + 1
  }, key);
  
  return cached;
}

export async function cacheResponse(
  prompt: string, 
  response: string,
  source: 'openai' | 'huggingface',
  context?: { mood?: string; stressLevel?: number }
): Promise<void> {
  const key = hash({ prompt, context });
  await db.put(STORE_NAME, {
    response,
    timestamp: Date.now(),
    usage: 1,
    source,
    context
  }, key);
}

// Clear old cache entries
export async function cleanCache(): Promise<void> {
  const keys = await db.getAllKeys(STORE_NAME);
  const now = Date.now();
  
  for (const key of keys) {
    const entry = await db.get(STORE_NAME, key);
    if (entry && now - entry.timestamp > CACHE_DURATION) {
      await db.delete(STORE_NAME, key);
    }
  }
}