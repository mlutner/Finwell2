# FinWell - Financial Wellness Platform

A comprehensive financial wellness platform combining CBT techniques with AI-powered guidance.

## Quick Start

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

## Development

### Project Structure

The project follows a modular architecture with clear separation of concerns:

- `/src/components` - Reusable UI components
- `/src/contexts` - React context providers
- `/src/hooks` - Custom React hooks
- `/src/lib` - Utility functions and services
- `/src/pages` - Main route components
- `/src/types` - TypeScript type definitions

### Key Features

1. **Authentication**
   - Email/password login
   - Demo account access
   - Protected routes

2. **Dashboard**
   - Financial wellbeing score
   - Mood tracking
   - Spending visualization
   - Quick actions
   - Learning pathways

3. **CBT Integration**
   - Progressive thought record
   - AI analysis
   - Mood-spending correlation
   - Therapist chat interface

### Environment Variables

Create a `.env` file with the following:

```
VITE_FIREBASE_API_KEY=
VITE_FIREBASE_AUTH_DOMAIN=
VITE_FIREBASE_PROJECT_ID=
VITE_FIREBASE_STORAGE_BUCKET=
VITE_FIREBASE_MESSAGING_SENDER_ID=
VITE_FIREBASE_APP_ID=
VITE_FIREBASE_MEASUREMENT_ID=
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit changes
4. Push to the branch
5. Open a pull request