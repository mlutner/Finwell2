import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';

const firebaseConfig = {
  apiKey: "AIzaSyBv2OAfu3wO-Fa0a7azVrtEyAlKiJ1Rbqk",
  authDomain: "finwell-72e98.firebaseapp.com",
  projectId: "finwell-72e98",
  storageBucket: "finwell-72e98.firebasestorage.app",
  messagingSenderId: "858768264942",
  appId: "1:858768264942:web:ef563eebd38df2153f6dff",
  measurementId: "G-NL9GD38STX"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);