import { Box } from '@chakra-ui/react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import ErrorBoundary from './components/ErrorBoundary';
import Sidebar from './components/layout/Sidebar';
import Dashboard from './pages/Dashboard';
import Budget from './pages/Budget';
import Transactions from './pages/Transactions';
import Assessment from './pages/Assessment';
import SignIn from './components/auth/SignIn';
import SignUp from './components/auth/SignUp';

function PrivateRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  
  if (loading) {
    return null;
  }
  
  return user ? <>{children}</> : <Navigate to="/signin" />;
}

function App() {
  const { user } = useAuth();

  return (
    <ErrorBoundary>
      <Router>
        <Box minH="100vh" bg="gray.50">
          {user && <Sidebar />}
          <Box ml={user ? { base: 0, md: "240px" } : 0} transition=".3s ease">
            <Box p={8}>
              <Routes>
                <Route path="/signin" element={!user ? <SignIn /> : <Navigate to="/" />} />
                <Route path="/signup" element={!user ? <SignUp /> : <Navigate to="/" />} />
                <Route path="/" element={
                  <PrivateRoute>
                    <Dashboard />
                  </PrivateRoute>
                } />
                <Route path="/budget" element={
                  <PrivateRoute>
                    <Budget />
                  </PrivateRoute>
                } />
                <Route path="/transactions" element={
                  <PrivateRoute>
                    <Transactions />
                  </PrivateRoute>
                } />
                <Route path="/assessment" element={
                  <PrivateRoute>
                    <Assessment />
                  </PrivateRoute>
                } />
                <Route path="*" element={<Navigate to={user ? "/" : "/signin"} />} />
              </Routes>
            </Box>
          </Box>
        </Box>
      </Router>
    </ErrorBoundary>
  );
}

function AppWithAuth() {
  return (
    <AuthProvider>
      <App />
    </AuthProvider>
  );
}

export default AppWithAuth;