import { useState } from 'react';
import { Box, VStack, Tab, TabList, TabPanel, TabPanels, Tabs } from '@chakra-ui/react';
import FinancialAssessmentForm from '../components/assessment/FinancialAssessmentForm';
import MoodTracker from '../components/assessment/MoodTracker';
import type { FinancialAssessment, MoodEntry } from '../types/assessment';

function Assessment() {
  const handleAssessmentSubmit = (data: FinancialAssessment) => {
    // TODO: Save assessment data to Firebase
    console.log('Assessment submitted:', data);
  };

  const handleMoodSubmit = (entry: MoodEntry) => {
    // TODO: Save mood entry to Firebase
    console.log('Mood entry:', entry);
  };

  return (
    <Box>
      <Tabs isFitted variant="enclosed">
        <TabList mb="1em">
          <Tab>Financial Assessment</Tab>
          <Tab>Mood Tracker</Tab>
        </TabList>

        <TabPanels>
          <TabPanel>
            <FinancialAssessmentForm onSubmit={handleAssessmentSubmit} />
          </TabPanel>
          <TabPanel>
            <MoodTracker onSubmit={handleMoodSubmit} />
          </TabPanel>
        </TabPanels>
      </Tabs>
    </Box>
  );
}

export default Assessment;