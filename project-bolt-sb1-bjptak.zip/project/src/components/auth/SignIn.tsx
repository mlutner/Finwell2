import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { auth } from '../../config/firebase';
import { Link as RouterLink, useNavigate } from 'react-router-dom';
import {
  Box,
  Button,
  FormControl,
  FormLabel,
  Input,
  VStack,
  Text,
  useToast,
  FormErrorMessage,
  Heading,
  Image,
  Divider,
  Link,
  Center,
} from '@chakra-ui/react';

const schema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
});

type SignInForm = z.infer<typeof schema>;

const DEMO_CREDENTIALS = {
  email: 'demo@finwell.com',
  password: 'demo123456',
};

function SignIn() {
  const [loading, setLoading] = useState(false);
  const toast = useToast();
  const navigate = useNavigate();
  
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<SignInForm>({
    resolver: zodResolver(schema),
  });

  const handleDemoLogin = async () => {
    try {
      setLoading(true);
      await signInWithEmailAndPassword(auth, DEMO_CREDENTIALS.email, DEMO_CREDENTIALS.password);
      navigate('/');
    } catch (error) {
      toast({
        title: 'Error signing in',
        description: 'Demo account login failed. Please try again.',
        status: 'error',
        duration: 5000,
        isClosable: true,
      });
    } finally {
      setLoading(false);
    }
  };

  const onSubmit = async (data: SignInForm) => {
    try {
      setLoading(true);
      await signInWithEmailAndPassword(auth, data.email, data.password);
      navigate('/');
    } catch (error) {
      toast({
        title: 'Error signing in',
        description: 'Please check your credentials and try again.',
        status: 'error',
        duration: 5000,
        isClosable: true,
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box maxW="md" mx="auto" mt={8} p={8} borderRadius="lg" bg="white" boxShadow="sm">
      <VStack spacing={6} align="center">
        <Image src="/owl-logo.svg" alt="FinWell Logo" boxSize="80px" />
        
        <Heading as="h1" size="xl" color="purple.700">
          FinWell
        </Heading>
        
        <Text fontSize="lg" color="gray.600">
          Your Financial Wellness Journey
        </Text>

        <Heading as="h2" size="xl" color="navy.800">
          Welcome Back
        </Heading>

        <Text fontSize="lg" color="blue.600">
          Continue your journey to financial wellbeing
        </Text>

        <Button
          w="full"
          size="lg"
          colorScheme="purple"
          onClick={handleDemoLogin}
          isLoading={loading}
        >
          View Demo Dashboard
        </Button>

        <Center w="full" position="relative" py={4}>
          <Divider />
          <Text
            position="absolute"
            bg="white"
            px={4}
            color="gray.500"
          >
            OR CONTINUE WITH
          </Text>
        </Center>

        <form onSubmit={handleSubmit(onSubmit)} style={{ width: '100%' }}>
          <VStack spacing={4} w="full">
            <FormControl isInvalid={!!errors.email}>
              <FormLabel>Email</FormLabel>
              <Input
                type="email"
                placeholder="you@example.com"
                size="lg"
                {...register('email')}
              />
              <FormErrorMessage>{errors.email?.message}</FormErrorMessage>
            </FormControl>

            <FormControl isInvalid={!!errors.password}>
              <FormLabel>Password</FormLabel>
              <Input
                type="password"
                placeholder="••••••••"
                size="lg"
                {...register('password')}
              />
              <FormErrorMessage>{errors.password?.message}</FormErrorMessage>
            </FormControl>

            <Button
              type="submit"
              w="full"
              size="lg"
              colorScheme="purple"
              bgGradient="linear(to-r, blue.700, purple.500)"
              _hover={{
                bgGradient: "linear(to-r, blue.800, purple.600)",
              }}
              isLoading={loading}
            >
              Sign in with Email
            </Button>
          </VStack>
        </form>

        <Link color="purple.500" href="#" fontSize="sm">
          Forgot your password?
        </Link>

        <Text color="gray.600" fontSize="sm">
          Don't have an account?{' '}
          <Link as={RouterLink} to="/signup" color="purple.500">
            Sign up
          </Link>
        </Text>
      </VStack>
    </Box>
  );
}

export default SignIn;