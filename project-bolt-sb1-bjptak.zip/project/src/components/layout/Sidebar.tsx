import {
  Box,
  VStack,
  Icon,
  Text,
  Flex,
  Image,
  useColorModeValue,
  IconButton,
  Drawer,
  DrawerContent,
  useDisclosure,
} from '@chakra-ui/react';
import { Link, useLocation } from 'react-router-dom';
import {
  FiHome,
  FiTrendingUp,
  FiDollarSign,
  FiTarget,
  FiCalendar,
  FiPieChart,
  FiMenu,
  FiX,
} from 'react-icons/fi';
import { useAuth } from '../../contexts/AuthContext';

interface NavItemProps {
  icon: any;
  children: string;
  path: string;
  active?: boolean;
}

const NavItem = ({ icon, children, path, active }: NavItemProps) => {
  return (
    <Link to={path} style={{ width: '100%' }}>
      <Flex
        align="center"
        p="4"
        mx="4"
        borderRadius="lg"
        role="group"
        cursor="pointer"
        bg={active ? 'purple.500' : 'transparent'}
        color={active ? 'white' : 'inherit'}
        _hover={{
          bg: 'purple.500',
          color: 'white',
        }}
      >
        <Icon
          mr="4"
          fontSize="16"
          as={icon}
        />
        <Text fontSize="sm" fontWeight="medium">{children}</Text>
      </Flex>
    </Link>
  );
};

const SidebarContent = ({ onClose, ...rest }) => {
  const location = useLocation();
  const { user } = useAuth();

  const NavItems = [
    { name: 'Dashboard', icon: FiHome, path: '/' },
    { name: 'Learning Path', icon: FiTrendingUp, path: '/learning' },
    { name: 'Goals', icon: FiTarget, path: '/goals' },
    { name: 'Expenses', icon: FiDollarSign, path: '/expenses' },
    { name: 'Savings', icon: FiDollarSign, path: '/savings' },
    { name: 'Calendar', icon: FiCalendar, path: '/calendar' },
    { name: 'Analytics', icon: FiPieChart, path: '/analytics' },
  ];

  return (
    <Box
      bg={useColorModeValue('white', 'gray.900')}
      borderRight="1px"
      borderRightColor={useColorModeValue('gray.200', 'gray.700')}
      w={{ base: 'full', md: 60 }}
      pos="fixed"
      h="full"
      {...rest}
    >
      <Flex h="20" alignItems="center" mx="8" justifyContent="space-between">
        <Image src="/owl-logo.svg" h="8" />
        <Text fontSize="2xl" fontWeight="bold" color="purple.500">
          FinWell
        </Text>
        <IconButton
          display={{ base: 'flex', md: 'none' }}
          onClick={onClose}
          variant="ghost"
          aria-label="close menu"
          icon={<FiX />}
        />
      </Flex>

      <VStack spacing={1} align="stretch">
        {NavItems.map((item) => (
          <NavItem
            key={item.name}
            icon={item.icon}
            path={item.path}
            active={location.pathname === item.path}
          >
            {item.name}
          </NavItem>
        ))}
      </VStack>

      <Box position="absolute" bottom="4" width="full">
        <Flex
          align="center"
          p="4"
          mx="4"
          borderRadius="lg"
          role="group"
          cursor="pointer"
          _hover={{
            bg: 'purple.500',
            color: 'white',
          }}
        >
          <Image
            src={user?.photoURL || 'https://via.placeholder.com/40'}
            borderRadius="full"
            boxSize="8"
            mr="4"
          />
          <Text fontSize="sm" fontWeight="medium">
            {user?.displayName || user?.email}
          </Text>
        </Flex>
      </Box>
    </Box>
  );
};

export default function Sidebar() {
  const { isOpen, onOpen, onClose } = useDisclosure();

  return (
    <Box>
      <IconButton
        display={{ base: 'flex', md: 'none' }}
        onClick={onOpen}
        variant="ghost"
        aria-label="open menu"
        icon={<FiMenu />}
        position="fixed"
        top="4"
        left="4"
      />
      <Box display={{ base: 'none', md: 'block' }}>
        <SidebarContent onClose={() => {}} />
      </Box>
      <Drawer
        autoFocus={false}
        isOpen={isOpen}
        placement="left"
        onClose={onClose}
        returnFocusOnClose={false}
        onOverlayClick={onClose}
        size="full"
      >
        <DrawerContent>
          <SidebarContent onClose={onClose} />
        </DrawerContent>
      </Drawer>
    </Box>
  );
}