import { useState } from 'react';
import {
  Box,
  Button,
  FormControl,
  FormLabel,
  Textarea,
  VStack,
  Text,
} from '@chakra-ui/react';
import type { ThoughtAnalysis, ThoughtRecord } from '../../types/exercises';

interface Props {
  previousAnalysis: ThoughtAnalysis | null;
  onComplete: (data: Partial<ThoughtRecord>) => void;
}

export default function BehaviorInput({ previousAnalysis, onComplete }: Props) {
  const [behavior, setBehavior] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onComplete({ behavior });
  };

  return (
    <Box as="form" onSubmit={handleSubmit}>
      <VStack spacing={4} align="stretch">
        <Text fontSize="lg" fontWeight="medium">
          How did this thought affect your behavior?
        </Text>

        {previousAnalysis?.recommendations.map((rec, index) => (
          <Text key={index} color="gray.600">
            Consider: {rec}
          </Text>
        ))}

        <FormControl isRequired>
          <FormLabel>Behavior</FormLabel>
          <Textarea
            value={behavior}
            onChange={(e) => setBehavior(e.target.value)}
            placeholder="Describe what you did or plan to do..."
            minH="150px"
          />
        </FormControl>

        <Button
          type="submit"
          colorScheme="blue"
          isDisabled={!behavior.trim()}
        >
          Complete Record
        </Button>
      </VStack>
    </Box>
  );
}