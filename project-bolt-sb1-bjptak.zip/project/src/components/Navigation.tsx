import { Box, Flex, Link, Stack, Button } from '@chakra-ui/react';
import { Link as RouterLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { auth } from '../config/firebase';

function Navigation() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    try {
      await auth.signOut();
      navigate('/signin');
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  return (
    <Box bg="white" px={4} shadow="sm">
      <Flex h={16} alignItems="center" justifyContent="space-between">
        <Box fontWeight="bold" fontSize="xl">FinWell</Box>
        <Stack direction="row" spacing={4}>
          {user ? (
            <>
              <Link as={RouterLink} to="/" px={3} py={2} rounded="md" _hover={{ bg: 'gray.100' }}>
                Dashboard
              </Link>
              <Link as={RouterLink} to="/assessment" px={3} py={2} rounded="md" _hover={{ bg: 'gray.100' }}>
                Assessment
              </Link>
              <Link as={RouterLink} to="/budget" px={3} py={2} rounded="md" _hover={{ bg: 'gray.100' }}>
                Budget
              </Link>
              <Link as={RouterLink} to="/transactions" px={3} py={2} rounded="md" _hover={{ bg: 'gray.100' }}>
                Transactions
              </Link>
              <Button onClick={handleSignOut} variant="ghost">
                Sign Out
              </Button>
            </>
          ) : (
            <>
              <Link as={RouterLink} to="/signin" px={3} py={2} rounded="md" _hover={{ bg: 'gray.100' }}>
                Sign In
              </Link>
              <Link as={RouterLink} to="/signup" px={3} py={2} rounded="md" _hover={{ bg: 'gray.100' }}>
                Sign Up
              </Link>
            </>
          )}
        </Stack>
      </Flex>
    </Box>
  );
}

export default Navigation;