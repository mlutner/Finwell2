import {
  Box,
  Button,
  Flex,
  Heading,
  Progress,
  Text,
  VStack,
} from '@chakra-ui/react';

interface PathwayCardProps {
  title: string;
  progress: number;
  status: string;
  onClick: () => void;
}

function PathwayCard({ title, progress, status, onClick }: PathwayCardProps) {
  return (
    <Flex
      justify="space-between"
      align="center"
      p={4}
      bg="gray.50"
      rounded="lg"
    >
      <Box flex={1}>
        <Text fontWeight="medium" mb={2}>{title}</Text>
        <Progress
          value={progress}
          size="sm"
          colorScheme="purple"
          rounded="full"
          w="32"
        />
      </Box>
      <Button
        variant="ghost"
        color="purple.600"
        _hover={{ color: 'purple.700' }}
        onClick={onClick}
      >
        {status}
      </Button>
    </Flex>
  );
}

export default function LearningPathways() {
  return (
    <Box bg="white" rounded="lg" shadow="sm" p={6}>
      <Heading size="md" mb={6}>Learning Pathways</Heading>
      <VStack spacing={4} align="stretch">
        <PathwayCard
          title="Introduction to FinWell"
          progress={100}
          status="Continue"
          onClick={() => {}}
        />
        <PathwayCard
          title="Spending Tracker"
          progress={60}
          status="Continue"
          onClick={() => {}}
        />
        <PathwayCard
          title="Financial Mindset"
          progress={0}
          status="Start"
          onClick={() => {}}
        />
      </VStack>
    </Box>
  );
}