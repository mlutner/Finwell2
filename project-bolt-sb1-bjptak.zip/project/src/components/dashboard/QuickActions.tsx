import {
  Grid,
  Button,
  Icon,
  Text,
  VStack,
} from '@chakra-ui/react';
import { FiCamera, FiBook, FiPenTool, FiFileText } from 'react-icons/fi';

interface QuickActionProps {
  title: string;
  icon: React.ElementType;
  variant: string;
  onClick: () => void;
}

function QuickAction({ title, icon, variant, onClick }: QuickActionProps) {
  const bgColors = {
    purple: 'purple.50',
    blue: 'blue.50',
    green: 'green.50',
    yellow: 'yellow.50',
  };

  return (
    <Button
      p={4}
      h="auto"
      bg={bgColors[variant]}
      _hover={{ opacity: 0.8 }}
      onClick={onClick}
      variant="ghost"
    >
      <VStack spacing={2}>
        <Icon as={icon} boxSize={6} />
        <Text fontSize="sm" fontWeight="medium">{title}</Text>
      </VStack>
    </Button>
  );
}

export default function QuickActions() {
  return (
    <Grid templateColumns="repeat(2, 1fr)" gap={4}>
      <QuickAction
        title="Video Blog"
        icon={FiCamera}
        variant="purple"
        onClick={() => {}}
      />
      <QuickAction
        title="Resources"
        icon={FiBook}
        variant="blue"
        onClick={() => {}}
      />
      <QuickAction
        title="Journal"
        icon={FiPenTool}
        variant="green"
        onClick={() => {}}
      />
      <QuickAction
        title="Notes"
        icon={FiFileText}
        variant="yellow"
        onClick={() => {}}
      />
    </Grid>
  );
}