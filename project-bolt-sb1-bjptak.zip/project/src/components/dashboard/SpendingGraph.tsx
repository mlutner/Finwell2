import { Box, Heading, Select } from '@chakra-ui/react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';
import { Line } from 'react-chartjs-2';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

const options = {
  responsive: true,
  plugins: {
    legend: {
      position: 'top' as const,
    },
  },
  scales: {
    y: {
      beginAtZero: true,
      grid: {
        color: 'rgba(0, 0, 0, 0.05)',
      },
    },
    x: {
      grid: {
        display: false,
      },
    },
  },
};

const labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];

const data = {
  labels,
  datasets: [
    {
      label: 'Spending',
      data: [2100, 1800, 2300, 1900, 2100, 1700],
      borderColor: 'rgb(124, 58, 237)',
      backgroundColor: 'rgba(124, 58, 237, 0.5)',
      tension: 0.3,
    },
    {
      label: 'Budget',
      data: [2000, 2000, 2000, 2000, 2000, 2000],
      borderColor: 'rgb(45, 55, 72)',
      backgroundColor: 'rgba(45, 55, 72, 0.5)',
      borderDash: [5, 5],
      tension: 0,
    },
  ],
};

export default function SpendingGraph() {
  return (
    <Box bg="white" rounded="lg" shadow="sm" p={6}>
      <Box mb={6}>
        <Heading size="md" mb={4}>Monthly Spending</Heading>
        <Select defaultValue="6months" size="sm" maxW="200px">
          <option value="3months">Last 3 months</option>
          <option value="6months">Last 6 months</option>
          <option value="1year">Last year</option>
        </Select>
      </Box>
      <Box>
        <Line options={options} data={data} />
      </Box>
    </Box>
  );
}