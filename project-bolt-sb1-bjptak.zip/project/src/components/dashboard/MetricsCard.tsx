import {
  Box,
  CircularProgress,
  CircularProgressLabel,
  Grid,
  Heading,
  Text,
  VStack,
  Flex,
} from '@chakra-ui/react';

interface MetricBarProps {
  label: string;
  value: number;
  icon?: React.ReactNode;
}

function MetricBar({ label, value, icon }: MetricBarProps) {
  return (
    <VStack spacing={2} align="stretch">
      <Flex justify="space-between" align="center">
        <Text color="gray.600" fontSize="sm">{label}</Text>
        <Text fontWeight="medium">{value}%</Text>
      </Flex>
      <Box h="2" bg="gray.100" rounded="full" overflow="hidden">
        <Box
          h="full"
          bg="purple.500"
          rounded="full"
          transition="width 0.3s"
          w={`${value}%`}
        />
      </Box>
    </VStack>
  );
}

export default function MetricsCard() {
  const wellbeingScore = 78;

  return (
    <Box bg="white" rounded="lg" shadow="sm" p={6}>
      <VStack spacing={6} align="stretch">
        <Flex justify="space-between" align="center">
          <Box>
            <Heading size="md" mb={1}>Financial Wellbeing</Heading>
            <Flex gap={4}>
              <Text color="purple.600" fontWeight="medium">Score</Text>
              <Text color="gray.600">Mood vs. Spend</Text>
            </Flex>
          </Box>
        </Flex>

        <Flex justify="center" py={6}>
          <CircularProgress
            value={wellbeingScore}
            size="160px"
            thickness="8px"
            color="purple.500"
          >
            <CircularProgressLabel>
              <VStack spacing={0}>
                <Text fontSize="4xl" fontWeight="bold" lineHeight="1">
                  {wellbeingScore}
                </Text>
                <Text fontSize="sm" color="gray.500">/100</Text>
              </VStack>
            </CircularProgressLabel>
          </CircularProgress>
        </Flex>

        <Grid templateColumns="repeat(2, 1fr)" gap={4}>
          <MetricBar label="Mindset" value={80} />
          <MetricBar label="Resiliency" value={75} />
          <MetricBar label="Consistency" value={85} />
          <MetricBar label="Spending" value={70} />
        </Grid>
      </VStack>
    </Box>
  );
}