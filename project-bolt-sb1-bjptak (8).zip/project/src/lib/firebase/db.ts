import { getFirestore, collection, addDoc, updateDoc, doc, getDoc, getDocs, query, where, orderBy } from 'firebase/firestore';
import { auth } from '../../config/firebase';
import type { MoodEntry } from '../../types/mood';
import type { JournalEntry } from '../../types/journal';
import type { CBTModule } from '../../types/cbt';

const db = getFirestore();

// Collections
const COLLECTIONS = {
  moods: 'moods',
  journals: 'journals',
  progress: 'progress',
  assessments: 'assessments',
  userPreferences: 'userPreferences'
};

// Mood Tracking
export async function saveMoodEntry(entry: MoodEntry) {
  try {
    const userId = auth.currentUser?.uid;
    if (!userId) throw new Error('User not authenticated');

    const moodRef = await addDoc(collection(db, COLLECTIONS.moods), {
      ...entry,
      userId,
      createdAt: new Date().toISOString()
    });

    return moodRef.id;
  } catch (error) {
    console.error('Error saving mood entry:', error);
    throw error;
  }
}

export async function getMoodEntries(limit = 7) {
  try {
    const userId = auth.currentUser?.uid;
    if (!userId) throw new Error('User not authenticated');

    const moodsRef = collection(db, COLLECTIONS.moods);
    const q = query(
      moodsRef,
      where('userId', '==', userId),
      orderBy('createdAt', 'desc'),
      limit(limit)
    );

    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    })) as MoodEntry[];
  } catch (error) {
    console.error('Error getting mood entries:', error);
    throw error;
  }
}

// Journal Entries
export async function saveJournalEntry(entry: JournalEntry) {
  try {
    const userId = auth.currentUser?.uid;
    if (!userId) throw new Error('User not authenticated');

    const journalRef = await addDoc(collection(db, COLLECTIONS.journals), {
      ...entry,
      userId,
      createdAt: new Date().toISOString()
    });

    return journalRef.id;
  } catch (error) {
    console.error('Error saving journal entry:', error);
    throw error;
  }
}

export async function getJournalEntries(limit = 10) {
  try {
    const userId = auth.currentUser?.uid;
    if (!userId) throw new Error('User not authenticated');

    const journalsRef = collection(db, COLLECTIONS.journals);
    const q = query(
      journalsRef,
      where('userId', '==', userId),
      orderBy('createdAt', 'desc'),
      limit(limit)
    );

    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    })) as JournalEntry[];
  } catch (error) {
    console.error('Error getting journal entries:', error);
    throw error;
  }
}

// Module Progress
export async function updateModuleProgress(moduleId: string, progress: number) {
  try {
    const userId = auth.currentUser?.uid;
    if (!userId) throw new Error('User not authenticated');

    const progressRef = doc(db, COLLECTIONS.progress, `${userId}_${moduleId}`);
    const progressDoc = await getDoc(progressRef);

    if (progressDoc.exists()) {
      await updateDoc(progressRef, { progress, updatedAt: new Date().toISOString() });
    } else {
      await addDoc(collection(db, COLLECTIONS.progress), {
        userId,
        moduleId,
        progress,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });
    }
  } catch (error) {
    console.error('Error updating module progress:', error);
    throw error;
  }
}

export async function getModuleProgress(moduleId: string) {
  try {
    const userId = auth.currentUser?.uid;
    if (!userId) throw new Error('User not authenticated');

    const progressRef = doc(db, COLLECTIONS.progress, `${userId}_${moduleId}`);
    const progressDoc = await getDoc(progressRef);

    if (progressDoc.exists()) {
      return progressDoc.data();
    }
    return null;
  } catch (error) {
    console.error('Error getting module progress:', error);
    throw error;
  }
}

// Assessment Data
export async function saveAssessment(assessmentData: any) {
  try {
    const userId = auth.currentUser?.uid;
    if (!userId) throw new Error('User not authenticated');

    const assessmentRef = await addDoc(collection(db, COLLECTIONS.assessments), {
      ...assessmentData,
      userId,
      createdAt: new Date().toISOString()
    });

    return assessmentRef.id;
  } catch (error) {
    console.error('Error saving assessment:', error);
    throw error;
  }
}

export async function getLatestAssessment() {
  try {
    const userId = auth.currentUser?.uid;
    if (!userId) throw new Error('User not authenticated');

    const assessmentsRef = collection(db, COLLECTIONS.assessments);
    const q = query(
      assessmentsRef,
      where('userId', '==', userId),
      orderBy('createdAt', 'desc'),
      limit(1)
    );

    const querySnapshot = await getDocs(q);
    if (querySnapshot.empty) return null;

    return {
      id: querySnapshot.docs[0].id,
      ...querySnapshot.docs[0].data()
    };
  } catch (error) {
    console.error('Error getting latest assessment:', error);
    throw error;
  }
}

// User Preferences
export async function saveUserPreferences(preferences: any) {
  try {
    const userId = auth.currentUser?.uid;
    if (!userId) throw new Error('User not authenticated');

    const preferencesRef = doc(db, COLLECTIONS.userPreferences, userId);
    const preferencesDoc = await getDoc(preferencesRef);

    if (preferencesDoc.exists()) {
      await updateDoc(preferencesRef, { 
        ...preferences,
        updatedAt: new Date().toISOString() 
      });
    } else {
      await addDoc(collection(db, COLLECTIONS.userPreferences), {
        userId,
        ...preferences,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });
    }
  } catch (error) {
    console.error('Error saving user preferences:', error);
    throw error;
  }
}

export async function getUserPreferences() {
  try {
    const userId = auth.currentUser?.uid;
    if (!userId) throw new Error('User not authenticated');

    const preferencesRef = doc(db, COLLECTIONS.userPreferences, userId);
    const preferencesDoc = await getDoc(preferencesRef);

    if (preferencesDoc.exists()) {
      return preferencesDoc.data();
    }
    return null;
  } catch (error) {
    console.error('Error getting user preferences:', error);
    throw error;
  }
}