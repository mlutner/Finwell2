import { z } from 'zod';

// Mock responses for development/demo mode
export const MOCK_RESPONSES = {
  therapist: [
    "I understand how challenging financial stress can be. Let's explore what's troubling you.",
    "That's a common concern. Have you noticed any patterns in when these feelings arise?",
    "It sounds like you're taking important steps to improve your financial wellness.",
    "Let's break this down into smaller, manageable steps.",
    "How does this financial situation make you feel emotionally?",
    "Would you like to explore some coping strategies for financial stress?",
    "I notice you're making progress. How do you feel about these changes?",
    "Let's focus on what you can control in this situation.",
  ],
};

const envSchema = z.object({
  VITE_USE_MOCK_AI: z.string().optional(),
});

// Validate environment variables
const env = envSchema.safeParse({
  VITE_USE_MOCK_AI: import.meta.env.VITE_USE_MOCK_AI,
});

export const config = {
  useMockResponses: true, // Always use mock responses in this version
};