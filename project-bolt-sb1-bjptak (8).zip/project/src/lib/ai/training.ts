import { openDB } from 'idb';
import { HfInference } from '@huggingface/inference';
import type { Message } from '../../types/chat';

const TRAINING_DB = 'finwell-training';
const FEEDBACK_STORE = 'user-feedback';
const INTERACTIONS_STORE = 'interactions';

interface Feedback {
  messageId: string;
  rating: 1 | 2 | 3 | 4 | 5;
  comment?: string;
  timestamp: number;
}

interface Interaction {
  prompt: string;
  response: string;
  feedback?: Feedback;
  context: {
    mood?: string;
    stressLevel?: number;
    financialContext?: string;
  };
  timestamp: number;
}

const db = await openDB(TRAINING_DB, 1, {
  upgrade(db) {
    db.createObjectStore(FEEDBACK_STORE, { keyPath: 'messageId' });
    db.createObjectStore(INTERACTIONS_STORE, { 
      keyPath: 'id', 
      autoIncrement: true 
    });
  },
});

// Store interaction for training
export async function storeInteraction(
  prompt: string,
  response: string,
  context?: Interaction['context']
): Promise<void> {
  await db.add(INTERACTIONS_STORE, {
    prompt,
    response,
    context,
    timestamp: Date.now()
  });
}

// Store user feedback
export async function storeFeedback(feedback: Feedback): Promise<void> {
  await db.put(FEEDBACK_STORE, feedback);
  
  // Update interaction with feedback
  const interactions = await db.getAll(INTERACTIONS_STORE);
  const interaction = interactions.find(i => 
    i.response.includes(feedback.messageId)
  );
  
  if (interaction) {
    await db.put(INTERACTIONS_STORE, {
      ...interaction,
      feedback
    });
  }
}

// Fine-tune local model with collected data
export async function trainLocalModel(): Promise<void> {
  const interactions = await db.getAll(INTERACTIONS_STORE);
  const goodInteractions = interactions.filter(i => 
    i.feedback?.rating >= 4
  );

  if (goodInteractions.length < 100) {
    console.log('Not enough quality data for training yet');
    return;
  }

  const trainingData = goodInteractions.map(i => ({
    input: i.prompt,
    output: i.response,
    context: i.context
  }));

  // Use Hugging Face for fine-tuning
  const hf = new HfInference(process.env.VITE_HUGGINGFACE_API_KEY);
  
  try {
    await hf.translation({
      model: 'facebook/opt-350m',
      inputs: trainingData
    });
  } catch (error) {
    console.error('Training failed:', error);
  }
}