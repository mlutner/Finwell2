import { HfInference } from '@huggingface/inference';
import { config } from './config';

const hf = config.huggingface.available ? new HfInference(config.huggingface.apiKey) : null;

export async function getHuggingFaceResponse(prompt: string): Promise<string> {
  if (!hf || !config.huggingface.available) {
    throw new Error('Hugging Face API is not configured');
  }

  try {
    const result = await hf.textGeneration({
      model: config.huggingface.defaultModel,
      inputs: prompt,
      parameters: {
        max_new_tokens: 150,
        temperature: 0.7,
        top_p: 0.95,
        repetition_penalty: 1.2
      }
    });

    return result.generated_text;
  } catch (error) {
    console.error('Hugging Face API Error:', error);
    // Throw a user-friendly error
    throw new Error('Unable to get response from AI service');
  }
}