import { Box, Heading } from '@chakra-ui/react'

function Budget() {
  return (
    <Box>
      <Heading mb={6}>Budget</Heading>
      {/* Budget implementation will go here */}
    </Box>
  )
}

export default Budget