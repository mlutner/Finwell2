import {
  Box,
  Button,
  Drawer,
  DrawerBody,
  DrawerCloseButton,
  DrawerContent,
  DrawerHeader,
  Icon,
  Text,
  useDisclosure,
  VStack,
  Input,
  InputGroup,
  InputRightElement,
  IconButton,
  Spinner,
  useToast,
} from '@chakra-ui/react';
import { FiMessageSquare, FiSend } from 'react-icons/fi';
import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAITherapist } from '../../hooks/useAITherapist';
import { testAPIs } from '../../lib/ai/testApis';
import { config } from '../../lib/ai/config';

export default function FloatingChatButton() {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [message, setMessage] = useState('');
  const { messages, sendMessage, isLoading } = useAITherapist();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const toast = useToast();

  useEffect(() => {
    // Only show API status if not using mock responses
    if (!config.useMockResponses) {
      testAPIs().then(results => {
        if (!results.openai && !results.huggingface) {
          toast({
            title: 'Using Demo Mode',
            description: 'AI services are not configured. Using mock responses.',
            status: 'info',
            duration: 5000,
            isClosable: true,
          });
        }
      });
    }
  }, [toast]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!message.trim()) return;
    await sendMessage(message);
    setMessage('');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <AnimatePresence>
      <Box position="fixed" bottom={6} right={6} zIndex={1000}>
        {!isOpen ? (
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            exit={{ scale: 0 }}
          >
            <Button
              onClick={onOpen}
              colorScheme="purple"
              size="lg"
              rounded="full"
              leftIcon={<Icon as={FiMessageSquare} />}
              shadow="lg"
            >
              Chat with AI Therapist
            </Button>
          </motion.div>
        ) : (
          <Drawer
            isOpen={isOpen}
            placement="right"
            onClose={onClose}
            size="md"
          >
            <DrawerContent>
              <DrawerCloseButton />
              <DrawerHeader borderBottomWidth="1px">
                AI Financial Therapist
                {config.useMockResponses && (
                  <Text fontSize="sm" color="gray.500">Demo Mode</Text>
                )}
              </DrawerHeader>

              <DrawerBody>
                <VStack spacing={4} h="full">
                  <Box flex={1} w="full" overflowY="auto" py={4}>
                    {messages.map((msg) => (
                      <Box
                        key={msg.id}
                        alignSelf={msg.sender === 'user' ? 'flex-end' : 'flex-start'}
                        maxW="80%"
                        mb={4}
                      >
                        <Box
                          bg={msg.sender === 'user' ? 'purple.500' : 'gray.100'}
                          color={msg.sender === 'user' ? 'white' : 'gray.800'}
                          px={4}
                          py={2}
                          borderRadius="lg"
                        >
                          <Text>{msg.text}</Text>
                        </Box>
                      </Box>
                    ))}
                    <div ref={messagesEndRef} />
                  </Box>

                  <InputGroup size="lg">
                    <Input
                      pr="4.5rem"
                      placeholder="Type your message..."
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      onKeyPress={handleKeyPress}
                    />
                    <InputRightElement width="4.5rem">
                      <IconButton
                        h="1.75rem"
                        size="sm"
                        icon={isLoading ? <Spinner size="sm" /> : <FiSend />}
                        onClick={handleSend}
                        aria-label="Send message"
                        isDisabled={!message.trim() || isLoading}
                      />
                    </InputRightElement>
                  </InputGroup>
                </VStack>
              </DrawerBody>
            </DrawerContent>
          </Drawer>
        )}
      </Box>
    </AnimatePresence>
  );
}