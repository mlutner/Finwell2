import {
  SimpleGrid,
  Card,
  CardHeader,
  CardBody,
  Badge,
  Text,
  Progress,
  Box,
  VStack,
} from '@chakra-ui/react';
import { CBTModule } from '../../types/cbt';
import { modules } from '../../data/cbtModules';

interface Props {
  onSelectModule: (module: CBTModule) => void;
}

export default function ModuleGrid({ onSelectModule }: Props) {
  return (
    <SimpleGrid columns={{ base: 1, md: 2, lg: 3 }} spacing={6}>
      {modules.map((module) => (
        <Card
          key={module.id}
          onClick={() => module.status !== 'locked' && onSelectModule(module)}
          cursor={module.status === 'locked' ? 'not-allowed' : 'pointer'}
          opacity={module.status === 'locked' ? 0.5 : 1}
          transition="all 0.2s"
          _hover={{
            transform: module.status !== 'locked' ? 'translateY(-2px)' : 'none',
            shadow: module.status !== 'locked' ? 'lg' : 'none',
          }}
        >
          <CardHeader>
            <Box mb={4}>
              <Badge mb={2}>Module {module.id}</Badge>
              <Badge
                ml={2}
                colorScheme={
                  module.status === 'completed' ? 'green' :
                  module.status === 'in-progress' ? 'purple' :
                  module.status === 'available' ? 'blue' : 'gray'
                }
              >
                {module.status}
              </Badge>
            </Box>
            <Text fontSize="lg" fontWeight="bold" mb={2}>{module.title}</Text>
            <Text color="gray.600" fontSize="sm">{module.description}</Text>
          </CardHeader>

          <CardBody>
            <VStack spacing={4} align="stretch">
              <Box>
                <Text color="gray.600" fontSize="sm" mb={1}>Duration</Text>
                <Text fontWeight="medium">{module.duration}</Text>
              </Box>
              <Box>
                <Text color="gray.600" fontSize="sm" mb={1}>Progress</Text>
                <Progress
                  value={module.progress}
                  size="sm"
                  colorScheme="purple"
                  rounded="full"
                />
              </Box>
            </VStack>
          </CardBody>
        </Card>
      ))}
    </SimpleGrid>
  );
}