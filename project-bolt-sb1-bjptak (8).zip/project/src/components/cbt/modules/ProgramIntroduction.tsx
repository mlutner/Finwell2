import {
  Box,
  Button,
  Card,
  CardBody,
  CardHeader,
  Heading,
  Text,
  VStack,
  Stepper,
  Step,
  StepIndicator,
  StepStatus,
  StepIcon,
  StepNumber,
  StepTitle,
  StepSeparator,
  List,
  ListItem,
  ListIcon,
} from '@chakra-ui/react';
import { FiCheck } from 'react-icons/fi';
import { motion } from 'framer-motion';
import AudioPlayer from '../AudioPlayer';

interface Props {
  onStart: () => void;
}

export default function ProgramIntroduction({ onStart }: Props) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card>
        <CardHeader>
          <Box mb={8}>
            <Stepper index={0} colorScheme="orange">
              <Step>
                <StepIndicator>
                  <StepStatus
                    complete={<StepIcon />}
                    incomplete={<StepNumber />}
                    active={<StepNumber />}
                  />
                </StepIndicator>
                <Box flexShrink='0'>
                  <StepTitle>Introduction</StepTitle>
                </Box>
                <StepSeparator />
              </Step>
              <Step>
                <StepIndicator>
                  <StepStatus
                    complete={<StepIcon />}
                    incomplete={<StepNumber />}
                    active={<StepNumber />}
                  />
                </StepIndicator>
                <Box flexShrink='0'>
                  <StepTitle>Assessment</StepTitle>
                </Box>
                <StepSeparator />
              </Step>
              <Step>
                <StepIndicator>
                  <StepStatus
                    complete={<StepIcon />}
                    incomplete={<StepNumber />}
                    active={<StepNumber />}
                  />
                </StepIndicator>
                <Box flexShrink='0'>
                  <StepTitle>Goal Setting</StepTitle>
                </Box>
                <StepSeparator />
              </Step>
            </Stepper>
          </Box>

          <Heading size="lg">Welcome to Your Financial Wellness Journey</Heading>
          <Text mt={4} color="gray.600">
            An 8-module CBT program designed to help you develop a healthier relationship with money
          </Text>
        </CardHeader>

        <CardBody>
          <VStack spacing={8} align="stretch">
            {/* Audio Introduction */}
            <AudioPlayer 
              title="Listen to Program Introduction" 
              duration="2:30"
            />

            <Text>
              This journey is designed to help you address the intricate connection between your mental health and spending habits. 
              We recognize that for many, financial challenges and emotional well-being often go hand-in-hand, creating a cycle that 
              can feel overwhelming to break.
            </Text>

            <Box bg="headspace.orange.light" p={6} rounded="lg">
              <Heading size="md" mb={4}>What to Expect</Heading>
              <List spacing={4}>
                <ListItem display="flex" alignItems="center">
                  <ListIcon as={FiCheck} color="green.500" />
                  <Text>Structured CBT approach to understand spending behaviors</Text>
                </ListItem>
                <ListItem display="flex" alignItems="center">
                  <ListIcon as={FiCheck} color="green.500" />
                  <Text>Interactive exercises and self-reflection activities</Text>
                </ListItem>
                <ListItem display="flex" alignItems="center">
                  <ListIcon as={FiCheck} color="green.500" />
                  <Text>Regular mood and progress tracking</Text>
                </ListItem>
                <ListItem display="flex" alignItems="center">
                  <ListIcon as={FiCheck} color="green.500" />
                  <Text>AI-powered personalized guidance</Text>
                </ListItem>
                <ListItem display="flex" alignItems="center">
                  <ListIcon as={FiCheck} color="green.500" />
                  <Text>Professional support when needed</Text>
                </ListItem>
              </List>
            </Box>

            <Box bg="blue.50" p={6} rounded="lg">
              <Heading size="md" mb={4}>Program Structure</Heading>
              <Text mb={4}>
                The program consists of 8 modules, each focusing on different aspects of financial wellness:
              </Text>
              <List spacing={3}>
                <ListItem>1. Goal Setting & Initial Assessment</ListItem>
                <ListItem>2. Understanding Money Emotions</ListItem>
                <ListItem>3. Identifying Triggers</ListItem>
                <ListItem>4. Developing Coping Strategies</ListItem>
                <ListItem>5. Building Healthy Habits</ListItem>
                <ListItem>6. Financial Decision Making</ListItem>
                <ListItem>7. Stress Management</ListItem>
                <ListItem>8. Long-term Wellness Planning</ListItem>
              </List>
            </Box>

            <Button
              size="lg"
              onClick={onStart}
              bg="headspace.orange.primary"
              color="white"
              _hover={{
                bg: 'headspace.orange.secondary',
                transform: 'translateY(-2px)',
              }}
            >
              Begin Your Journey
            </Button>
          </VStack>
        </CardBody>
      </Card>
    </motion.div>
  );
}