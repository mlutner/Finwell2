import {
  Box,
  Button,
  Card,
  CardBody,
  CardHeader,
  Heading,
  Text,
  Textarea,
  VStack,
  useToast,
  Select,
  FormControl,
  FormLabel,
  Tag,
  Wrap,
  WrapItem,
  ButtonGroup,
  IconButton,
  useDisclosure,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalCloseButton,
  Progress,
} from '@chakra-ui/react';
import { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { FiVideo, FiStopCircle, FiMic, FiEdit2 } from 'react-icons/fi';

interface JournalEntry {
  date: string;
  mood: string;
  situation: string;
  thoughts: string;
  emotions: string;
  behaviors: string;
  insights: string;
  tags: string[];
  type: 'text' | 'video';
  mediaUrl?: string;
  transcription?: string;
  learningStyle?: 'visual' | 'auditory' | 'written';
}

interface Props {
  onSave: (entry: JournalEntry) => void;
  previousEntries?: JournalEntry[];
  learningStyle?: 'visual' | 'auditory' | 'written';
}

const MOODS = [
  'Confident',
  'Anxious',
  'Hopeful',
  'Overwhelmed',
  'Motivated',
  'Stressed',
  'Satisfied',
  'Worried'
];

const TAGS = [
  'Spending',
  'Saving',
  'Debt',
  'Income',
  'Budgeting',
  'Investment',
  'Goals',
  'Stress',
  'Success',
  'Challenge'
];

export default function FinancialJournal({ onSave, previousEntries = [], learningStyle }: Props) {
  const [entry, setEntry] = useState<JournalEntry>({
    date: new Date().toISOString().split('T')[0],
    mood: '',
    situation: '',
    thoughts: '',
    emotions: '',
    behaviors: '',
    insights: '',
    tags: [],
    type: 'text',
    learningStyle: learningStyle
  });

  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [journalType, setJournalType] = useState<'text' | 'video'>('text');
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<NodeJS.Timeout>();
  const { isOpen, onOpen, onClose } = useDisclosure();
  const toast = useToast();

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      chunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          chunksRef.current.push(e.data);
        }
      };

      mediaRecorder.onstop = async () => {
        const blob = new Blob(chunksRef.current, { type: 'video/webm' });
        const url = URL.createObjectURL(blob);
        
        // Here you would typically upload the blob to your storage service
        // and get back a URL. For now, we'll use the local blob URL
        setEntry(prev => ({
          ...prev,
          type: 'video',
          mediaUrl: url
        }));

        // Mock transcription - in production, you'd use a speech-to-text service
        setEntry(prev => ({
          ...prev,
          transcription: "Video journal transcription would appear here..."
        }));

        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
      
      // Start timer
      timerRef.current = setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);

    } catch (error) {
      toast({
        title: 'Could not start recording',
        description: 'Please make sure you have granted camera and microphone permissions.',
        status: 'error',
        duration: 5000,
      });
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      clearInterval(timerRef.current);
      setRecordingTime(0);
    }
  };

  const handleSubmit = () => {
    if (!validateEntry()) {
      toast({
        title: 'Please complete all required fields',
        status: 'warning',
        duration: 3000,
      });
      return;
    }

    onSave(entry);
    toast({
      title: 'Journal Entry Saved',
      status: 'success',
      duration: 3000,
    });

    // Reset form
    setEntry({
      date: new Date().toISOString().split('T')[0],
      mood: '',
      situation: '',
      thoughts: '',
      emotions: '',
      behaviors: '',
      insights: '',
      tags: [],
      type: 'text',
      learningStyle
    });
  };

  const validateEntry = () => {
    if (entry.type === 'video') {
      return entry.mediaUrl && entry.mood;
    }
    return entry.mood && entry.situation && entry.thoughts && entry.emotions;
  };

  const toggleTag = (tag: string) => {
    setEntry(prev => ({
      ...prev,
      tags: prev.tags.includes(tag)
        ? prev.tags.filter(t => t !== tag)
        : [...prev.tags, tag]
    }));
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card>
        <CardHeader>
          <Heading size="lg">Financial Reflection Journal</Heading>
          <Text mt={2} color="gray.600">
            Record your thoughts, feelings, and behaviors around money
          </Text>
          
          {/* Journal Type Selection */}
          <ButtonGroup size="lg" isAttached variant="outline" mt={4}>
            <Button
              onClick={() => setJournalType('text')}
              colorScheme={journalType === 'text' ? 'purple' : 'gray'}
              leftIcon={<FiEdit2 />}
            >
              Written
            </Button>
            <Button
              onClick={() => {
                setJournalType('video');
                onOpen();
              }}
              colorScheme={journalType === 'video' ? 'purple' : 'gray'}
              leftIcon={<FiVideo />}
            >
              Video
            </Button>
          </ButtonGroup>
        </CardHeader>

        <CardBody>
          <VStack spacing={6} align="stretch">
            {/* Common Fields */}
            <FormControl isRequired>
              <FormLabel>Current Mood</FormLabel>
              <Select
                value={entry.mood}
                onChange={(e) => setEntry(prev => ({ ...prev, mood: e.target.value }))}
                placeholder="Select your current mood"
              >
                {MOODS.map(mood => (
                  <option key={mood} value={mood}>{mood}</option>
                ))}
              </Select>
            </FormControl>

            {journalType === 'text' ? (
              // Written Journal Fields
              <>
                <FormControl isRequired>
                  <FormLabel>Situation</FormLabel>
                  <Textarea
                    value={entry.situation}
                    onChange={(e) => setEntry(prev => ({ ...prev, situation: e.target.value }))}
                    placeholder="What financial situation or event are you reflecting on?"
                    rows={3}
                  />
                </FormControl>

                <FormControl isRequired>
                  <FormLabel>Thoughts</FormLabel>
                  <Textarea
                    value={entry.thoughts}
                    onChange={(e) => setEntry(prev => ({ ...prev, thoughts: e.target.value }))}
                    placeholder="What thoughts came up for you?"
                    rows={3}
                  />
                </FormControl>

                <FormControl isRequired>
                  <FormLabel>Emotions</FormLabel>
                  <Textarea
                    value={entry.emotions}
                    onChange={(e) => setEntry(prev => ({ ...prev, emotions: e.target.value }))}
                    placeholder="How did this make you feel emotionally?"
                    rows={3}
                  />
                </FormControl>

                <FormControl>
                  <FormLabel>Behaviors</FormLabel>
                  <Textarea
                    value={entry.behaviors}
                    onChange={(e) => setEntry(prev => ({ ...prev, behaviors: e.target.value }))}
                    placeholder="How did you act or want to act?"
                    rows={3}
                  />
                </FormControl>

                <FormControl>
                  <FormLabel>Insights & Learnings</FormLabel>
                  <Textarea
                    value={entry.insights}
                    onChange={(e) => setEntry(prev => ({ ...prev, insights: e.target.value }))}
                    placeholder="What did you learn from this experience?"
                    rows={3}
                  />
                </FormControl>
              </>
            ) : (
              // Video Journal Preview
              entry.mediaUrl && (
                <Box>
                  <video 
                    src={entry.mediaUrl} 
                    controls 
                    style={{ width: '100%', borderRadius: '8px' }}
                  />
                  {entry.transcription && (
                    <Box mt={4}>
                      <Text fontWeight="medium" mb={2}>Transcription:</Text>
                      <Text color="gray.600">{entry.transcription}</Text>
                    </Box>
                  )}
                </Box>
              )
            )}

            {/* Tags */}
            <Box>
              <FormLabel>Tags</FormLabel>
              <Wrap spacing={2}>
                {TAGS.map(tag => (
                  <WrapItem key={tag}>
                    <Tag
                      size="md"
                      variant={entry.tags.includes(tag) ? 'solid' : 'outline'}
                      colorScheme="purple"
                      cursor="pointer"
                      onClick={() => toggleTag(tag)}
                      _hover={{
                        opacity: 0.8
                      }}
                    >
                      {tag}
                    </Tag>
                  </WrapItem>
                ))}
              </Wrap>
            </Box>

            <Button
              colorScheme="purple"
              size="lg"
              onClick={handleSubmit}
              bgGradient="linear(to-r, purple.500, blue.500)"
              _hover={{
                bgGradient: "linear(to-r, purple.600, blue.600)",
              }}
            >
              Save Journal Entry
            </Button>
          </VStack>
        </CardBody>
      </Card>

      {/* Video Recording Modal */}
      <Modal isOpen={isOpen} onClose={onClose} size="xl">
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>Record Video Journal</ModalHeader>
          <ModalCloseButton />
          <ModalBody pb={6}>
            <VStack spacing={4}>
              {isRecording ? (
                <Box position="relative" width="100%" height="400px" bg="gray.900" borderRadius="lg">
                  <video
                    autoPlay
                    muted
                    playsInline
                    style={{
                      width: '100%',
                      height: '100%',
                      objectFit: 'cover',
                      borderRadius: '8px'
                    }}
                  />
                  <Box position="absolute" bottom={4} left={0} right={0} textAlign="center">
                    <Text color="white" mb={2}>Recording: {recordingTime}s</Text>
                    <IconButton
                      aria-label="Stop recording"
                      icon={<FiStopCircle />}
                      colorScheme="red"
                      onClick={stopRecording}
                      size="lg"
                      isRound
                    />
                  </Box>
                </Box>
              ) : (
                <Box
                  width="100%"
                  height="400px"
                  bg="gray.100"
                  borderRadius="lg"
                  display="flex"
                  alignItems="center"
                  justifyContent="center"
                >
                  <VStack spacing={4}>
                    <IconButton
                      aria-label="Start recording"
                      icon={<FiVideo />}
                      colorScheme="purple"
                      onClick={startRecording}
                      size="lg"
                      isRound
                    />
                    <Text>Click to start recording</Text>
                  </VStack>
                </Box>
              )}
            </VStack>
          </ModalBody>
        </ModalContent>
      </Modal>
    </motion.div>
  );
}