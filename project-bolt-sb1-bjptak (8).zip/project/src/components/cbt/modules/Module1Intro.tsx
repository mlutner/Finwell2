import {
  Box,
  Card,
  CardBody,
  CardHeader,
  Heading,
  Text,
  VStack,
  List,
  ListItem,
  ListIcon,
  Button,
  Progress,
} from '@chakra-ui/react';
import { FiCheckCircle } from 'react-icons/fi';

interface Props {
  onComplete: () => void;
}

export default function Module1Intro({ onComplete }: Props) {
  return (
    <Card>
      <CardHeader>
        <Heading size="lg">Welcome to Your Financial Wellness Journey</Heading>
        <Text mt={2} color="gray.600">
          Module 1: Goal Setting & Initial Assessment
        </Text>
      </CardHeader>

      <CardBody>
        <VStack spacing={6} align="stretch">
          <Box>
            <Heading size="md" mb={4}>Program Structure</Heading>
            <Text mb={4}>
              This CBT-based program combines financial management with psychological well-being.
              Each module builds upon the previous one, helping you develop healthier financial habits.
            </Text>
            <List spacing={3}>
              <ListItem display="flex" alignItems="center">
                <ListIcon as={FiCheckCircle} color="green.500" />
                Evidence-based CBT techniques for financial wellness
              </ListItem>
              <ListItem display="flex" alignItems="center">
                <ListIcon as={FiCheckCircle} color="green.500" />
                Interactive exercises and self-reflection activities
              </ListItem>
              <ListItem display="flex" alignItems="center">
                <ListIcon as={FiCheckCircle} color="green.500" />
                Progress tracking and goal monitoring
              </ListItem>
              <ListItem display="flex" alignItems="center">
                <ListIcon as={FiCheckCircle} color="green.500" />
                Professional support when needed
              </ListItem>
            </List>
          </Box>

          <Box>
            <Heading size="md" mb={4}>Module 1 Overview</Heading>
            <Text mb={4}>
              In this module, you'll establish your baseline and set clear goals for your journey.
              Key activities include:
            </Text>
            <List spacing={3}>
              <ListItem display="flex" alignItems="center">
                <ListIcon as={FiCheckCircle} color="purple.500" />
                Goal-Setting Worksheet
              </ListItem>
              <ListItem display="flex" alignItems="center">
                <ListIcon as={FiCheckCircle} color="purple.500" />
                Current Behavior Assessment
              </ListItem>
              <ListItem display="flex" alignItems="center">
                <ListIcon as={FiCheckCircle} color="purple.500" />
                Confidence to Achieve Goals Log
              </ListItem>
              <ListItem display="flex" alignItems="center">
                <ListIcon as={FiCheckCircle} color="purple.500" />
                Stages of Change Assessment
              </ListItem>
            </List>
          </Box>

          <Box bg="purple.50" p={6} rounded="lg">
            <Heading size="sm" mb={3}>Your Progress</Heading>
            <Progress value={0} size="sm" colorScheme="purple" mb={4} />
            <Text fontSize="sm" color="purple.700">
              Ready to begin your journey to financial wellness?
            </Text>
          </Box>

          <Button
            colorScheme="purple"
            size="lg"
            onClick={onComplete}
            bgGradient="linear(to-r, purple.500, blue.500)"
            _hover={{
              bgGradient: "linear(to-r, purple.600, blue.600)",
            }}
          >
            Begin Module 1
          </Button>
        </VStack>
      </CardBody>
    </Card>
  );
}