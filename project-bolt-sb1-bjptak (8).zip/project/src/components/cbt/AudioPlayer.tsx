import {
  Box,
  IconButton,
  Text,
  Progress,
  HStack,
  useToast,
} from '@chakra-ui/react';
import { useState, useRef, useEffect } from 'react';
import { FiPlay, FiPause } from 'react-icons/fi';

interface Props {
  title: string;
  duration?: string;
}

export default function AudioPlayer({ title, duration = '2:30' }: Props) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const toast = useToast();

  useEffect(() => {
    // Create audio element with demo audio
    audioRef.current = new Audio('/demo-intro.mp3');
    
    audioRef.current.addEventListener('timeupdate', () => {
      if (audioRef.current) {
        const percentage = (audioRef.current.currentTime / audioRef.current.duration) * 100;
        setProgress(percentage);
      }
    });

    audioRef.current.addEventListener('ended', () => {
      setIsPlaying(false);
      setProgress(0);
    });

    // Cleanup
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.remove();
      }
    };
  }, []);

  const togglePlay = () => {
    if (!audioRef.current) {
      toast({
        title: "Audio not available",
        description: "Demo audio file is not loaded",
        status: "error",
        duration: 3000,
      });
      return;
    }

    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play().catch(error => {
        toast({
          title: "Playback failed",
          description: "Unable to play audio file",
          status: "error",
          duration: 3000,
        });
      });
    }
    setIsPlaying(!isPlaying);
  };

  return (
    <Box
      bg="headspace.orange.light"
      p={4}
      borderRadius="lg"
      border="1px solid"
      borderColor="headspace.orange.primary"
    >
      <HStack spacing={4} align="center">
        <IconButton
          aria-label={isPlaying ? 'Pause' : 'Play'}
          icon={isPlaying ? <FiPause /> : <FiPlay />}
          onClick={togglePlay}
          colorScheme="orange"
          variant="solid"
          bg="headspace.orange.primary"
          color="white"
          size="lg"
          isRound
        />
        <Box flex={1}>
          <Text fontWeight="medium" color="headspace.slate" mb={1}>
            {title}
          </Text>
          <Progress
            value={progress}
            size="sm"
            colorScheme="orange"
            bg="white"
            borderRadius="full"
          />
          <Text fontSize="sm" color="gray.600" mt={1}>
            {duration}
          </Text>
        </Box>
      </HStack>
    </Box>
  );
}