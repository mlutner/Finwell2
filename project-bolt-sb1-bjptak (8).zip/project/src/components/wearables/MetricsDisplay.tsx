import {
  Box,
  Card,
  CardBody,
  CardHeader,
  Grid,
  Heading,
  Text,
  Icon,
  Stat,
  StatLabel,
  StatNumber,
  StatHelpText,
} from '@chakra-ui/react';
import { FiHeart, FiActivity, FiMoon, FiTrendingUp } from 'react-icons/fi';
import type { WearableMetrics } from '../../types/wearables';

interface Props {
  metrics: WearableMetrics;
}

export default function MetricsDisplay({ metrics }: Props) {
  return (
    <Card>
      <CardHeader>
        <Heading size="md">Wellness Metrics</Heading>
        <Text color="gray.600" mt={1}>
          Your latest health and wellness data
        </Text>
      </CardHeader>

      <CardBody>
        <Grid templateColumns="repeat(2, 1fr)" gap={6}>
          <Card variant="outline">
            <CardBody>
              <Stat>
                <StatLabel>
                  <Icon as={FiHeart} color="red.500" mr={2} />
                  Heart Rate
                </StatLabel>
                <StatNumber>{metrics.heartRate} BPM</StatNumber>
                <StatHelpText>Average today</StatHelpText>
              </Stat>
            </CardBody>
          </Card>

          <Card variant="outline">
            <CardBody>
              <Stat>
                <StatLabel>
                  <Icon as={FiTrendingUp} color="orange.500" mr={2} />
                  Stress Level
                </StatLabel>
                <StatNumber>{metrics.stressLevel}/10</StatNumber>
                <StatHelpText>Current level</StatHelpText>
              </Stat>
            </CardBody>
          </Card>

          <Card variant="outline">
            <CardBody>
              <Stat>
                <StatLabel>
                  <Icon as={FiMoon} color="purple.500" mr={2} />
                  Sleep Quality
                </StatLabel>
                <StatNumber>{metrics.sleepQuality}%</StatNumber>
                <StatHelpText>Last night</StatHelpText>
              </Stat>
            </CardBody>
          </Card>

          <Card variant="outline">
            <CardBody>
              <Stat>
                <StatLabel>
                  <Icon as={FiActivity} color="green.500" mr={2} />
                  Steps
                </StatLabel>
                <StatNumber>{metrics.steps.toLocaleString()}</StatNumber>
                <StatHelpText>Today's count</StatHelpText>
              </Stat>
            </CardBody>
          </Card>
        </Grid>
      </CardBody>
    </Card>
  );
}