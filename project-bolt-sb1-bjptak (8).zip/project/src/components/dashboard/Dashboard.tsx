import {
  Box,
  Container,
  Grid,
  Heading,
  Text,
  VStack,
  SimpleGrid,
  Button,
  ButtonGroup,
} from '@chakra-ui/react';
import { motion } from 'framer-motion';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import MetricsCard from './MetricsCard';
import MoodTracker from './MoodTracker';
import QuickActions from './QuickActions';
import SpendingGraph from './SpendingGraph';
import LearningPathways from './LearningPathways';
import WearablesConnect from '../wearables/WearablesConnect';
import WellnessMetrics from '../wearables/WellnessMetrics';

export default function Dashboard() {
  const navigate = useNavigate();

  return (
    <Container maxW="container.xl">
      {/* Header Section */}
      <Box textAlign="center" pt={8} pb={6}>
        <Heading size="lg" mb={2}>Dashboard</Heading>
        <Text color="gray.600" mb={6}>
          Welcome back! Here's your financial wellness overview.
        </Text>

        {/* Action Buttons */}
        <ButtonGroup spacing={4} mb={8}>
          <Button
            size="lg"
            variant="solid"
            onClick={() => navigate('/assessment')}
            bg="brand.500"
            color="white"
            _hover={{
              bg: 'brand.400',
              transform: 'translateY(-2px)',
            }}
          >
            Start Your Wellbeing Journey
          </Button>
          <Button
            size="lg"
            variant="secondary"
            onClick={() => navigate('/cbt-program')}
            _hover={{
              bg: 'mindful.400',
              transform: 'translateY(-2px)',
            }}
          >
            Continue Your CBT Pathway
          </Button>
        </ButtonGroup>
      </Box>

      <VStack spacing={8} align="stretch">
        {/* Mood Tracker */}
        <Box maxW="container.sm" mx="auto">
          <MoodTracker />
        </Box>

        {/* Main Content */}
        <SimpleGrid columns={{ base: 1, lg: 2 }} spacing={6}>
          <MetricsCard />
          <SpendingGraph />
        </SimpleGrid>

        {/* Wearables Section */}
        <SimpleGrid columns={{ base: 1, lg: 2 }} spacing={6}>
          <VStack spacing={4}>
            <WearablesConnect />
            <Button
              size="lg"
              variant="calm"
              onClick={onOpen}
              w="full"
              _hover={{
                bg: 'calm.400',
                transform: 'translateY(-2px)',
              }}
            >
              Connect Your Bank
            </Button>
          </VStack>
          <WellnessMetrics />
        </SimpleGrid>

        {/* Secondary Content */}
        <Grid templateColumns={{ base: '1fr', lg: 'repeat(2, 1fr)' }} gap={6}>
          <QuickActions />
          <LearningPathways />
        </Grid>
      </VStack>
    </Container>
  );
}