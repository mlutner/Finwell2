import {
  Box,
  Heading,
  ButtonGroup,
  Button,
  Flex,
  Text,
  Card,
  CardHeader,
  CardBody,
  useTheme,
} from '@chakra-ui/react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Line } from 'react-chartjs-2';
import { useState } from 'react';
import { motion } from 'framer-motion';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

const generateMockData = (days: number, colors: any) => {
  const labels = Array.from({ length: days }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() - (days - 1 - i));
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  });

  const spending = Array.from({ length: days }, () => 
    Math.floor(Math.random() * 150) + 50
  );

  const budget = Array(days).fill(100);

  return {
    labels,
    datasets: [
      {
        label: 'Daily Spending',
        data: spending,
        borderColor: colors.headspace.orange.primary,
        backgroundColor: colors.headspace.orange.light,
        tension: 0.4,
      },
      {
        label: 'Budget Target',
        data: budget,
        borderColor: colors.headspace.blue,
        backgroundColor: `${colors.headspace.blue}33`,
        borderDash: [5, 5],
        tension: 0,
      },
    ],
  };
};

export default function SpendingGraph() {
  const theme = useTheme();
  const [timeframe, setTimeframe] = useState<'7d' | '30d' | '90d'>('7d');
  const [chartData, setChartData] = useState(() => generateMockData(7, theme.colors));

  const handleTimeframeChange = (newTimeframe: '7d' | '30d' | '90d') => {
    setTimeframe(newTimeframe);
    const days = newTimeframe === '7d' ? 7 : newTimeframe === '30d' ? 30 : 90;
    setChartData(generateMockData(days, theme.colors));
  };

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
        labels: {
          font: {
            family: "'Circular', -apple-system, BlinkMacSystemFont, sans-serif"
          },
          padding: 20,
          usePointStyle: true
        }
      },
      tooltip: {
        mode: 'index' as const,
        intersect: false,
        backgroundColor: 'rgba(255, 255, 255, 0.95)',
        titleColor: theme.colors.headspace.slate,
        bodyColor: theme.colors.headspace.slate,
        borderColor: 'rgba(0, 0, 0, 0.1)',
        borderWidth: 1,
        padding: 12,
        bodyFont: {
          family: "'Circular', -apple-system, BlinkMacSystemFont, sans-serif"
        },
        titleFont: {
          family: "'Circular', -apple-system, BlinkMacSystemFont, sans-serif"
        }
      }
    },
    scales: {
      y: {
        beginAtZero: true,
        grid: {
          color: theme.colors.headspace.orange.light,
        },
        ticks: {
          font: {
            family: "'Circular', -apple-system, BlinkMacSystemFont, sans-serif"
          },
          color: theme.colors.headspace.slate
        }
      },
      x: {
        grid: {
          display: false,
        },
        ticks: {
          font: {
            family: "'Circular', -apple-system, BlinkMacSystemFont, sans-serif"
          },
          color: theme.colors.headspace.slate
        }
      }
    },
    interaction: {
      mode: 'nearest' as const,
      axis: 'x' as const,
      intersect: false,
    },
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card>
        <CardHeader>
          <Flex justify="space-between" align="center" mb={4}>
            <Box>
              <Heading 
                size="md" 
                color="headspace.slate"
                fontWeight="600"
                letterSpacing="-0.02em"
              >
                Spending Overview
              </Heading>
              <Text 
                color="gray.600" 
                fontSize="sm"
                mt={1}
              >
                Track your daily spending patterns
              </Text>
            </Box>
            <ButtonGroup variant="pill">
              <Button
                variant="pill"
                onClick={() => handleTimeframeChange('7d')}
                bg={timeframe === '7d' ? 'white' : 'transparent'}
                shadow={timeframe === '7d' ? 'sm' : 'none'}
              >
                7D
              </Button>
              <Button
                variant="pill"
                onClick={() => handleTimeframeChange('30d')}
                bg={timeframe === '30d' ? 'white' : 'transparent'}
                shadow={timeframe === '30d' ? 'sm' : 'none'}
              >
                30D
              </Button>
              <Button
                variant="pill"
                onClick={() => handleTimeframeChange('90d')}
                bg={timeframe === '90d' ? 'white' : 'transparent'}
                shadow={timeframe === '90d' ? 'sm' : 'none'}
              >
                90D
              </Button>
            </ButtonGroup>
          </Flex>
        </CardHeader>

        <CardBody>
          <Box h="300px">
            <Line options={options} data={chartData} />
          </Box>
        </CardBody>
      </Card>
    </motion.div>
  );
}