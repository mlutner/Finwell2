import { useState } from 'react';
import { useNavigate, Link as RouterLink } from 'react-router-dom';
import { signInWithEmailAndPassword, signInWithPopup } from 'firebase/auth';
import { auth, googleProvider } from '../../config/firebase';
import {
  Box,
  Button,
  VStack,
  Text,
  useToast,
  Heading,
  Image,
  Divider,
  Link,
  Center,
  Icon,
  Card,
  CardBody,
  FormControl,
  FormLabel,
  Input,
} from '@chakra-ui/react';
import { FcGoogle } from 'react-icons/fc';

export default function SignIn() {
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const toast = useToast();
  const navigate = useNavigate();

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setLoading(true);
      await signInWithEmailAndPassword(auth, email, password);
      navigate('/');
    } catch (error) {
      toast({
        title: 'Error signing in',
        description: 'Invalid email or password.',
        status: 'error',
        duration: 5000,
        isClosable: true,
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDemoLogin = async () => {
    try {
      setLoading(true);
      // Use the demo credentials
      await signInWithEmailAndPassword(auth, 'demo@finwell.com', 'demo123');
      navigate('/');
    } catch (error) {
      console.error('Demo login error:', error);
      toast({
        title: 'Error signing in',
        description: 'Demo account login failed. Please try again.',
        status: 'error',
        duration: 5000,
        isClosable: true,
      });
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    try {
      setLoading(true);
      await signInWithPopup(auth, googleProvider);
      navigate('/');
    } catch (error) {
      toast({
        title: 'Error signing in with Google',
        description: 'Please try again.',
        status: 'error',
        duration: 5000,
        isClosable: true,
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box maxW="md" mx="auto" mt={8}>
      <Card>
        <CardBody>
          <VStack spacing={6}>
            <Image src="/owl-logo.svg" alt="FinWell Logo" boxSize="120px" />
            
            <Heading as="h1" size="xl" color="headspace.slate">
              FinWell
            </Heading>
            
            <Text fontSize="lg" color="gray.600">
              Your Financial Wellness Journey
            </Text>

            <form onSubmit={handleSignIn} style={{ width: '100%' }}>
              <VStack spacing={4}>
                <FormControl>
                  <FormLabel>Email</FormLabel>
                  <Input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    focusBorderColor="headspace.orange.primary"
                    placeholder="Enter your email"
                  />
                </FormControl>

                <FormControl>
                  <FormLabel>Password</FormLabel>
                  <Input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    focusBorderColor="headspace.orange.primary"
                    placeholder="Enter your password"
                  />
                </FormControl>

                <Button
                  type="submit"
                  width="full"
                  isLoading={loading}
                  bg="headspace.orange.primary"
                  color="white"
                  _hover={{ bg: 'headspace.orange.secondary' }}
                >
                  Sign In
                </Button>
              </VStack>
            </form>

            <Center w="full" position="relative" py={4}>
              <Divider />
              <Text
                position="absolute"
                bg="white"
                px={4}
                color="gray.500"
              >
                OR
              </Text>
            </Center>

            <Button
              w="full"
              variant="outline"
              onClick={handleDemoLogin}
              isLoading={loading}
              borderColor="headspace.orange.primary"
              color="headspace.orange.primary"
              _hover={{ bg: 'headspace.orange.light' }}
            >
              Try Demo Account
            </Button>

            <Button
              w="full"
              variant="outline"
              leftIcon={<Icon as={FcGoogle} boxSize={5} />}
              onClick={handleGoogleSignIn}
              isLoading={loading}
            >
              Continue with Google
            </Button>

            <Text color="gray.600" fontSize="sm">
              Don't have an account?{' '}
              <Link as={RouterLink} to="/signup" color="headspace.orange.primary">
                Sign up
              </Link>
            </Text>
          </VStack>
        </CardBody>
      </Card>
    </Box>
  );
}