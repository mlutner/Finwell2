import {
  Box,
  Checkbox,
  CheckboxGroup,
  Radio,
  RadioGroup,
  Stack,
  Text,
  Textarea,
  Slider,
  SliderTrack,
  SliderFilledTrack,
  SliderThumb,
  SliderMark,
} from '@chakra-ui/react';
import { AssessmentQuestion } from '../../types/assessment';

interface Props {
  question: AssessmentQuestion;
  value: any;
  onChange: (value: any) => void;
}

export function QuestionRenderer({ question, value, onChange }: Props) {
  switch (question.type) {
    case 'multiple-select':
      return (
        <CheckboxGroup
          value={value[question.id] || []}
          onChange={(selected) => onChange({ [question.id]: selected })}
        >
          <Stack spacing={3}>
            {question.options?.map((option) => (
              <Checkbox
                key={option.id}
                value={option.id}
                colorScheme="purple"
              >
                {option.label}
              </Checkbox>
            ))}
          </Stack>
        </CheckboxGroup>
      );

    case 'single-select':
      return (
        <RadioGroup
          value={value[question.id] || ''}
          onChange={(selected) => onChange({ [question.id]: selected })}
        >
          <Stack spacing={3}>
            {question.options?.map((option) => (
              <Radio
                key={option.id}
                value={option.id}
                colorScheme="purple"
              >
                {option.label}
              </Radio>
            ))}
          </Stack>
        </RadioGroup>
      );

    case 'slider':
      return (
        <Box pt={6} pb={2}>
          <Slider
            defaultValue={5}
            min={0}
            max={10}
            step={1}
            onChange={(val) => onChange({ [question.id]: val })}
          >
            <SliderMark value={0} mt={2} ml={-2} fontSize="sm">
              0
            </SliderMark>
            <SliderMark value={5} mt={2} ml={-2} fontSize="sm">
              5
            </SliderMark>
            <SliderMark value={10} mt={2} ml={-2} fontSize="sm">
              10
            </SliderMark>
            <SliderTrack>
              <SliderFilledTrack bg="purple.500" />
            </SliderTrack>
            <SliderThumb boxSize={6} />
          </Slider>
        </Box>
      );

    case 'text':
      return (
        <Textarea
          value={value[question.id] || ''}
          onChange={(e) => onChange({ [question.id]: e.target.value })}
          placeholder="Type your answer here..."
          size="lg"
          minH="150px"
        />
      );

    default:
      return (
        <Text color="red.500">
          Unsupported question type: {question.type}
        </Text>
      );
  }
}