export type MoodType = 'great' | 'good' | 'neutral' | 'low' | 'bad';

export interface MoodEntry {
  id: string;
  timestamp: string;
  mood: MoodType;
  note?: string;
  stressLevel?: number;
  wearableMetrics?: {
    heartRate?: number;
    stressScore?: number;
    sleepQuality?: number;
  };
}