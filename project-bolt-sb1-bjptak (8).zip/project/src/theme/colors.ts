export const colors = {
  headspace: {
    orange: {
      primary: '#f58b44',    // Main orange
      secondary: '#f06e1d',  // Darker orange for hover
      light: '#fdf5eb'       // Light orange background
    },
    red: {
      primary: '#ff654a',    // Accent red
      secondary: '#ff4d2e',  // Darker red for hover
      light: '#fff1f0'       // Light red background
    },
    slate: '#4b5161'         // Text color
  }
};