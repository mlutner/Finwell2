import { useState, useCallback } from 'react';
import { useToast } from '@chakra-ui/react';
import type { WearableProvider, WearableMetrics, WearableConnection } from '../types/wearables';

// Mock data for demo purposes
const MOCK_METRICS: WearableMetrics = {
  heartRate: 72,
  stressLevel: 45,
  sleepQuality: 85,
  steps: 8432,
  timestamp: new Date().toISOString()
};

export function useWearables() {
  const [connections, setConnections] = useState<WearableConnection[]>([]);
  const [isConnecting, setIsConnecting] = useState(false);
  const [metrics, setMetrics] = useState<WearableMetrics | null>(null);
  const toast = useToast();

  const connect = useCallback(async (provider: WearableProvider) => {
    setIsConnecting(true);
    try {
      // Simulate connection delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      setConnections(prev => [...prev, {
        provider,
        connected: true,
        lastSync: new Date().toISOString()
      }]);

      // Set mock metrics
      setMetrics(MOCK_METRICS);

      toast({
        title: 'Device Connected',
        description: `Successfully connected to ${provider}`,
        status: 'success',
        duration: 3000,
      });
    } catch (error) {
      toast({
        title: 'Connection Failed',
        description: error instanceof Error ? error.message : 'Failed to connect device',
        status: 'error',
        duration: 5000,
      });
    } finally {
      setIsConnecting(false);
    }
  }, [toast]);

  const disconnect = useCallback(async (provider: WearableProvider) => {
    try {
      // Simulate disconnection delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setConnections(prev => 
        prev.filter(conn => conn.provider !== provider)
      );

      if (connections.length === 1) {
        setMetrics(null);
      }

      toast({
        title: 'Device Disconnected',
        description: `Successfully disconnected from ${provider}`,
        status: 'success',
        duration: 3000,
      });
    } catch (error) {
      toast({
        title: 'Disconnect Failed',
        description: 'Failed to disconnect device',
        status: 'error',
        duration: 5000,
      });
    }
  }, [connections.length, toast]);

  const syncMetrics = useCallback(async (provider: WearableProvider) => {
    try {
      // Simulate sync delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Update mock metrics with slight variations
      const newMetrics: WearableMetrics = {
        ...MOCK_METRICS,
        heartRate: MOCK_METRICS.heartRate + Math.floor(Math.random() * 5),
        stressLevel: MOCK_METRICS.stressLevel + Math.floor(Math.random() * 10),
        steps: MOCK_METRICS.steps + Math.floor(Math.random() * 1000),
        timestamp: new Date().toISOString()
      };
      
      setMetrics(newMetrics);
      
      // Update last sync time
      setConnections(prev =>
        prev.map(conn =>
          conn.provider === provider
            ? { ...conn, lastSync: new Date().toISOString() }
            : conn
        )
      );

      return newMetrics;
    } catch (error) {
      toast({
        title: 'Sync Failed',
        description: 'Failed to sync metrics from device',
        status: 'error',
        duration: 5000,
      });
      return null;
    }
  }, [toast]);

  return {
    connections,
    isConnecting,
    metrics,
    connect,
    disconnect,
    syncMetrics
  };
}