import { useState, useCallback } from 'react';
import { useToast } from '@chakra-ui/react';
import { useWearables } from './useWearables';
import type { MoodEntry, MoodType } from '../types/mood';

export function useMoodTracking() {
  const [entries, setEntries] = useState<MoodEntry[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const { metrics, syncMetrics } = useWearables();
  const toast = useToast();

  const addEntry = useCallback(async (mood: MoodType, note?: string) => {
    setIsLoading(true);
    try {
      // Get latest wearable metrics if available
      let wearableData;
      if (metrics) {
        wearableData = {
          heartRate: metrics.heartRate,
          stressScore: metrics.stressLevel,
          sleepQuality: metrics.sleepQuality
        };
      }

      const newEntry: MoodEntry = {
        id: Date.now().toString(),
        timestamp: new Date().toISOString(),
        mood,
        note,
        stressLevel: wearableData?.stressScore,
        wearableMetrics: wearableData
      };

      setEntries(prev => [newEntry, ...prev]);

      // Analyze correlation if we have enough data
      if (entries.length > 0) {
        analyzeStressMoodCorrelation();
      }

      toast({
        title: 'Mood Tracked',
        description: wearableData 
          ? 'Mood and stress data recorded'
          : 'Mood recorded',
        status: 'success',
        duration: 3000,
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to record mood',
        status: 'error',
        duration: 5000,
      });
    } finally {
      setIsLoading(false);
    }
  }, [metrics, entries, toast]);

  const analyzeStressMoodCorrelation = useCallback(() => {
    const recentEntries = entries.slice(0, 7); // Last 7 entries
    const hasCorrelation = recentEntries.some(entry => 
      entry.wearableMetrics?.stressScore && 
      ((entry.mood === 'bad' && entry.wearableMetrics.stressScore > 70) ||
       (entry.mood === 'great' && entry.wearableMetrics.stressScore < 30))
    );

    if (hasCorrelation) {
      toast({
        title: 'Insight Detected',
        description: 'We noticed a correlation between your stress levels and mood',
        status: 'info',
        duration: 5000,
        isClosable: true,
      });
    }
  }, [entries, toast]);

  return {
    entries,
    isLoading,
    addEntry,
  };
}