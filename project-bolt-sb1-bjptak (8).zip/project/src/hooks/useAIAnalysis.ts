import { useState } from 'react';
import { config } from '../lib/ai/config';

const mockAnalysis = {
  riskLevel: 'moderate' as const,
  sentiment: 'neutral' as const,
  emotionalTriggers: ['financial stress', 'impulsive spending', 'money anxiety'],
  recommendations: {
    cbt: [
      'Practice mindfulness when making financial decisions',
      'Challenge negative money beliefs',
      'Keep a financial thought diary'
    ],
    financial: [
      'Create a monthly budget',
      'Track daily expenses',
      'Build an emergency fund'
    ],
    combined: [
      'Set realistic financial goals aligned with your values',
      'Develop healthy money habits through CBT techniques',
      'Practice self-compassion during financial setbacks'
    ]
  },
  suggestedModules: [
    'Financial Mindset Fundamentals',
    'Emotional Spending Awareness',
    'Building Healthy Money Habits'
  ]
};

export function useAIAnalysis() {
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const analyzeResponses = async (assessmentData: any) => {
    setIsAnalyzing(true);
    try {
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      return mockAnalysis;
    } catch (error) {
      console.error('AI Analysis Error:', error);
      return mockAnalysis;
    } finally {
      setIsAnalyzing(false);
    }
  };

  return {
    analyzeResponses,
    isAnalyzing,
  };
}