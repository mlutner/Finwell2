import {
  Box,
  Button,
  Card,
  CardBody,
  CardHeader,
  FormControl,
  FormLabel,
  Heading,
  Input,
  Select,
  Text,
  Textarea,
  VStack,
  useToast,
} from '@chakra-ui/react';
import { useState } from 'react';

interface Goal {
  type: string;
  timeframe: string;
  description: string;
  target: string;
  steps: string;
  obstacles: string;
  support: string;
}

interface Props {
  onComplete: (goals: Goal[]) => void;
}

export default function GoalSettingWorksheet({ onComplete }: Props) {
  const [goals, setGoals] = useState<Goal[]>([{
    type: '',
    timeframe: '',
    description: '',
    target: '',
    steps: '',
    obstacles: '',
    support: ''
  }]);
  const toast = useToast();

  const handleSubmit = () => {
    if (!validateGoals()) {
      toast({
        title: 'Please complete all fields',
        status: 'warning',
        duration: 3000,
      });
      return;
    }

    onComplete(goals);
    toast({
      title: 'Goals saved successfully',
      status: 'success',
      duration: 3000,
    });
  };

  const validateGoals = () => {
    return goals.every(goal => 
      Object.values(goal).every(value => value.trim() !== '')
    );
  };

  const updateGoal = (index: number, field: keyof Goal, value: string) => {
    const updatedGoals = [...goals];
    updatedGoals[index] = { ...updatedGoals[index], [field]: value };
    setGoals(updatedGoals);
  };

  return (
    <Card>
      <CardHeader>
        <Heading size="lg">Goal Setting Worksheet</Heading>
        <Text mt={2} color="gray.600">
          Define your SMART financial and wellness goals
        </Text>
      </CardHeader>

      <CardBody>
        <VStack spacing={6} align="stretch">
          {goals.map((goal, index) => (
            <Box key={index} p={6} bg="gray.50" rounded="lg">
              <VStack spacing={4} align="stretch">
                <FormControl isRequired>
                  <FormLabel>Goal Type</FormLabel>
                  <Select
                    value={goal.type}
                    onChange={(e) => updateGoal(index, 'type', e.target.value)}
                  >
                    <option value="">Select type</option>
                    <option value="financial">Financial</option>
                    <option value="wellness">Mental Wellness</option>
                    <option value="combined">Combined</option>
                  </Select>
                </FormControl>

                <FormControl isRequired>
                  <FormLabel>Timeframe</FormLabel>
                  <Select
                    value={goal.timeframe}
                    onChange={(e) => updateGoal(index, 'timeframe', e.target.value)}
                  >
                    <option value="">Select timeframe</option>
                    <option value="short">Short-term (1-3 months)</option>
                    <option value="medium">Medium-term (3-12 months)</option>
                    <option value="long">Long-term (1+ years)</option>
                  </Select>
                </FormControl>

                <FormControl isRequired>
                  <FormLabel>Goal Description</FormLabel>
                  <Textarea
                    value={goal.description}
                    onChange={(e) => updateGoal(index, 'description', e.target.value)}
                    placeholder="What do you want to achieve?"
                  />
                </FormControl>

                <FormControl isRequired>
                  <FormLabel>Specific Target</FormLabel>
                  <Input
                    value={goal.target}
                    onChange={(e) => updateGoal(index, 'target', e.target.value)}
                    placeholder="e.g., Save $5000, Reduce anxiety to manageable level"
                  />
                </FormControl>

                <FormControl isRequired>
                  <FormLabel>Action Steps</FormLabel>
                  <Textarea
                    value={goal.steps}
                    onChange={(e) => updateGoal(index, 'steps', e.target.value)}
                    placeholder="List the specific steps you'll take"
                  />
                </FormControl>

                <FormControl isRequired>
                  <FormLabel>Potential Obstacles</FormLabel>
                  <Textarea
                    value={goal.obstacles}
                    onChange={(e) => updateGoal(index, 'obstacles', e.target.value)}
                    placeholder="What might get in your way?"
                  />
                </FormControl>

                <FormControl isRequired>
                  <FormLabel>Support Needed</FormLabel>
                  <Textarea
                    value={goal.support}
                    onChange={(e) => updateGoal(index, 'support', e.target.value)}
                    placeholder="What resources or support will help you succeed?"
                  />
                </FormControl>
              </VStack>
            </Box>
          ))}

          <Button
            onClick={() => setGoals([...goals, {
              type: '',
              timeframe: '',
              description: '',
              target: '',
              steps: '',
              obstacles: '',
              support: ''
            }])}
            variant="outline"
            colorScheme="purple"
          >
            Add Another Goal
          </Button>

          <Button
            colorScheme="purple"
            size="lg"
            onClick={handleSubmit}
            bgGradient="linear(to-r, purple.500, blue.500)"
            _hover={{
              bgGradient: "linear(to-r, purple.600, blue.600)",
            }}
          >
            Save Goals
          </Button>
        </VStack>
      </CardBody>
    </Card>
  );
}