import {
  Box,
  Button,
  Card,
  CardBody,
  CardHeader,
  Heading,
  Text,
  VStack,
  CircularProgress,
  CircularProgressLabel,
  Badge,
} from '@chakra-ui/react';

interface Props {
  score: number;
  onRetake: () => void;
  onContinue: () => void;
}

export default function QuizResults({ score, onRetake, onContinue }: Props) {
  const isPassing = score >= 70;

  return (
    <Card>
      <CardHeader>
        <Heading size="md">Quiz Results</Heading>
      </CardHeader>

      <CardBody>
        <VStack spacing={6} align="center">
          <CircularProgress
            value={score}
            size="120px"
            thickness="8px"
            color={isPassing ? "green.400" : "red.400"}
          >
            <CircularProgressLabel>
              {score}%
            </CircularProgressLabel>
          </CircularProgress>

          <Badge
            colorScheme={isPassing ? "green" : "red"}
            fontSize="md"
            px={3}
            py={1}
          >
            {isPassing ? "Passed" : "Not Passed"}
          </Badge>

          <Text align="center" color="gray.600">
            {isPassing
              ? "Great job! You've demonstrated a good understanding of the module concepts."
              : "You might want to review the module material and try again to ensure better understanding."}
          </Text>

          <Box>
            {!isPassing && (
              <Button
                colorScheme="purple"
                variant="outline"
                onClick={onRetake}
                mb={4}
                w="full"
              >
                Retake Quiz
              </Button>
            )}
            <Button
              colorScheme="purple"
              onClick={onContinue}
              w="full"
              isDisabled={!isPassing}
            >
              Continue to Next Module
            </Button>
          </Box>
        </VStack>
      </CardBody>
    </Card>
  );
}