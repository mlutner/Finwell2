import {
  Grid,
  Card,
  CardHeader,
  CardBody,
  Heading,
  Text,
  Button,
  Badge,
  VStack,
  HStack,
  Icon,
} from '@chakra-ui/react';
import { FiVideo, FiMessageSquare, FiPhone, FiCalendar, FiStar } from 'react-icons/fi';

interface Props {
  onBooking: () => void;
}

export default function ConsultationOverview({ onBooking }: Props) {
  return (
    <Grid templateColumns={{ base: '1fr', md: 'repeat(2, 1fr)', lg: 'repeat(3, 1fr)' }} gap={6}>
      {/* Support Status */}
      <Card>
        <CardHeader>
          <Heading size="md">Your Support Status</Heading>
        </CardHeader>
        <CardBody>
          <VStack spacing={4} align="stretch">
            <HStack justify="space-between">
              <Text color="gray.600">Support Level</Text>
              <Badge colorScheme="purple">Premium Care</Badge>
            </HStack>
            <HStack justify="space-between">
              <Text color="gray.600">Next Session</Text>
              <Text fontWeight="medium">Not Scheduled</Text>
            </HStack>
            <Button
              colorScheme="purple"
              onClick={onBooking}
              w="full"
            >
              Schedule Session
            </Button>
          </VStack>
        </CardBody>
      </Card>

      {/* Available Support */}
      <Card>
        <CardHeader>
          <Heading size="md">Available Support</Heading>
        </CardHeader>
        <CardBody>
          <VStack spacing={4} align="stretch">
            <HStack p={3} bg="blue.50" rounded="lg">
              <Icon as={FiVideo} color="blue.500" />
              <Box>
                <Text fontWeight="medium">Video Consultation</Text>
                <Text fontSize="sm" color="gray.600">1-on-1 video sessions</Text>
              </Box>
            </HStack>
            <HStack p={3} bg="green.50" rounded="lg">
              <Icon as={FiMessageSquare} color="green.500" />
              <Box>
                <Text fontWeight="medium">Chat Support</Text>
                <Text fontSize="sm" color="gray.600">24/7 chat assistance</Text>
              </Box>
            </HStack>
            <HStack p={3} bg="purple.50" rounded="lg">
              <Icon as={FiPhone} color="purple.500" />
              <Box>
                <Text fontWeight="medium">Phone Support</Text>
                <Text fontSize="sm" color="gray.600">Direct phone consultations</Text>
              </Box>
            </HStack>
          </VStack>
        </CardBody>
      </Card>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <Heading size="md">Recent Activity</Heading>
        </CardHeader>
        <CardBody>
          <VStack spacing={4} align="stretch">
            <HStack justify="space-between" p={3} border="1px" borderColor="gray.200" rounded="lg">
              <HStack spacing={3}>
                <Icon as={FiCalendar} color="gray.500" />
                <Box>
                  <Text fontWeight="medium">Initial Assessment</Text>
                  <Text fontSize="sm" color="gray.600">Completed on Nov 15</Text>
                </Box>
              </HStack>
              <Badge variant="subtle">Complete</Badge>
            </HStack>
            <HStack justify="space-between" p={3} border="1px" borderColor="gray.200" rounded="lg">
              <HStack spacing={3}>
                <Icon as={FiStar} color="gray.500" />
                <Box>
                  <Text fontWeight="medium">Support Plan Created</Text>
                  <Text fontSize="sm" color="gray.600">Updated Nov 16</Text>
                </Box>
              </HStack>
              <Badge variant="subtle" colorScheme="green">Active</Badge>
            </HStack>
          </VStack>
        </CardBody>
      </Card>
    </Grid>
  );
}