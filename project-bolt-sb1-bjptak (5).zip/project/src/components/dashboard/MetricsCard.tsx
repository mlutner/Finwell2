import {
  Box,
  CircularProgress,
  CircularProgressLabel,
  Grid,
  Heading,
  Text,
  VStack,
  Flex,
  Button,
  ButtonGroup,
} from '@chakra-ui/react';
import { useState } from 'react';
import { Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

interface MetricBarProps {
  label: string;
  value: number;
  icon?: React.ReactNode;
}

const moodVsSpendData = {
  labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
  datasets: [
    {
      label: 'Mood Score',
      data: [85, 75, 82, 78, 90, 88, 85],
      backgroundColor: 'rgba(124, 58, 237, 0.5)',
      borderColor: 'rgba(124, 58, 237, 1)',
      borderWidth: 1,
      yAxisID: 'y',
    },
    {
      label: 'Daily Spend',
      data: [120, 200, 150, 80, 70, 180, 90],
      backgroundColor: 'rgba(49, 130, 206, 0.5)',
      borderColor: 'rgba(49, 130, 206, 1)',
      borderWidth: 1,
      yAxisID: 'y1',
    },
  ],
};

const options = {
  responsive: true,
  interaction: {
    mode: 'index' as const,
    intersect: false,
  },
  scales: {
    y: {
      type: 'linear' as const,
      display: true,
      position: 'left' as const,
      title: {
        display: true,
        text: 'Mood Score',
      },
      min: 0,
      max: 100,
    },
    y1: {
      type: 'linear' as const,
      display: true,
      position: 'right' as const,
      title: {
        display: true,
        text: 'Spending ($)',
      },
      min: 0,
      grid: {
        drawOnChartArea: false,
      },
    },
  },
};

function MetricBar({ label, value, icon }: MetricBarProps) {
  return (
    <VStack spacing={2} align="stretch">
      <Flex justify="space-between" align="center">
        <Text color="gray.600" fontSize="sm">{label}</Text>
        <Text fontWeight="medium">{value}%</Text>
      </Flex>
      <Box h="2" bg="gray.100" rounded="full" overflow="hidden">
        <Box
          h="full"
          bg="purple.500"
          rounded="full"
          transition="width 0.3s"
          w={`${value}%`}
        />
      </Box>
    </VStack>
  );
}

export default function MetricsCard() {
  const [activeView, setActiveView] = useState<'wellbeing' | 'mood'>('wellbeing');
  const wellbeingScore = 78;
  const moodScore = 82;

  return (
    <Box bg="white" rounded="lg" shadow="sm" p={6}>
      <VStack spacing={6} align="stretch">
        <Flex justify="space-between" align="center">
          <Box>
            <Heading size="md" mb={1}>Financial Wellbeing</Heading>
            <ButtonGroup size="sm" isAttached variant="outline" borderRadius="full" p="1" bg="gray.50">
              <Button
                onClick={() => setActiveView('wellbeing')}
                borderRadius="full"
                bg={activeView === 'wellbeing' ? 'white' : 'transparent'}
                color={activeView === 'wellbeing' ? 'purple.600' : 'gray.600'}
                borderColor={activeView === 'wellbeing' ? 'purple.200' : 'transparent'}
                boxShadow={activeView === 'wellbeing' ? 'sm' : 'none'}
                _hover={{ bg: activeView === 'wellbeing' ? 'white' : 'gray.100' }}
              >
                Score
              </Button>
              <Button
                onClick={() => setActiveView('mood')}
                borderRadius="full"
                bg={activeView === 'mood' ? 'white' : 'transparent'}
                color={activeView === 'mood' ? 'purple.600' : 'gray.600'}
                borderColor={activeView === 'mood' ? 'purple.200' : 'transparent'}
                boxShadow={activeView === 'mood' ? 'sm' : 'none'}
                _hover={{ bg: activeView === 'mood' ? 'white' : 'gray.100' }}
              >
                Mood vs. Spend
              </Button>
            </ButtonGroup>
          </Box>
        </Flex>

        {activeView === 'wellbeing' ? (
          <>
            <Flex justify="center" py={6}>
              <CircularProgress
                value={wellbeingScore}
                size="160px"
                thickness="8px"
                color="purple.500"
                trackColor="purple.50"
              >
                <CircularProgressLabel>
                  <VStack spacing={0}>
                    <Text fontSize="4xl" fontWeight="bold" lineHeight="1">
                      {wellbeingScore}
                    </Text>
                    <Text fontSize="sm" color="gray.500">/100</Text>
                  </VStack>
                </CircularProgressLabel>
              </CircularProgress>
            </Flex>

            <Grid templateColumns="repeat(2, 1fr)" gap={4}>
              <MetricBar label="Mindset" value={80} />
              <MetricBar label="Resiliency" value={75} />
              <MetricBar label="Consistency" value={85} />
              <MetricBar label="Spending" value={70} />
            </Grid>
          </>
        ) : (
          <Box h="300px">
            <Bar options={options} data={moodVsSpendData} />
          </Box>
        )}
      </VStack>
    </Box>
  );
}