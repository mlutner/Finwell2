import {
  Box,
  Button,
  Heading,
  HStack,
  Text,
  VStack,
  Card,
  CardHeader,
  CardBody,
} from '@chakra-ui/react';

interface MoodButtonProps {
  label: string;
  onClick: () => void;
  size?: string;
}

function MoodButton({ label, onClick, size = "16" }: MoodButtonProps) {
  return (
    <VStack spacing={1}>
      <Button
        w={size}
        h={size}
        rounded="full"
        variant="ghost"
        _hover={{ bg: 'purple.100' }}
        onClick={onClick}
        fontSize={size === "16" ? "2xl" : "xl"}
      >
        {/* Add mood emoji based on label */}
        {label === 'Great' && '😄'}
        {label === 'Good' && '🙂'}
        {label === 'Ok' && '😐'}
        {label === 'Low' && '😕'}
        {label === 'Bad' && '😢'}
      </Button>
      <Text fontSize="sm" color="gray.600">{label}</Text>
    </VStack>
  );
}

export default function MoodTracker() {
  const handleMoodSelect = (mood: string) => {
    // TODO: Implement mood tracking
    console.log('Selected mood:', mood);
  };

  return (
    <Card>
      <CardHeader>
        <Heading size="md" textAlign="center">How are you feeling today?</Heading>
      </CardHeader>
      <CardBody>
        <HStack justify="center" spacing={8}>
          <MoodButton label="Bad" onClick={() => handleMoodSelect('Bad')} size="16" />
          <MoodButton label="Low" onClick={() => handleMoodSelect('Low')} size="16" />
          <MoodButton label="Ok" onClick={() => handleMoodSelect('Ok')} size="16" />
          <MoodButton label="Good" onClick={() => handleMoodSelect('Good')} size="16" />
          <MoodButton label="Great" onClick={() => handleMoodSelect('Great')} size="16" />
        </HStack>
      </CardBody>
    </Card>
  );
}