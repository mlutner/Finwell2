import {
  Box,
  Button,
  Card,
  CardBody,
  CardHeader,
  Heading,
  List,
  ListIcon,
  ListItem,
  Stack,
  Text,
  VStack,
  Badge,
  Divider,
} from '@chakra-ui/react';
import { CheckCircleIcon, WarningIcon, InfoIcon } from '@chakra-ui/icons';
import { useNavigate } from 'react-router-dom';

interface Props {
  data: any;
  analysis: {
    riskLevel: string;
    sentiment: string;
    emotionalTriggers: string[];
    recommendations: {
      cbt: string[];
      financial: string[];
      combined: string[];
    };
    suggestedModules: string[];
  };
}

export default function AssessmentResults({ data, analysis }: Props) {
  const navigate = useNavigate();

  const getRiskColor = (level: string) => {
    switch (level) {
      case 'low': return 'green';
      case 'moderate': return 'yellow';
      case 'high': return 'orange';
      case 'severe': return 'red';
      default: return 'gray';
    }
  };

  return (
    <VStack spacing={6} align="stretch">
      <Card>
        <CardHeader>
          <Stack direction="row" justify="space-between" align="center">
            <Heading size="lg">Assessment Results</Heading>
            <Badge
              colorScheme={getRiskColor(analysis.riskLevel)}
              fontSize="md"
              px={3}
              py={1}
              borderRadius="full"
            >
              {analysis.riskLevel.toUpperCase()} RISK
            </Badge>
          </Stack>
        </CardHeader>

        <CardBody>
          <VStack spacing={6} align="stretch">
            <Box>
              <Heading size="md" mb={4}>Emotional Analysis</Heading>
              <Text>Current Sentiment: {analysis.sentiment}</Text>
              <Text mt={2}>Identified Emotional Triggers:</Text>
              <List spacing={2} mt={2}>
                {analysis.emotionalTriggers.map((trigger, index) => (
                  <ListItem key={index} display="flex" alignItems="center">
                    <ListIcon as={WarningIcon} color="orange.500" />
                    {trigger}
                  </ListItem>
                ))}
              </List>
            </Box>

            <Divider />

            <Box>
              <Heading size="md" mb={4}>Recommendations</Heading>
              
              <Text fontWeight="medium" mb={2}>CBT Techniques:</Text>
              <List spacing={2} mb={4}>
                {analysis.recommendations.cbt.map((rec, index) => (
                  <ListItem key={index} display="flex" alignItems="center">
                    <ListIcon as={CheckCircleIcon} color="green.500" />
                    {rec}
                  </ListItem>
                ))}
              </List>

              <Text fontWeight="medium" mb={2}>Financial Steps:</Text>
              <List spacing={2} mb={4}>
                {analysis.recommendations.financial.map((rec, index) => (
                  <ListItem key={index} display="flex" alignItems="center">
                    <ListIcon as={CheckCircleIcon} color="green.500" />
                    {rec}
                  </ListItem>
                ))}
              </List>

              <Text fontWeight="medium" mb={2}>Combined Approach:</Text>
              <List spacing={2}>
                {analysis.recommendations.combined.map((rec, index) => (
                  <ListItem key={index} display="flex" alignItems="center">
                    <ListIcon as={CheckCircleIcon} color="green.500" />
                    {rec}
                  </ListItem>
                ))}
              </List>
            </Box>

            <Divider />

            <Box>
              <Heading size="md" mb={4}>Suggested Learning Path</Heading>
              <List spacing={3}>
                {analysis.suggestedModules.map((module, index) => (
                  <ListItem key={index} display="flex" alignItems="center">
                    <ListIcon as={InfoIcon} color="blue.500" />
                    {module}
                  </ListItem>
                ))}
              </List>
            </Box>
          </VStack>
        </CardBody>
      </Card>

      <Stack direction="row" spacing={4} justify="center">
        <Button
          colorScheme="purple"
          size="lg"
          onClick={() => navigate('/dashboard')}
        >
          Go to Dashboard
        </Button>
        <Button
          variant="outline"
          colorScheme="purple"
          size="lg"
          onClick={() => navigate('/learning-path')}
        >
          Start Learning Path
        </Button>
      </Stack>
    </VStack>
  );
}