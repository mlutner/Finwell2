import { useState } from 'react';
import {
  Box,
  Button,
  FormControl,
  FormLabel,
  Select,
  Textarea,
  VStack,
  Slider,
  SliderTrack,
  SliderFilledTrack,
  SliderThumb,
  Text,
  Heading,
  useToast,
} from '@chakra-ui/react';
import type { MoodEntry } from '../../types/assessment';

interface Props {
  onSubmit: (entry: MoodEntry) => void;
}

function MoodTracker({ onSubmit }: Props) {
  const [mood, setMood] = useState<MoodEntry['mood']>('neutral');
  const [anxiety, setAnxiety] = useState(5);
  const [notes, setNotes] = useState('');
  const toast = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const entry: MoodEntry = {
      date: new Date().toISOString(),
      mood,
      financialAnxiety: anxiety,
      notes: notes.trim() || undefined,
    };

    onSubmit(entry);
    toast({
      title: 'Mood tracked',
      description: 'Your mood has been recorded successfully.',
      status: 'success',
      duration: 3000,
    });

    // Reset form
    setMood('neutral');
    setAnxiety(5);
    setNotes('');
  };

  return (
    <Box maxW="xl" mx="auto" mt={8}>
      <Heading size="lg" mb={6}>Daily Mood Tracker</Heading>
      <form onSubmit={handleSubmit}>
        <VStack spacing={6} align="stretch">
          <FormControl>
            <FormLabel>How are you feeling today?</FormLabel>
            <Select value={mood} onChange={(e) => setMood(e.target.value as MoodEntry['mood'])}>
              <option value="very_negative">Very Negative</option>
              <option value="negative">Negative</option>
              <option value="neutral">Neutral</option>
              <option value="positive">Positive</option>
              <option value="very_positive">Very Positive</option>
            </Select>
          </FormControl>

          <FormControl>
            <FormLabel>Financial Anxiety Level (1-10)</FormLabel>
            <Slider
              value={anxiety}
              onChange={setAnxiety}
              min={1}
              max={10}
              step={1}
            >
              <SliderTrack>
                <SliderFilledTrack />
              </SliderTrack>
              <SliderThumb />
            </Slider>
            <Text textAlign="center" mt={2}>
              {anxiety}
            </Text>
          </FormControl>

          <FormControl>
            <FormLabel>Notes (optional)</FormLabel>
            <Textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Any specific thoughts or events affecting your mood today?"
            />
          </FormControl>

          <Button type="submit" colorScheme="blue" size="lg">
            Track Mood
          </Button>
        </VStack>
      </form>
    </Box>
  );
}

export default MoodTracker;