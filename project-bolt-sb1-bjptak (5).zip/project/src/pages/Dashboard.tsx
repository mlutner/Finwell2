import {
  Box,
  Container,
  Grid,
  Heading,
  Text,
  VStack,
  SimpleGrid,
} from '@chakra-ui/react';
import { useState } from 'react';
import MetricsCard from '../components/dashboard/MetricsCard';
import MoodTracker from '../components/dashboard/MoodTracker';
import QuickActions from '../components/dashboard/QuickActions';
import SpendingGraph from '../components/dashboard/SpendingGraph';
import LearningPathways from '../components/dashboard/LearningPathways';
import UserEngagement from '../components/engagement/UserEngagement';

export default function Dashboard() {
  const [currentMood, setCurrentMood] = useState<string | null>(null);

  const handleMoodSelect = (mood: string) => {
    setCurrentMood(mood);
  };

  return (
    <Container maxW="container.xl">
      {/* Header Section - Centered */}
      <Box textAlign="center" pt={8} pb={6}>
        <Heading size="lg" mb={2}>Dashboard</Heading>
        <Text color="gray.600">
          Welcome back! Here's your financial wellness overview.
        </Text>
      </Box>

      <VStack spacing={8} align="stretch">
        {/* Mood Tracker - Centered and Narrower */}
        <Box maxW="container.sm" mx="auto">
          <MoodTracker onMoodSelect={handleMoodSelect} />
        </Box>

        {/* Weekly Overview */}
        <UserEngagement />

        {/* Main Content Grid */}
        <SimpleGrid columns={{ base: 1, lg: 2 }} spacing={6}>
          <MetricsCard />
          <SpendingGraph />
        </SimpleGrid>

        {/* Secondary Content */}
        <Grid templateColumns={{ base: '1fr', lg: 'repeat(2, 1fr)' }} gap={6}>
          <QuickActions />
          <LearningPathways />
        </Grid>
      </VStack>
    </Container>
  );
}