import {
  Box,
  Button,
  Container,
  Flex,
  Grid,
  Heading,
  IconButton,
  Progress,
  Text,
  useToast,
} from '@chakra-ui/react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FiArrowLeft } from 'react-icons/fi';
import ModuleGrid from '../components/cbt/ModuleGrid';
import ModuleDetail from '../components/cbt/ModuleDetail';
import { CBTModule } from '../types/cbt';

export default function CBTProgram() {
  const [selectedModule, setSelectedModule] = useState<CBTModule | null>(null);
  const navigate = useNavigate();
  const toast = useToast();

  const handleBack = () => {
    navigate('/');
  };

  return (
    <Container maxW="container.xl" py={8}>
      <Flex direction="column" gap={6}>
        {/* Back Button */}
        <IconButton
          aria-label="Back to dashboard"
          icon={<FiArrowLeft />}
          variant="ghost"
          alignSelf="flex-start"
          onClick={handleBack}
          size="lg"
          _hover={{
            transform: "translateX(-2px)",
            bg: "gray.100"
          }}
          transition="all 0.2s"
        />

        {/* Header */}
        <Flex justify="space-between" align="center">
          <Box>
            <Heading size="lg">Financial Wellness Program</Heading>
            <Text color="gray.600">8-Module CBT Program for Financial Health</Text>
          </Box>
          <Flex align="center" gap={4}>
            <Text color="gray.600">Overall Progress</Text>
            <Progress value={12} size="sm" width="200px" colorScheme="purple" />
            <Text fontWeight="bold" color="purple.500">12%</Text>
          </Flex>
        </Flex>

        {/* Content */}
        <Box>
          {selectedModule ? (
            <ModuleDetail
              module={selectedModule}
              onBack={() => setSelectedModule(null)}
            />
          ) : (
            <ModuleGrid
              onSelectModule={setSelectedModule}
            />
          )}
        </Box>
      </Flex>
    </Container>
  );
}