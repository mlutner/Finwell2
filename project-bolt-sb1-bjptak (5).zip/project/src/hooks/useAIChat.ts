import { useState, useCallback } from 'react';
import { useAuth } from '../contexts/AuthContext';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  timestamp: Date;
}

export function useAIChat(context: string, initialMessage?: string) {
  const [messages, setMessages] = useState<Message[]>(() => 
    initialMessage 
      ? [{
          id: '0',
          text: initialMessage,
          sender: 'ai',
          timestamp: new Date()
        }]
      : []
  );
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const { user } = useAuth();

  const generateResponse = useCallback(async (userMessage: string) => {
    // TODO: Implement actual AI response generation
    // For now, return mock responses based on context and message content
    await new Promise(resolve => setTimeout(resolve, 1000));

    if (userMessage.toLowerCase().includes('anxious')) {
      return "I understand feeling anxious about finances can be overwhelming. Let's break down what's causing this anxiety and explore some coping strategies.";
    }

    if (userMessage.toLowerCase().includes('help')) {
      return "I'm here to help! Could you tell me more specifically what you'd like assistance with?";
    }

    if (context === 'assessment') {
      return "I'm here to guide you through the assessment. What would you like to know?";
    }

    return "I understand. Could you tell me more about that?";
  }, [context]);

  const sendMessage = useCallback(async () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: input,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    try {
      const response = await generateResponse(input);
      
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: response,
        sender: 'ai',
        timestamp: new Date()
      };

      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
      console.error('Error generating AI response:', error);
    } finally {
      setIsTyping(false);
    }
  }, [input, generateResponse]);

  return {
    messages,
    input,
    setInput,
    sendMessage,
    isTyping
  };
}