import { CBTModule } from '../types/cbt';

export const modules: CBTModule[] = [
  {
    id: 1,
    title: "Goal Setting & Initial Assessment",
    description: "Establish personal financial and mental health goals, assess current behaviors.",
    duration: "45 mins",
    status: "available",
    progress: 0,
    exercises: [
      {
        id: "1-1",
        title: "Financial Goals Worksheet",
        type: "worksheet",
        completed: false
      },
      {
        id: "1-2",
        title: "Current Behavior Assessment",
        type: "quiz",
        completed: false
      },
      {
        id: "1-3",
        title: "Confidence Log",
        type: "journal",
        completed: false
      }
    ]
  },
  {
    id: 2,
    title: "First Steps & Taking Action",
    description: "Begin your journey toward financial control with actionable steps.",
    duration: "60 mins",
    status: "locked",
    progress: 0,
    exercises: [
      {
        id: "2-1",
        title: "Action Plan Creation",
        type: "worksheet",
        completed: false
      },
      {
        id: "2-2",
        title: "Triggers and Solutions Log",
        type: "journal",
        completed: false
      }
    ]
  },
  {
    id: 3,
    title: "Understanding Financial Emotions",
    description: "Explore the emotional aspects of your financial decisions.",
    duration: "45 mins",
    status: "locked",
    progress: 0,
    exercises: [
      {
        id: "3-1",
        title: "Emotional Spending Quiz",
        type: "quiz",
        completed: false
      },
      {
        id: "3-2",
        title: "Money Beliefs Journal",
        type: "journal",
        completed: false
      }
    ]
  }
];