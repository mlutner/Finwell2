import { z } from 'zod';

export const AssessmentStepSchema = z.object({
  id: z.string(),
  title: z.string(),
  description: z.string().optional(),
  type: z.enum(['single-select', 'multi-select', 'scale', 'text', 'mood']),
  options: z.array(z.object({
    id: z.string(),
    label: z.string(),
    description: z.string().optional(),
    icon: z.string().optional()
  })).optional(),
  required: z.boolean().optional(),
  validationRules: z.object({
    min: z.number().optional(),
    max: z.number().optional(),
    pattern: z.instanceof(RegExp).optional()
  }).optional()
});

export const AssessmentResponseSchema = z.object({
  stepId: z.string(),
  response: z.any(),
  timestamp: z.number()
});

export const AssessmentStateSchema = z.object({
  currentStep: z.number(),
  responses: z.record(z.string(), AssessmentResponseSchema),
  isComplete: z.boolean(),
  riskLevel: z.enum(['low', 'medium', 'high']).optional()
});

export type AssessmentStep = z.infer<typeof AssessmentStepSchema>;
export type AssessmentResponse = z.infer<typeof AssessmentResponseSchema>;
export type AssessmentState = z.infer<typeof AssessmentStateSchema>;