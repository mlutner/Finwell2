import { config } from './config';
import { HfInference } from '@huggingface/inference';

export async function testAPIs() {
  const results = {
    huggingface: false
  };

  if (config.huggingface.available) {
    try {
      const hf = new HfInference(config.huggingface.apiKey);
      
      await hf.textGeneration({
        model: config.huggingface.defaultModel,
        inputs: "Test",
        parameters: {
          max_new_tokens: 5
        }
      });

      results.huggingface = true;
      console.log("✅ Hugging Face API is working");
    } catch (error) {
      console.log("❌ Hugging Face API Error:", error);
    }
  }

  return results;
}