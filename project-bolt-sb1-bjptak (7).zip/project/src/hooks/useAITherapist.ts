import { useState, useCallback } from 'react';
import { useToast } from '@chakra-ui/react';
import { HfInference } from '@huggingface/inference';
import { getCachedResponse, cacheResponse } from '../lib/ai/cache';
import { config } from '../lib/ai/config';
import type { Message } from '../types/chat';
import { MOCK_RESPONSES } from '../lib/ai/config';

// Initialize Hugging Face only if available
const hf = config.huggingface.available ? new HfInference(config.huggingface.apiKey) : null;

export function useAITherapist() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '0',
      text: "Hi! I'm your AI Financial Therapist. How can I help you today?",
      sender: 'ai',
      timestamp: new Date(),
    },
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const toast = useToast();

  const getAIResponse = async (prompt: string, context?: any) => {
    // Check cache first
    const cached = await getCachedResponse(prompt, context);
    if (cached) return cached.response;

    if (config.useMockResponses) {
      // Use mock responses in demo mode
      const randomResponse = MOCK_RESPONSES.therapist[
        Math.floor(Math.random() * MOCK_RESPONSES.therapist.length)
      ];
      return randomResponse;
    }

    try {
      if (!hf || !config.huggingface.available) {
        throw new Error('AI service is not configured');
      }

      const result = await hf.textGeneration({
        model: config.huggingface.defaultModel,
        inputs: prompt,
        parameters: {
          max_new_tokens: 150,
          temperature: 0.7,
          top_p: 0.95,
          repetition_penalty: 1.2
        }
      });

      const response = result.generated_text;
      
      // Cache successful response
      await cacheResponse(prompt, response, 'huggingface', context);
      return response;
    } catch (error) {
      console.error('AI Service Error:', error);
      throw error;
    }
  };

  const sendMessage = useCallback(async (text: string) => {
    try {
      setIsLoading(true);
      
      const userMessage: Message = {
        id: Date.now().toString(),
        text,
        sender: 'user',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, userMessage]);

      const aiResponse = await getAIResponse(text);
      
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: aiResponse,
        sender: 'ai',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, aiMessage]);

    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to get AI response. Please try again.',
        status: 'error',
        duration: 3000,
      });
    } finally {
      setIsLoading(false);
    }
  }, [toast]);

  return {
    messages,
    sendMessage,
    isLoading,
  };
}