import { useState } from 'react';
import { HfInference } from '@huggingface/inference';
import { config } from '../lib/ai/config';
import { getCachedResponse, cacheResponse } from '../lib/ai/cache';

const mockAnalysis = {
  riskLevel: 'moderate' as const,
  sentiment: 'neutral' as const,
  emotionalTriggers: ['financial stress', 'impulsive spending', 'money anxiety'],
  recommendations: {
    cbt: [
      'Practice mindfulness when making financial decisions',
      'Challenge negative money beliefs',
      'Keep a financial thought diary'
    ],
    financial: [
      'Create a monthly budget',
      'Track daily expenses',
      'Build an emergency fund'
    ],
    combined: [
      'Set realistic financial goals aligned with your values',
      'Develop healthy money habits through CBT techniques',
      'Practice self-compassion during financial setbacks'
    ]
  },
  suggestedModules: [
    'Financial Mindset Fundamentals',
    'Emotional Spending Awareness',
    'Building Healthy Money Habits'
  ]
};

export function useAIAnalysis() {
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const analyzeResponses = async (assessmentData: any) => {
    setIsAnalyzing(true);
    try {
      // Check cache first
      const cached = await getCachedResponse('assessment_analysis', assessmentData);
      if (cached) return cached;

      if (!config.huggingface.available) {
        return mockAnalysis;
      }

      const hf = new HfInference(config.huggingface.apiKey);
      
      const prompt = generatePrompt(assessmentData);
      const result = await hf.textGeneration({
        model: config.huggingface.defaultModel,
        inputs: prompt,
        parameters: {
          max_new_tokens: 150,
          temperature: 0.7,
          top_p: 0.95,
        }
      });

      const analysis = parseAnalysis(result.generated_text);
      
      // Cache the results
      await cacheResponse('assessment_analysis', analysis, 'huggingface', assessmentData);
      
      return analysis;
    } catch (error) {
      console.error('AI Analysis Error:', error);
      return mockAnalysis;
    } finally {
      setIsAnalyzing(false);
    }
  };

  return {
    analyzeResponses,
    isAnalyzing,
  };
}

function generatePrompt(data: any): string {
  return `
    Analyze the following financial wellness assessment data:
    
    Initial Assessment:
    ${JSON.stringify(data.initial, null, 2)}
    
    Emotional Assessment:
    ${JSON.stringify(data.emotional, null, 2)}
    
    Financial Assessment:
    ${JSON.stringify(data.financial, null, 2)}
    
    Please provide:
    1. Risk level assessment (low, moderate, high)
    2. Sentiment analysis
    3. Identified emotional triggers
    4. CBT-based recommendations
    5. Financial recommendations
    6. Combined therapy approach suggestions
    7. Recommended learning modules
  `;
}

function parseAnalysis(response: string): typeof mockAnalysis {
  try {
    // In a real implementation, parse the AI response
    // For now, return mock data
    return mockAnalysis;
  } catch (error) {
    console.error('Error parsing AI response:', error);
    return mockAnalysis;
  }
}