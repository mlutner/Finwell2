import { useState, useCallback } from 'react';
import { useToast } from '@chakra-ui/react';
import axios from 'axios';
import type { WearableProvider, WearableMetrics, WearableConnection } from '../types/wearables';

export function useWearables() {
  const [connections, setConnections] = useState<WearableConnection[]>([]);
  const [isConnecting, setIsConnecting] = useState(false);
  const [metrics, setMetrics] = useState<WearableMetrics | null>(null);
  const toast = useToast();

  const connect = useCallback(async (provider: WearableProvider) => {
    setIsConnecting(true);
    try {
      // Each provider has its own OAuth flow
      switch (provider) {
        case 'fitbit':
          window.location.href = '/api/auth/fitbit';
          break;
        case 'apple':
          // Apple Health requires native iOS integration
          if ('webkit' in window) {
            // @ts-ignore
            window.webkit.messageHandlers.healthKit.postMessage('requestAuthorization');
          } else {
            throw new Error('Apple Health is only available on iOS devices');
          }
          break;
        default:
          throw new Error(`Unsupported provider: ${provider}`);
      }

      setConnections(prev => [...prev, {
        provider,
        connected: true,
        lastSync: new Date().toISOString()
      }]);

      toast({
        title: 'Device Connected',
        description: `Successfully connected to ${provider}`,
        status: 'success',
        duration: 3000,
      });
    } catch (error) {
      toast({
        title: 'Connection Failed',
        description: error instanceof Error ? error.message : 'Failed to connect device',
        status: 'error',
        duration: 5000,
      });
    } finally {
      setIsConnecting(false);
    }
  }, [toast]);

  const disconnect = useCallback(async (provider: WearableProvider) => {
    try {
      await axios.post(`/api/wearables/${provider}/disconnect`);
      
      setConnections(prev => 
        prev.filter(conn => conn.provider !== provider)
      );

      toast({
        title: 'Device Disconnected',
        description: `Successfully disconnected from ${provider}`,
        status: 'success',
        duration: 3000,
      });
    } catch (error) {
      toast({
        title: 'Disconnect Failed',
        description: 'Failed to disconnect device',
        status: 'error',
        duration: 5000,
      });
    }
  }, [toast]);

  const syncMetrics = useCallback(async (provider: WearableProvider) => {
    try {
      const response = await axios.get(`/api/wearables/${provider}/metrics`);
      const newMetrics: WearableMetrics = response.data;
      
      setMetrics(newMetrics);
      
      // Update last sync time
      setConnections(prev =>
        prev.map(conn =>
          conn.provider === provider
            ? { ...conn, lastSync: new Date().toISOString() }
            : conn
        )
      );

      return newMetrics;
    } catch (error) {
      toast({
        title: 'Sync Failed',
        description: 'Failed to sync metrics from device',
        status: 'error',
        duration: 5000,
      });
      return null;
    }
  }, [toast]);

  return {
    connections,
    isConnecting,
    metrics,
    connect,
    disconnect,
    syncMetrics
  };
}