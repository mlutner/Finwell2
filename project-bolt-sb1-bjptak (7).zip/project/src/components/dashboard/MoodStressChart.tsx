import {
  Box,
  Card,
  CardBody,
  CardHeader,
  Heading,
  Text,
  Badge,
  HStack,
  Tooltip,
} from '@chakra-ui/react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip as ChartTooltip,
  Legend,
  ScatterController,
} from 'chart.js';
import { Line } from 'react-chartjs-2';
import { motion } from 'framer-motion';
import regression from 'regression';
import { useMoodTracking } from '../../hooks/useMoodTracking';
import { useCallback, useMemo } from 'react';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  ChartTooltip,
  Legend,
  ScatterController
);

const moodToValue = {
  'great': 100,
  'good': 75,
  'neutral': 50,
  'low': 25,
  'bad': 0,
};

export default function MoodStressChart() {
  const { entries } = useMoodTracking();

  const calculateCorrelation = useCallback((moodData: number[], stressData: number[]) => {
    if (moodData.length !== stressData.length || moodData.length === 0) return 0;
    
    const points = moodData.map((mood, i) => [mood, stressData[i]]);
    const result = regression.linear(points);
    return result.r2; // R-squared value as correlation coefficient
  }, []);

  const { chartData, correlationStrength } = useMemo(() => {
    const recentEntries = entries.slice(0, 7).reverse();
    const dates = recentEntries.map(entry => 
      new Date(entry.timestamp).toLocaleDateString()
    );
    
    const moodValues = recentEntries.map(entry => moodToValue[entry.mood]);
    const stressValues = recentEntries.map(entry => 
      entry.wearableMetrics?.stressScore || null
    ).filter(Boolean) as number[];

    const correlation = calculateCorrelation(moodValues, stressValues);
    
    // Calculate trend line
    const points = moodValues.map((mood, i) => [i, mood]);
    const trendline = regression.linear(points);
    const trendlineData = points.map(([x]) => trendline.predict(x)[1]);

    return {
      chartData: {
        labels: dates,
        datasets: [
          {
            label: 'Mood',
            data: moodValues,
            borderColor: 'rgb(124, 58, 237)',
            backgroundColor: 'rgba(124, 58, 237, 0.5)',
            tension: 0.4,
          },
          {
            label: 'Stress Level',
            data: stressValues,
            borderColor: 'rgb(239, 68, 68)',
            backgroundColor: 'rgba(239, 68, 68, 0.5)',
            tension: 0.4,
          },
          {
            label: 'Trend',
            data: trendlineData,
            borderColor: 'rgba(59, 130, 246, 0.5)',
            borderDash: [5, 5],
            borderWidth: 2,
            pointRadius: 0,
            fill: false,
          },
        ],
      },
      correlationStrength: Math.abs(correlation),
    };
  }, [entries, calculateCorrelation]);

  const options = {
    responsive: true,
    animation: {
      duration: 1000,
      easing: 'easeInOutQuart',
    },
    plugins: {
      legend: {
        position: 'top' as const,
      },
      tooltip: {
        callbacks: {
          label: (context: any) => {
            const label = context.dataset.label || '';
            const value = context.parsed.y;
            if (label === 'Mood') {
              const moodLabel = Object.entries(moodToValue).find(
                ([, v]) => v === value
              )?.[0];
              return `${label}: ${moodLabel || value}`;
            }
            return `${label}: ${value}`;
          },
        },
      },
    },
    scales: {
      y: {
        min: 0,
        max: 100,
        grid: {
          color: 'rgba(0, 0, 0, 0.05)',
        },
      },
      x: {
        grid: {
          display: false,
        },
      },
    },
    transitions: {
      show: {
        animations: {
          x: { duration: 0 },
          y: { duration: 1000, from: 0 },
        },
      },
    },
  };

  const getCorrelationColor = (strength: number) => {
    if (strength > 0.7) return 'red';
    if (strength > 0.4) return 'orange';
    return 'green';
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card>
        <CardHeader>
          <HStack justify="space-between" align="center" mb={2}>
            <Heading size="md">Mood & Stress Trends</Heading>
            <Tooltip 
              label={`Correlation strength indicates how closely mood and stress levels are related. 
                     Higher values suggest a stronger connection.`}
            >
              <Badge 
                colorScheme={getCorrelationColor(correlationStrength)}
                variant="subtle"
                px={2}
                py={1}
              >
                Correlation: {(correlationStrength * 100).toFixed(0)}%
              </Badge>
            </Tooltip>
          </HStack>
          <Text color="gray.600">
            Track how your mood correlates with stress levels over time
          </Text>
        </CardHeader>
        <CardBody>
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <Box h="300px">
              <Line options={options} data={chartData} />
            </Box>
          </motion.div>
        </CardBody>
      </Card>
    </motion.div>
  );
}