import {
  Box,
  Heading,
  Select,
  ButtonGroup,
  Button,
  Flex,
} from '@chakra-ui/react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Line } from 'react-chartjs-2';
import { useState } from 'react';
import { motion } from 'framer-motion';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

const options = {
  responsive: true,
  interaction: {
    mode: 'index' as const,
    intersect: false,
  },
  scales: {
    y: {
      type: 'linear' as const,
      display: true,
      position: 'left' as const,
      title: {
        display: true,
        text: 'Amount ($)',
      },
      min: 0,
    },
    y1: {
      type: 'linear' as const,
      display: true,
      position: 'right' as const,
      title: {
        display: true,
        text: 'Score',
      },
      min: 0,
      max: 100,
      grid: {
        drawOnChartArea: false,
      },
    },
  },
  animation: {
    duration: 1000,
    easing: 'easeInOutQuart',
  },
};

const labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

const spendingData = {
  labels,
  datasets: [
    {
      label: 'Spending',
      data: [2100, 1800, 2300, 1900, 2100, 1700, 2000],
      borderColor: 'rgb(124, 58, 237)',
      backgroundColor: 'rgba(124, 58, 237, 0.5)',
      tension: 0.3,
      yAxisID: 'y',
    },
    {
      label: 'Stress Level',
      data: [65, 75, 85, 70, 60, 80, 65],
      borderColor: 'rgb(239, 68, 68)',
      backgroundColor: 'rgba(239, 68, 68, 0.5)',
      tension: 0.3,
      yAxisID: 'y1',
    }
  ],
};

const moodData = {
  labels,
  datasets: [
    {
      label: 'Spending',
      data: [2100, 1800, 2300, 1900, 2100, 1700, 2000],
      borderColor: 'rgb(124, 58, 237)',
      backgroundColor: 'rgba(124, 58, 237, 0.5)',
      tension: 0.3,
      yAxisID: 'y',
    },
    {
      label: 'Mood Score',
      data: [85, 75, 82, 78, 90, 88, 85],
      borderColor: 'rgb(72, 187, 120)',
      backgroundColor: 'rgba(72, 187, 120, 0.5)',
      tension: 0.3,
      yAxisID: 'y1',
    }
  ],
};

export default function SpendingGraph() {
  const [timeframe, setTimeframe] = useState('6months');
  const [view, setView] = useState<'spending' | 'mood'>('spending');

  return (
    <Box bg="white" rounded="lg" shadow="sm" p={6}>
      <Box mb={6}>
        <Heading size="md" mb={4}>Monthly Overview</Heading>
        <Flex justify="space-between" align="center">
          <Select 
            value={timeframe} 
            onChange={(e) => setTimeframe(e.target.value)}
            size="sm"
            maxW="200px"
          >
            <option value="3months">Last 3 months</option>
            <option value="6months">Last 6 months</option>
            <option value="1year">Last year</option>
          </Select>
          <ButtonGroup size="sm" isAttached variant="outline">
            <Button
              onClick={() => setView('spending')}
              colorScheme={view === 'spending' ? 'purple' : 'gray'}
            >
              Spending & Stress
            </Button>
            <Button
              onClick={() => setView('mood')}
              colorScheme={view === 'mood' ? 'purple' : 'gray'}
            >
              Spending & Mood
            </Button>
          </ButtonGroup>
        </Flex>
      </Box>

      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
      >
        <Box h="300px">
          <Line 
            options={options} 
            data={view === 'spending' ? spendingData : moodData} 
          />
        </Box>
      </motion.div>
    </Box>
  );
}