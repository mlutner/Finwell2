import {
  Box,
  Button,
  Card,
  CardBody,
  CardHeader,
  Heading,
  HStack,
  Icon,
  Text,
  VStack,
  Circle,
} from '@chakra-ui/react';
import { motion } from 'framer-motion';
import { FiCheck } from 'react-icons/fi';
import { useState } from 'react';

const MOODS = [
  { type: 'great', icon: '😄', label: 'Great', color: 'green.500' },
  { type: 'good', icon: '🙂', label: 'Good', color: 'blue.500' },
  { type: 'neutral', icon: '😐', label: 'Neutral', color: 'gray.500' },
  { type: 'low', icon: '😕', label: 'Low', color: 'orange.500' },
  { type: 'bad', icon: '😢', label: 'Bad', color: 'red.500' }
];

interface Props {
  onMoodSelect?: (mood: string) => void;
}

export default function MoodTracker({ onMoodSelect }: Props) {
  const [selectedMood, setSelectedMood] = useState<string | null>(null);

  const handleMoodSelect = (type: string) => {
    setSelectedMood(type);
    onMoodSelect?.(type);
  };

  return (
    <Card>
      <CardHeader>
        <Heading size="md" textAlign="center">How are you feeling today?</Heading>
      </CardHeader>
      <CardBody>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <HStack spacing={4} justify="center">
            {MOODS.map(({ type, icon, label, color }) => (
              <motion.div
                key={type}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button
                  onClick={() => handleMoodSelect(type)}
                  variant={selectedMood === type ? 'solid' : 'outline'}
                  colorScheme={selectedMood === type ? color.split('.')[0] : 'gray'}
                  size="lg"
                  p={6}
                  position="relative"
                >
                  <VStack>
                    <Text fontSize="2xl">{icon}</Text>
                    <Text fontSize="sm">{label}</Text>
                  </VStack>
                  {selectedMood === type && (
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ duration: 0.2 }}
                    >
                      <Circle
                        size="20px"
                        bg="green.500"
                        position="absolute"
                        top="-2"
                        right="-2"
                        border="2px solid white"
                      >
                        <Icon as={FiCheck} color="white" boxSize={3} />
                      </Circle>
                    </motion.div>
                  )}
                </Button>
              </motion.div>
            ))}
          </HStack>
        </motion.div>
      </CardBody>
    </Card>
  );
}