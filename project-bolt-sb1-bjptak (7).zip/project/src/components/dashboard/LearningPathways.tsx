import {
  Box,
  Button,
  Card,
  CardBody,
  CardHeader,
  Flex,
  Heading,
  Progress,
  Text,
  VStack,
} from '@chakra-ui/react';
import { useNavigate } from 'react-router-dom';

export default function LearningPathways() {
  const navigate = useNavigate();

  const handleCBTAccess = () => {
    navigate('/cbt-program');
  };

  return (
    <Card>
      <CardHeader>
        <Heading size="md">Learning Progress</Heading>
      </CardHeader>

      <CardBody>
        <VStack spacing={4} align="stretch">
          {/* CBT Program Button */}
          <Button
            colorScheme="purple"
            size="lg"
            onClick={handleCBTAccess}
            bgGradient="linear(to-r, purple.500, blue.500)"
            _hover={{
              bgGradient: "linear(to-r, purple.600, blue.600)",
              transform: "translateY(-2px)",
            }}
            shadow="md"
            transition="all 0.2s"
          >
            Access CBT Worksheets & Exercises
          </Button>

          {/* Progress Cards */}
          <PathwayCard
            title="Introduction to FinWell"
            progress={100}
            status="Complete"
            onClick={() => {}}
          />
          <PathwayCard
            title="Spending Tracker"
            progress={60}
            status="Continue"
            onClick={() => {}}
          />
          <PathwayCard
            title="Financial Mindset"
            progress={0}
            status="Start"
            onClick={() => {}}
          />
        </VStack>
      </CardBody>
    </Card>
  );
}

interface PathwayCardProps {
  title: string;
  progress: number;
  status: string;
  onClick: () => void;
}

function PathwayCard({ title, progress, status, onClick }: PathwayCardProps) {
  return (
    <Flex
      justify="space-between"
      align="center"
      p={4}
      bg="gray.50"
      rounded="lg"
      cursor="pointer"
      onClick={onClick}
      _hover={{ bg: 'gray.100' }}
    >
      <Box flex={1}>
        <Text fontWeight="medium" mb={2}>{title}</Text>
        <Progress
          value={progress}
          size="sm"
          colorScheme="purple"
          rounded="full"
          w="32"
        />
      </Box>
      <Text color="purple.600" fontWeight="medium">{status}</Text>
    </Flex>
  );
}