import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalCloseButton,
  Text,
  VStack,
  Box,
  Icon,
  Flex,
  Divider,
} from '@chakra-ui/react';
import { 
  FiShield, 
  FiCpu, 
  FiHeart, 
  FiLock 
} from 'react-icons/fi';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export default function ChatExplainer({ isOpen, onClose }: Props) {
  const features = [
    {
      icon: FiCpu,
      title: 'AI-Powered Support',
      description: 'Get instant, personalized guidance based on your unique financial situation and emotional state.'
    },
    {
      icon: FiHeart,
      title: 'Emotional Support',
      description: 'Our AI assistant is trained to provide empathetic responses and help you manage financial stress.'
    },
    {
      icon: FiShield,
      title: 'Evidence-Based',
      description: 'Recommendations are based on CBT principles and proven financial wellness strategies.'
    },
    {
      icon: FiLock,
      title: 'Private & Secure',
      description: 'Your conversations are private and encrypted. We never share your personal information.'
    }
  ];

  return (
    <Modal isOpen={isOpen} onClose={onClose} size="lg">
      <ModalOverlay />
      <ModalContent>
        <ModalHeader>About AI Financial Assistant</ModalHeader>
        <ModalCloseButton />
        <ModalBody pb={6}>
          <VStack spacing={6} align="stretch">
            <Text color="gray.600">
              Your AI Financial Assistant combines artificial intelligence with financial therapy principles to provide personalized support and guidance on your journey to financial wellness.
            </Text>

            <Divider />

            <VStack spacing={4} align="stretch">
              {features.map((feature, index) => (
                <Flex key={index} gap={4}>
                  <Box
                    p={2}
                    bg="purple.50"
                    color="purple.500"
                    rounded="lg"
                    boxSize="40px"
                    display="flex"
                    alignItems="center"
                    justifyContent="center"
                  >
                    <Icon as={feature.icon} boxSize={5} />
                  </Box>
                  <Box>
                    <Text fontWeight="medium">{feature.title}</Text>
                    <Text color="gray.600" fontSize="sm">
                      {feature.description}
                    </Text>
                  </Box>
                </Flex>
              ))}
            </VStack>

            <Box bg="blue.50" p={4} rounded="lg">
              <Text fontSize="sm" color="blue.800">
                Note: While our AI assistant provides valuable support, it's not a replacement for professional financial or mental health services. Please seek professional help when needed.
              </Text>
            </Box>
          </VStack>
        </ModalBody>
      </ModalContent>
    </Modal>
  );
}