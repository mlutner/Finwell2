import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Link as RouterLink } from 'react-router-dom';
import { signInWithEmailAndPassword, signInWithPopup } from 'firebase/auth';
import { auth, googleProvider } from '../../config/firebase';
import {
  Box,
  Button,
  VStack,
  Text,
  useToast,
  Heading,
  Image,
  Divider,
  Link,
  Center,
  Icon,
} from '@chakra-ui/react';
import { FcGoogle } from 'react-icons/fc';

function SignIn() {
  const [loading, setLoading] = useState(false);
  const toast = useToast();
  const navigate = useNavigate();

  const handleDemoLogin = async () => {
    try {
      setLoading(true);
      await signInWithEmailAndPassword(auth, 'demo@finwell.com', 'demo123');
      navigate('/');
    } catch (error) {
      toast({
        title: 'Error signing in',
        description: 'Demo account login failed. Please try again.',
        status: 'error',
        duration: 5000,
        isClosable: true,
      });
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    try {
      setLoading(true);
      await signInWithPopup(auth, googleProvider);
      navigate('/');
    } catch (error) {
      toast({
        title: 'Error signing in with Google',
        description: 'Please try again.',
        status: 'error',
        duration: 5000,
        isClosable: true,
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box maxW="md" mx="auto" mt={8} p={8} borderRadius="lg" bg="white" boxShadow="sm">
      <VStack spacing={2} align="center">
        <Image src="/owl-logo.svg" alt="FinWell Logo" boxSize="160px" />
        
        <Heading as="h1" size="xl" color="purple.700">
          FinWell
        </Heading>
        
        <Text fontSize="lg" color="gray.600" mt={4}>
          Your Financial Wellness Journey
        </Text>

        <Heading as="h2" size="xl" color="navy.800" mt={4}>
          Welcome Back
        </Heading>

        <Text fontSize="lg" color="blue.600">
          Continue your journey to financial wellbeing
        </Text>

        <Button
          w="full"
          size="lg"
          colorScheme="purple"
          onClick={handleDemoLogin}
          isLoading={loading}
          mt={4}
          bgGradient="linear(to-r, purple.500, blue.500)"
          _hover={{
            bgGradient: "linear(to-r, purple.600, blue.600)",
          }}
        >
          View Demo Dashboard
        </Button>

        <Center w="full" position="relative" py={4}>
          <Divider />
          <Text
            position="absolute"
            bg="white"
            px={4}
            color="gray.500"
          >
            OR
          </Text>
        </Center>

        <Button
          w="full"
          size="lg"
          variant="outline"
          leftIcon={<Icon as={FcGoogle} boxSize={5} />}
          onClick={handleGoogleSignIn}
          isLoading={loading}
        >
          Continue with Google
        </Button>

        <Text color="gray.600" fontSize="sm" mt={4}>
          Don't have an account?{' '}
          <Link as={RouterLink} to="/signup" color="purple.500">
            Sign up
          </Link>
        </Text>
      </VStack>
    </Box>
  );
}

export default SignIn;