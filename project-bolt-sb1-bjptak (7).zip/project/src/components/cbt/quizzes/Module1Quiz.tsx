import {
  Box,
  Button,
  Card,
  CardBody,
  CardHeader,
  Heading,
  Radio,
  RadioGroup,
  Stack,
  Text,
  VStack,
  Progress,
  useToast,
} from '@chakra-ui/react';
import { useState } from 'react';
import { motion } from 'framer-motion';

interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

const module1Questions: QuizQuestion[] = [
  {
    id: 1,
    question: "Which of the following is NOT a key component of a SMART financial goal?",
    options: [
      "Specific amounts and deadlines",
      "Measurable progress indicators",
      "Ambitious but unrealistic targets",
      "Time-bound milestones"
    ],
    correctAnswer: 2,
    explanation: "SMART goals should be Specific, Measurable, Achievable, Relevant, and Time-bound. Unrealistic targets contradict the 'Achievable' criterion."
  },
  {
    id: 2,
    question: "What is the primary purpose of financial journaling?",
    options: [
      "To track daily expenses only",
      "To understand emotional patterns around money",
      "To record investment returns",
      "To plan budgets"
    ],
    correctAnswer: 1,
    explanation: "Financial journaling helps identify and understand emotional patterns and triggers related to money behaviors."
  },
  {
    id: 3,
    question: "How can tracking your mood alongside financial decisions help?",
    options: [
      "It doesn't affect financial decisions",
      "It helps identify emotional spending triggers",
      "It only matters for large purchases",
      "It's only relevant for savings goals"
    ],
    correctAnswer: 1,
    explanation: "Tracking mood helps identify emotional triggers that influence spending and financial decisions."
  },
  {
    id: 4,
    question: "What is the best way to handle financial stress?",
    options: [
      "Ignore it completely",
      "Make impulsive decisions to feel better",
      "Acknowledge it and seek support",
      "Wait for it to go away"
    ],
    correctAnswer: 2,
    explanation: "Acknowledging financial stress and seeking appropriate support is the healthiest approach to managing it."
  },
  {
    id: 5,
    question: "Which statement best describes financial wellness?",
    options: [
      "Having a lot of money",
      "Never experiencing financial stress",
      "Balance between financial health and emotional wellbeing",
      "Making only perfect financial decisions"
    ],
    correctAnswer: 2,
    explanation: "Financial wellness is about maintaining a healthy balance between financial health and emotional wellbeing."
  }
];

interface Props {
  onComplete: (results: { score: number; answers: Record<number, number> }) => void;
}

export default function Module1Quiz({ onComplete }: Props) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [showExplanation, setShowExplanation] = useState(false);
  const toast = useToast();

  const handleAnswer = (value: string) => {
    setAnswers(prev => ({
      ...prev,
      [currentQuestion]: parseInt(value)
    }));
    setShowExplanation(true);
  };

  const handleNext = () => {
    setShowExplanation(false);
    if (currentQuestion < module1Questions.length - 1) {
      setCurrentQuestion(prev => prev + 1);
    } else {
      const score = calculateScore();
      onComplete({ score, answers });
    }
  };

  const calculateScore = () => {
    const correctAnswers = Object.entries(answers).filter(
      ([questionIndex, answer]) => 
        answer === module1Questions[parseInt(questionIndex)].correctAnswer
    ).length;
    return Math.round((correctAnswers / module1Questions.length) * 100);
  };

  const question = module1Questions[currentQuestion];
  const progress = ((currentQuestion + 1) / module1Questions.length) * 100;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card>
        <CardHeader>
          <VStack spacing={4} align="stretch">
            <Heading size="lg">Module 1 Quiz: Financial Wellness Foundations</Heading>
            <Progress
              value={progress}
              size="sm"
              colorScheme="purple"
              borderRadius="full"
            />
            <Text color="gray.600">
              Question {currentQuestion + 1} of {module1Questions.length}
            </Text>
          </VStack>
        </CardHeader>

        <CardBody>
          <VStack spacing={6} align="stretch">
            <Box>
              <Text fontSize="lg" fontWeight="medium" mb={4}>
                {question.question}
              </Text>

              <RadioGroup
                onChange={handleAnswer}
                value={answers[currentQuestion]?.toString()}
                isDisabled={showExplanation}
              >
                <Stack spacing={4}>
                  {question.options.map((option, index) => (
                    <Radio
                      key={index}
                      value={index.toString()}
                      colorScheme="purple"
                      size="lg"
                    >
                      {option}
                    </Radio>
                  ))}
                </Stack>
              </RadioGroup>
            </Box>

            {showExplanation && (
              <Card
                bg={
                  answers[currentQuestion] === question.correctAnswer
                    ? 'green.50'
                    : 'red.50'
                }
                p={4}
              >
                <Text
                  color={
                    answers[currentQuestion] === question.correctAnswer
                      ? 'green.700'
                      : 'red.700'
                  }
                  fontWeight="medium"
                  mb={2}
                >
                  {answers[currentQuestion] === question.correctAnswer
                    ? '✓ Correct!'
                    : '✗ Incorrect'}
                </Text>
                <Text color="gray.700">{question.explanation}</Text>
              </Card>
            )}

            {showExplanation && (
              <Button
                colorScheme="purple"
                onClick={handleNext}
                size="lg"
                w="full"
                bgGradient="linear(to-r, purple.500, blue.500)"
                _hover={{
                  bgGradient: "linear(to-r, purple.600, blue.600)",
                }}
              >
                {currentQuestion === module1Questions.length - 1
                  ? 'Complete Quiz'
                  : 'Next Question'}
              </Button>
            )}
          </VStack>
        </CardBody>
      </Card>
    </motion.div>
  );
}