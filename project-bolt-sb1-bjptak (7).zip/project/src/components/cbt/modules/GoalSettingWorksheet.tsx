import {
  Box,
  Button,
  Card,
  CardBody,
  CardHeader,
  FormControl,
  FormLabel,
  Heading,
  Input,
  Select,
  Text,
  Textarea,
  VStack,
  useToast,
  List,
  ListItem,
  ListIcon,
  Divider,
} from '@chakra-ui/react';
import { useState } from 'react';
import { motion } from 'framer-motion';
import { FiCheck } from 'react-icons/fi';

interface Goal {
  type: string;
  timeframe: string;
  description: string;
  target: string;
  steps: string[];
  obstacles: string[];
  support: string[];
  metrics: string;
}

interface Props {
  onComplete: (goals: Goal[]) => void;
}

const SMART_CRITERIA = [
  {
    letter: 'S',
    title: 'Specific',
    description: 'Clear and well-defined goals'
  },
  {
    letter: 'M',
    title: 'Measurable',
    description: 'Quantifiable progress and targets'
  },
  {
    letter: 'A',
    title: 'Achievable',
    description: 'Realistic and attainable'
  },
  {
    letter: 'R',
    title: 'Relevant',
    description: 'Aligned with your values and long-term objectives'
  },
  {
    letter: 'T',
    title: 'Time-bound',
    description: 'Set deadlines and milestones'
  }
];

export default function GoalSettingWorksheet({ onComplete }: Props) {
  const [goals, setGoals] = useState<Goal[]>([{
    type: '',
    timeframe: '',
    description: '',
    target: '',
    steps: [''],
    obstacles: [''],
    support: [''],
    metrics: ''
  }]);
  const toast = useToast();

  const handleSubmit = () => {
    if (!validateGoals()) {
      toast({
        title: 'Please complete all fields',
        status: 'warning',
        duration: 3000,
      });
      return;
    }

    onComplete(goals);
    toast({
      title: 'Goals saved successfully',
      status: 'success',
      duration: 3000,
    });
  };

  const validateGoals = () => {
    return goals.every(goal => 
      Object.entries(goal).every(([key, value]) => {
        if (Array.isArray(value)) {
          return value.length > 0 && value.every(item => item.trim() !== '');
        }
        return value.trim() !== '';
      })
    );
  };

  const updateGoal = (index: number, field: keyof Goal, value: any) => {
    const updatedGoals = [...goals];
    updatedGoals[index] = { ...updatedGoals[index], [field]: value };
    setGoals(updatedGoals);
  };

  const addArrayItem = (goalIndex: number, field: 'steps' | 'obstacles' | 'support') => {
    const updatedGoals = [...goals];
    updatedGoals[goalIndex][field] = [...updatedGoals[goalIndex][field], ''];
    setGoals(updatedGoals);
  };

  const updateArrayItem = (
    goalIndex: number,
    field: 'steps' | 'obstacles' | 'support',
    itemIndex: number,
    value: string
  ) => {
    const updatedGoals = [...goals];
    updatedGoals[goalIndex][field][itemIndex] = value;
    setGoals(updatedGoals);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card>
        <CardHeader>
          <Heading size="lg">SMART Goal Setting</Heading>
          <Text mt={2} color="gray.600">
            Define your financial and wellness goals using the SMART framework
          </Text>
        </CardHeader>

        <CardBody>
          <VStack spacing={8} align="stretch">
            {/* SMART Criteria Guide */}
            <Card variant="outline" p={4}>
              <Heading size="sm" mb={4}>SMART Goal Criteria</Heading>
              <List spacing={3}>
                {SMART_CRITERIA.map(({ letter, title, description }) => (
                  <ListItem key={letter} display="flex" alignItems="center">
                    <ListIcon as={FiCheck} color="green.500" />
                    <Box>
                      <Text fontWeight="bold">
                        <Text as="span" color="purple.500">{letter}</Text>
                        {title}
                      </Text>
                      <Text fontSize="sm" color="gray.600">{description}</Text>
                    </Box>
                  </ListItem>
                ))}
              </List>
            </Card>

            <Divider />

            {goals.map((goal, goalIndex) => (
              <Box key={goalIndex} p={6} bg="gray.50" rounded="lg">
                <VStack spacing={6} align="stretch">
                  <FormControl isRequired>
                    <FormLabel>Goal Type</FormLabel>
                    <Select
                      value={goal.type}
                      onChange={(e) => updateGoal(goalIndex, 'type', e.target.value)}
                    >
                      <option value="">Select type</option>
                      <option value="saving">Saving</option>
                      <option value="spending">Spending</option>
                      <option value="debt">Debt Management</option>
                      <option value="income">Income</option>
                      <option value="investment">Investment</option>
                      <option value="wellness">Financial Wellness</option>
                    </Select>
                  </FormControl>

                  <FormControl isRequired>
                    <FormLabel>Timeframe</FormLabel>
                    <Select
                      value={goal.timeframe}
                      onChange={(e) => updateGoal(goalIndex, 'timeframe', e.target.value)}
                    >
                      <option value="">Select timeframe</option>
                      <option value="1month">1 Month</option>
                      <option value="3months">3 Months</option>
                      <option value="6months">6 Months</option>
                      <option value="1year">1 Year</option>
                      <option value="2years">2+ Years</option>
                    </Select>
                  </FormControl>

                  <FormControl isRequired>
                    <FormLabel>Goal Description</FormLabel>
                    <Textarea
                      value={goal.description}
                      onChange={(e) => updateGoal(goalIndex, 'description', e.target.value)}
                      placeholder="What do you want to achieve? Be specific."
                    />
                  </FormControl>

                  <FormControl isRequired>
                    <FormLabel>Target (Measurable Outcome)</FormLabel>
                    <Input
                      value={goal.target}
                      onChange={(e) => updateGoal(goalIndex, 'target', e.target.value)}
                      placeholder="e.g., Save $5000, Reduce spending by 20%"
                    />
                  </FormControl>

                  <FormControl isRequired>
                    <FormLabel>Success Metrics</FormLabel>
                    <Input
                      value={goal.metrics}
                      onChange={(e) => updateGoal(goalIndex, 'metrics', e.target.value)}
                      placeholder="How will you measure success?"
                    />
                  </FormControl>

                  <FormControl isRequired>
                    <FormLabel>Action Steps</FormLabel>
                    <VStack spacing={2}>
                      {goal.steps.map((step, stepIndex) => (
                        <Input
                          key={stepIndex}
                          value={step}
                          onChange={(e) => updateArrayItem(goalIndex, 'steps', stepIndex, e.target.value)}
                          placeholder={`Step ${stepIndex + 1}`}
                        />
                      ))}
                      <Button
                        size="sm"
                        onClick={() => addArrayItem(goalIndex, 'steps')}
                        variant="ghost"
                      >
                        Add Step
                      </Button>
                    </VStack>
                  </FormControl>

                  <FormControl isRequired>
                    <FormLabel>Potential Obstacles</FormLabel>
                    <VStack spacing={2}>
                      {goal.obstacles.map((obstacle, obstacleIndex) => (
                        <Input
                          key={obstacleIndex}
                          value={obstacle}
                          onChange={(e) => updateArrayItem(goalIndex, 'obstacles', obstacleIndex, e.target.value)}
                          placeholder="What might get in your way?"
                        />
                      ))}
                      <Button
                        size="sm"
                        onClick={() => addArrayItem(goalIndex, 'obstacles')}
                        variant="ghost"
                      >
                        Add Obstacle
                      </Button>
                    </VStack>
                  </FormControl>

                  <FormControl isRequired>
                    <FormLabel>Support & Resources</FormLabel>
                    <VStack spacing={2}>
                      {goal.support.map((support, supportIndex) => (
                        <Input
                          key={supportIndex}
                          value={support}
                          onChange={(e) => updateArrayItem(goalIndex, 'support', supportIndex, e.target.value)}
                          placeholder="What resources or support will help you succeed?"
                        />
                      ))}
                      <Button
                        size="sm"
                        onClick={() => addArrayItem(goalIndex, 'support')}
                        variant="ghost"
                      >
                        Add Support
                      </Button>
                    </VStack>
                  </FormControl>
                </VStack>
              </Box>
            ))}

            <Button
              onClick={() => setGoals([...goals, {
                type: '',
                timeframe: '',
                description: '',
                target: '',
                steps: [''],
                obstacles: [''],
                support: [''],
                metrics: ''
              }])}
              variant="outline"
              colorScheme="purple"
            >
              Add Another Goal
            </Button>

            <Button
              colorScheme="purple"
              size="lg"
              onClick={handleSubmit}
              bgGradient="linear(to-r, purple.500, blue.500)"
              _hover={{
                bgGradient: "linear(to-r, purple.600, blue.600)",
              }}
            >
              Save Goals
            </Button>
          </VStack>
        </CardBody>
      </Card>
    </motion.div>
  );
}