import {
  Box,
  Button,
  Card,
  CardBody,
  CardHeader,
  Flex,
  Heading,
  Text,
  Badge,
  Icon,
  useDisclosure,
} from '@chakra-ui/react';
import { FiCalendar, FiVideo, FiMessageSquare } from 'react-icons/fi';
import ConsultationModal from './ConsultationModal';

export default function ConsultationSection() {
  const { isOpen, onOpen, onClose } = useDisclosure();

  return (
    <Card>
      <CardHeader>
        <Flex justify="space-between" align="center">
          <Box>
            <Heading size="md">Professional Support</Heading>
            <Text color="gray.600" mt={1}>Get expert guidance for your financial journey</Text>
          </Box>
          <Badge colorScheme="purple">3 Free Sessions</Badge>
        </Flex>
      </CardHeader>

      <CardBody>
        <Box mb={6}>
          <Flex gap={4} mb={4}>
            <Card flex={1} p={4} variant="outline">
              <Flex align="center" gap={3}>
                <Icon as={FiVideo} boxSize={5} color="blue.500" />
                <Box>
                  <Text fontWeight="medium">Video Call</Text>
                  <Text fontSize="sm" color="gray.600">1-on-1 consultation</Text>
                </Box>
              </Flex>
            </Card>
            <Card flex={1} p={4} variant="outline">
              <Flex align="center" gap={3}>
                <Icon as={FiMessageSquare} boxSize={5} color="green.500" />
                <Box>
                  <Text fontWeight="medium">Chat Support</Text>
                  <Text fontSize="sm" color="gray.600">Instant messaging</Text>
                </Box>
              </Flex>
            </Card>
          </Flex>

          <Card p={4} bg="purple.50" mb={4}>
            <Flex align="center" gap={3}>
              <Icon as={FiCalendar} boxSize={5} color="purple.500" />
              <Box>
                <Text fontWeight="medium">Next Available Slot</Text>
                <Text fontSize="sm" color="purple.700">Today at 2:00 PM</Text>
              </Box>
            </Flex>
          </Card>

          <Button
            w="full"
            colorScheme="purple"
            size="lg"
            onClick={onOpen}
            bgGradient="linear(to-r, purple.500, blue.500)"
            _hover={{
              bgGradient: "linear(to-r, purple.600, blue.600)",
            }}
          >
            Schedule Consultation
          </Button>
        </Box>
      </CardBody>

      <ConsultationModal isOpen={isOpen} onClose={onClose} />
    </Card>
  );
}