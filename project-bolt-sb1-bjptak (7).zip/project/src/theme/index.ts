import { extendTheme, type ThemeConfig } from '@chakra-ui/react';

const config: ThemeConfig = {
  initialColorMode: 'light',
  useSystemColorMode: false,
  cssVarPrefix: 'finwell',
};

// Add consistent motion preferences
const theme = extendTheme({
  config,
  styles: {
    global: (props) => ({
      body: {
        bg: props.colorMode === 'dark' ? 'gray.900' : 'gray.50',
        color: props.colorMode === 'dark' ? 'white' : 'gray.900',
      },
    }),
  },
  components: {
    Button: {
      baseStyle: {
        _hover: {
          transform: 'translateY(-2px)',
          shadow: 'lg',
        },
        transition: 'all 0.2s',
      },
    },
    Card: {
      baseStyle: {
        container: {
          transition: 'all 0.2s',
          _hover: {
            shadow: 'lg',
          },
        },
      },
    },
  },
});

export default theme;